import 'package:vambora_passageiro/pages/SelectViaturaPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../controller/MapController.dart';
import '../pages/PagamentosPage.dart';
import '../pages/TelaDetalhesViagemPage.dart';

class CardPagamentos extends StatefulWidget {
  DateTime data;
  final String id;
  final String valor;
  final String origemViagem;
  final String destinoViagem;
  final String pagamentoViagem;
  final String horaInicio;
  final String horaFim;
  final String origem;
  final String destino;

  CardPagamentos(
      {required this.id,
      required this.data,
      required this.valor,
      required this.destinoViagem,
      required this.horaFim,
      required this.horaInicio,
      required this.origemViagem,
      required this.pagamentoViagem,
      required this.destino,
      required this.origem});

  @override
  _CardPagamentosState createState() => _CardPagamentosState();
}

class _CardPagamentosState extends State<CardPagamentos> {
  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFEDEEE9),
              Color(0xFFEDEEE9),
              Color(0xFFEDEEE9),
              Color(0xFFEDEEE9),
            ],
            stops: [0.1, 0.4, 0.7, 0.9],
          ),
        ),
        child: Column(
          children: [
            InkWell(
              onTap: () {
                setState(() {
                  dataViagem = widget.data;
                  origemViagem = widget.origemViagem;
                  destinoViagem = widget.destinoViagem;
                  pagamentoViagem = widget.pagamentoViagem;
                  valorViagem = widget.valor;
                  horaInicio = widget.horaInicio;
                  horaFim = widget.horaFim;
                  origem_pedido = widget.origem;
                  destino_pedido = widget.destino;
                  posicaoV1 = double.tryParse(origem_pedido.split(',')[0])!;
                  posicaoV2 = double.tryParse(origem_pedido.split(',')[1])!;
                  destinoV1 = double.tryParse(destino_pedido.split(',')[0])!;
                  destinoV2 = double.tryParse(destino_pedido.split(',')[1])!;
                  print(posicaoV1);
                  print(posicaoV2);
                  print(destinoV1);
                  print(destinoV2);
                });
                print(valorViagem);
                {
                  Navigator.of(context).push(CupertinoPageRoute(
                      builder: (BuildContext context) =>
                          const TelaDetalhesViagemPage()));
                }
              },
              child: Card(
                  elevation: 2,
                  child: Column(
                    children: [
                      ListTile(
                        trailing: Text(
                          " ${widget.valor} AOA",
                          style: const TextStyle(
                            color: Colors.black,
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'gotham',
                          ),
                        ),
                        title: Text(
                          DateFormat.yMMMd().format(widget.data),
                          style: const TextStyle(
                            color: Colors.black54,
                            fontSize: 14.0,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'gotham',
                            overflow: TextOverflow.visible,
                          ),
                        ),
                      ),
                    ],
                  )),
            )
          ],
        ));
  }
}
