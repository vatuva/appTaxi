class EnderecoModel {
  final String formatted;
  final String addressLine;
  final double lat;
  final double lon;

  EnderecoModel({
    required this.formatted,
    required this.addressLine,
    required this.lat,
    required this.lon,
  });

  Map<String, dynamic> toMap() {
    return {
      'formatted': formatted,
      'addressLine': addressLine,
      'lat': lat,
      'lon': lon,
    };
  }

  factory EnderecoModel.fromMap(Map<String, dynamic> map) {
    return EnderecoModel(
      formatted: map['formatted'],
      addressLine: map['addressLine'],
      lat: map['lat'],
      lon: map['lon'],
    );
  }
}
