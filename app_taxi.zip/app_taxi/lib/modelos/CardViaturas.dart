import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../pages/DefineRotaPage.dart';
import '../pages/SelectViaturaPage.dart';

var viatura;
var estimativa;
var nome_viatura;
var desc_viatara;
final formatCurrency = new NumberFormat.simpleCurrency();
var taxakm;
var valor;
var tarifa_inicio;
var tarifa_base;

// ignore: must_be_immutable
class CardViaturas extends StatefulWidget {
  final String nomeCat;
  final String imgCat;
  var tbase;
  final String id;
  var tkm;
  var tinicio;
  var desc_viatura;

  CardViaturas(
      {required this.id,
      required this.nomeCat,
      required this.imgCat,
      this.tbase,
      this.tkm,
      this.tinicio,
      this.desc_viatura});

  @override
  _CardViaturasState createState() => _CardViaturasState();
}

class _CardViaturasState extends State<CardViaturas> {
  initState() {
    setState(() {});
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        widget.desc_viatura,
        style: const TextStyle(
          fontFamily: "Gotham",
          fontSize: 22,
          // color: Colors.white,
        ),
      ),
      leading: const Image(
        image: AssetImage("assets/images/moto2.png"),
        width: 100,
        height: 45,
      ),
      trailing: carregadoViatura == false
          ? const Text(
              "0.0",
              style: TextStyle(
                fontFamily: "Gotham",
                fontSize: 18,
                color: Color(0xFFEDEEE9),
              ),
            )
          : Text(
              NumberFormat.currency(locale: 'eu', symbol: 'Kz')
                  .format((double?.parse(widget.tbase) +
                      double?.parse(widget.tkm) * calc_distancia_viatura!))
                  .toString(),
              style: const TextStyle(
                fontFamily: "Gotham",
                fontSize: 18,
                color: Color(0xFFEDEEE9),
              )),
      selectedColor: Colors.white,
      onLongPress: () {},
      onTap: () async {
        viatura_pedido = widget.desc_viatura;
        tipo_viatura = widget.nomeCat;
        setState(() async {

        });
      },
    );
  }
}
