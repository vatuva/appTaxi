import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'Endereco_Model.dart';

class HistoricoEnderecoService {
  static const String _keyOrigem = 'historico_origem';
  static const String _keyDestino = 'historico_destino';
  static const int _limite = 5;

  static String _getKey(String tipo) {
    return tipo == "Origem" ? _keyOrigem : _keyDestino;
  }

  static Future<void> salvar(
      String tipo, EnderecoModel endereco) async {
    final prefs = await SharedPreferences.getInstance();
    final key = _getKey(tipo);

    List<String> lista = prefs.getStringList(key) ?? [];

    // Remove duplicados
    lista.removeWhere((e) =>
    EnderecoModel.fromMap(json.decode(e)).formatted ==
        endereco.formatted);

    lista.insert(0, json.encode(endereco.toMap()));

    if (lista.length > _limite) {
      lista = lista.sublist(0, _limite);
    }

    await prefs.setStringList(key, lista);
  }

  static Future<List<EnderecoModel>> listar(String tipo) async {
    final prefs = await SharedPreferences.getInstance();
    final key = _getKey(tipo);

    final lista = prefs.getStringList(key) ?? [];

    return lista
        .map((e) => EnderecoModel.fromMap(json.decode(e)))
        .toList();
  }

  static Future<void> limpar(String tipo) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_getKey(tipo));
  }
}
