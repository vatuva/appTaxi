import 'package:flutter/material.dart';

class CardChat extends StatelessWidget {
  final String mensagem;
  final String data;
  final String hora;
  final String id;
  final String status;

  const CardChat(
      {required this.id,
        required this.data,
        required this.hora,
        required this.mensagem,
        required this.status});

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: status != "1" ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 14),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width * 0.75,
        ),
        decoration: BoxDecoration(
          color:status != "1" ? const Color(0xFFDCF8C6) : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(status != "1" ? 14 : 0),
            bottomRight: Radius.circular(status != "1" ? 0 : 14),
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 4,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment:
          status != "1" ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            Text(
              mensagem,
              style: const TextStyle(fontSize: 15),
            ),
            const SizedBox(height: 6),
            Text(
              '$data $hora',
              style: TextStyle(
                fontSize: 11,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
