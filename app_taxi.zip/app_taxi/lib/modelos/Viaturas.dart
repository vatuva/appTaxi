import 'package:google_maps_flutter/google_maps_flutter.dart';

class Viatura {
  final String matricula;
  final String apelido;
  final LatLng posicao;

  Viatura({
    required this.matricula,
    required this.apelido,
    required this.posicao,
  });

  factory Viatura.fromJson(Map<String, dynamic> json) {
    final String localizacao = json['localizacao_actual'];

    final partes = localizacao.split(',');

    return Viatura(
      matricula: json['matricula'].toString(),
      apelido: json['apelido'].toString(),
      posicao: LatLng(
        double.parse(partes[0]),
        double.parse(partes[1]),
      ),
    );
  }
}
