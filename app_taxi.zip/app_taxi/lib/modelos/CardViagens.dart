import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';



class CardViagens extends StatefulWidget {
  final String data;
  final String origem;
  final String destino;
  final String id;

  CardViagens({required this.id, required this.data, required this.origem, required this.destino});

  @override
  _CardViagensState createState() => _CardViagensState();
}
class _CardViagensState extends State<CardViagens> {


  @override
  Widget build(BuildContext context) {
    return Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFBFCFD),
              Color(0xFFFBFCFD),
              Color(0xFFFBFCFD),
              Color(0xFFFBFCFD),
            ],
            stops: [0.1, 0.4, 0.7, 0.9],
          ),
        ),
        child:Column(
          children: [
            Card(
                elevation: 10,
                child: Column(
                  children: [
                    ListTile(
                      selectedTileColor: const Color(0xFFFF0066),
                      leading: IconButton(
                        icon: const Icon(
                          Icons.gps_fixed,
                          color: Color(0xFF00008B),
                          size: 10,
                        ), onPressed: () {  },
                      ),
                      title: Text(
                        widget.origem,
                        overflow: TextOverflow.visible,
                        maxLines: 1,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 9.0,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'gotham',
                        ),
                      ),
                    ),
                    ListTile(
                      selectedTileColor: const Color(0xFFFF0066),
                      leading: IconButton(
                        icon: const Icon(
                          Icons.album_outlined,
                          color: Color(0xFF00008B),
                          size: 10,
                        ), onPressed: () {  },
                      ),
                      title: Text(
                        widget.destino,
                        overflow: TextOverflow.visible,
                        maxLines: 1,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 9.0,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'gotham',
                        ),
                      ),
                    ),
                    ListTile(
                      selectedTileColor: const Color(0xFFFF0066),
                      leading: IconButton(
                        icon: const Icon(
                          Icons.date_range,
                          color: Color(0xFF00008B),
                          size: 10,
                        ), onPressed: () {  },
                      ),
                      title: Text(
                        widget.data,
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 9.0,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'gotham',
                        ),
                      ),
                    ),
                  ],
                )
            ),
          ],
        )

    );
  }
}



