const google_api_key2="AIzaSyB0R8RyGL1x3IcwjThoUxnBROm21nxn_3Y";
const google_api_key="AIzaSyCILhuIZ26t6soOU-9blNKITB1-OqFeQS0";
const versionApp="1.0";
String Token_Mapbox="9ef98a60be3b4e0b93f691dbbba574e1";
/*
const dom="fm2.mvconws.com";
const endpoint="";
const pathURL="https://fm2.mvconws.com/";
const urlImagem="https://mvconws.com/fastmotoproducao2/";
const country="ao";
const language="pt";
const reg="Luanda";
*/


const dom="mvconws.com";
const endpoint="vamborawbs";
const pathURL="https://mvconws.com/";
const urlImagem="https://mvconws.com/vamborawbs/";
const country="ao";
const language="pt";
const reg="Luanda";
const urlsite="https://mvcon.net";
const urlplaystore="https://play.google.com/store/apps/details?id=com.vambora_passageiro.app.vambora_passageiro";
const urlappstore="https://apps.apple.com/us/app/vambora/id6747607032";
const urlpolitica="https://mvconws.com/policy/politica_vambora.html";
const urlreport="https://mvcon.net";
const urlcallcenter="https://mvcon.net";
