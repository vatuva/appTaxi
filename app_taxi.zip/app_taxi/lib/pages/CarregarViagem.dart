import 'dart:async';
import 'dart:convert';
import 'package:vambora_passageiro/modelos/CardViaturas.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../config/Constats.dart';
import 'DriverPage.dart';
import 'PrincipalPage.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';

import 'RadarPage.dart';
import 'SelectPagamentoPage.dart';
import 'SelectViaturaPage.dart';


class CarregarViagem extends StatefulWidget {
  @override
  // ignore: library_private_types_in_public_api
  _CarregarViagem createState() => _CarregarViagem();
}

class _CarregarViagem extends State<CarregarViagem> {
  Future DadosPedido() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/pedido/dados-pedido";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": idPedido.toString(),
      });
      final map = json.decode(response.body);
      final dados = map['pedido'];
      final motorista = map['motorista'];
      final infoMotorista = map['info_motorista'];
      setState(() {
        estado_pedido = dados['status'];
        posicaoMotorista = infoMotorista['localizacao_actual'];
        desc_origem_pedido = dados['desc_origem'];
        desc_destino_pedido = dados['desc_destino'];
        origem_viagem = dados['origem'];
        destino_viagem = dados['destino'];
        final nomeMoto = motorista['nome'];
        final sobrenomeMoto = motorista['apelido'];
        nome_motorista = "$nomeMoto";
        foto_motorista = motorista['foto'];
        contacto_motorista = motorista['telefone'];
        id_motorista = motorista['id'];
        viatura_motorista = infoMotorista['categoria'];
        matricula_motorista = infoMotorista['matricula'];
        marca_viatura = infoMotorista['marca_viatura'];
        cor_viatura = infoMotorista['cor'];
        modelo_viatura = infoMotorista['modelo_viatura'];
        LatLong();
      });
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        CustomSnackBar.error(
          message:
              'Ops! Ocorreu um erro. Erro $e.',
        ),
      );
    }
  }

  // ignore: non_constant_identifier_names
  void LatLong() {
    lat1 = double.tryParse(origem_viagem.toString().split(',')[0]);
    long1 = double.tryParse(origem_viagem.toString().split(',')[1]);
    lat2 = double.tryParse(destino_viagem.toString().split(',')[0]);
    long2 = double.tryParse(destino_viagem.toString().split(',')[1]);
    latPosMoto = double.tryParse(posicaoMotorista.toString().split(',')[0]);
    longPosMoto = double.tryParse(posicaoMotorista.toString().split(',')[1]);
  }

  void pegarVariaveisViagem() async {
    taxakm = await SessionManager().get("taxa_km");
    tarifa_base = await SessionManager().get("tarifa_base");
    valor_estimado = await SessionManager().get("valor_estimado");
  }

  @override
  void initState() {
    pegarVariaveisViagem();
    DadosPedido();
    super.initState();
    Timer(const Duration(seconds: 10), () {
      setState(() {
        DadosPedido();
      });
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (BuildContext context) => DriverPage()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        theme: ThemeData(fontFamily: 'Gotham'),
        home: const Scaffold(
            backgroundColor: Color(0xFFFBFCFD),
            body: Stack(
              alignment: Alignment.center,
              children: [
                Center(
                  child: CircularProgressIndicator(
                    strokeWidth: 10,
                    color: Color(0xFFEDBD1D), //<-- SEE HERE
                    backgroundColor: Colors.white, //<-- SEE HERE
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  ' A carregar informação...  ',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Color(0xFFEDBD1D),
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                )
              ],
            )));
  }
}
