import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:draggable_bottom_sheet_nullsafety/draggable_bottom_sheet_nullsafety.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:vambora_passageiro/pages/AvaliarPage.dart';
import 'package:vambora_passageiro/pages/SelectViaturaPage.dart';
import 'package:flutter/cupertino.dart' hide RadioGroup;
import 'package:flutter/material.dart' hide RadioGroup;
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:maps_curved_line/maps_curved_line.dart';
import 'package:panara_dialogs/panara_dialogs.dart';
import 'package:radio_group_v2/utils/radio_group_decoration.dart';
import 'package:radio_group_v2/widgets/view_models/radio_group_controller.dart';
import 'package:radio_group_v2/widgets/views/radio_group.dart';
import 'package:smooth_star_rating_null_safety/smooth_star_rating_null_safety.dart';
import 'package:url_launcher/url_launcher.dart';
import '../config/Constats.dart';
import '../controller/MapController.dart';
import 'package:get/get.dart';
import '../main.dart';
import 'ChatPage.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:geolocator/geolocator.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:material_dialogs/material_dialogs.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';

// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
import 'LocalNotification.dart';
import 'PrincipalPage.dart';
import 'PromocaoPage.dart';
import 'RadarPage.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';

// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'SelectPagamentoPage.dart';
import 'Loading.dart';
import 'SplashPage.dart';
import 'TelaMotivoCancelamento.dart';

var estatus_viagem;
var idViagem;
double desconto = 0.0;
double totalPagar = 0.0;
bool chegada = false;
bool carregarViagem = false;
double string1 = 0.0;
double string2 = 0.0;

class DriverPage extends StatefulWidget {
  @override
  _DriverPage createState() => _DriverPage();
}

class _DriverPage extends State<DriverPage> {
  bool con = false;
  late AnimationController controller;

  Future conexao() async {
    try {
      final result = await InternetAddress.lookup('www.mvconws.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        con = true;
      }
    } on SocketException catch (_) {
      con = false;
    }
    print(con);
  }

  @override
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  final f = NumberFormat("#,##0", "pt_BR");
  NumberFormat formatter = NumberFormat("00.00");
  loading load = loading();

  final controllerMap = Get.put(MapController());
  BitmapDescriptor markerIcon4 = BitmapDescriptor.defaultMarker;
  BitmapDescriptor markerIcon3 = BitmapDescriptor.defaultMarker;
  BitmapDescriptor markerIcon1 = BitmapDescriptor.defaultMarker;
  BitmapDescriptor markerIcon2 = BitmapDescriptor.defaultMarker;

  Future<void> ajustarCamera(LatLng origem, LatLng destino) async {
    final controller = await _controller.future;

    final bounds = LatLngBounds(
      southwest: LatLng(
        origem.latitude < destino.latitude
            ? origem.latitude
            : destino.latitude,
        origem.longitude < destino.longitude
            ? origem.longitude
            : destino.longitude,
      ),
      northeast: LatLng(
        origem.latitude > destino.latitude
            ? origem.latitude
            : destino.latitude,
        origem.longitude > destino.longitude
            ? origem.longitude
            : destino.longitude,
      ),
    );

    controller.animateCamera(CameraUpdate.newLatLngBounds(bounds, 80));
  }

  final Set<Polyline> _polylines = Set();
  final Set<Polyline> _polylines2 = Set();
  final Set<Marker> _markers = Set();

  final CameraPosition _initialLocation =
      CameraPosition(target: LatLng(posicaoV1, posicaoV2), zoom: 16.0);
  late GoogleMapController mapController;

  getCurrentLocation() async {
    await Geolocator.getCurrentPosition().then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(latPosMoto!, longPosMoto!),
        zoom: 16.0,
      )));
    }).catchError((e) async {
      print(e);
    });
  }

  LocationData? currentLocation;

  void pegarCurrentLocation() async {
    Location location = Location();
    location.getLocation().then(
      (location) {
        currentLocation = location;
        setState(() {});
      },
    );
    GoogleMapController googleMapController = await _controller.future;
    location.onLocationChanged.listen((newLoc) {
      currentLocation = newLoc;
      googleMapController.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(
              target: LatLng(latPosMoto!, longPosMoto!), zoom: 16.0)));
    });
    setState(() {});
  }

  Future Carregamento() async {
    await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(load.getFuture()),
    );
  }

  final LatLng _point1 = LatLng(lat1!, long1!);
  final LatLng _point2 = LatLng(lat2!, long2!);

  final LatLng _point3 = LatLng(latPosMoto!, longPosMoto!);
  final LatLng _point4 = LatLng(lat1!, long1!);

  void prepareCurvedPolylines() {
    _polylines.add(Polyline(
      polylineId: const PolylineId("line 1"),
      visible: true,
      width: 5,
      zIndex: 1000,
      geodesic: true,
      patterns: [PatternItem.dash(5), PatternItem.gap(10)],
      points: MapsCurvedLines.getPointsOnCurve(_point1, _point2),
      color: const Color(0xFFEDBD1D),
    ));
  }

  void prepareCurvedPolylines2() {
    _polylines2.add(Polyline(
      polylineId: const PolylineId("line 1"),
      visible: true,
      width: 5,
      zIndex: 1000,
      geodesic: true,
      patterns: [PatternItem.dash(5), PatternItem.gap(10)],
      points: MapsCurvedLines.getPointsOnCurve(_point3, _point4),
      color: const Color(0xFFEDBD1D),
    ));
  }

  LatLng origem = LatLng(posicaoV1, posicaoV2);
  LatLng destino = LatLng(destinoV1, destinoV2);

  void addCustomIcon() {
    BitmapDescriptor.fromAssetImage(
            const ImageConfiguration(), "assets/images/carro_online.png")
        .then(
      (icon) {
        setState(() {
          markerIcon1 = icon;
        });
      },
    );

    BitmapDescriptor.fromAssetImage(
            const ImageConfiguration(), "assets/images/carro_online.png")
        .then(
      (icon) {
        setState(() {
          markerIcon2 = icon;
        });
      },
    );

    BitmapDescriptor.fromAssetImage(
            const ImageConfiguration(), "assets/images/carro_online.png")
        .then(
      (icon) {
        setState(() {
          markerIcon3 = icon;
        });
      },
    );

    BitmapDescriptor.fromAssetImage(
            const ImageConfiguration(), "assets/images/carro_online.png")
        .then(
      (icon) {
        setState(() {
          markerIcon4 = icon;
        });
      },
    );
  }

  void MostrarDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Informe o Motivo do Cancelamento.'),
          titleTextStyle: const TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
          content: _MotivoCancela(),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Cancelar',
                  style: TextStyle(
                    color: Colors.black54,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  )),
            ),
            TextButton(
              onPressed: () => CancelarPedido(),
              child: const Text('Enviar',
                  style: TextStyle(
                    color: Color(0xFFEDBD1D),
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  )),
            )
          ],
        );
      },
    );
  }

  RadioGroupController myMotivo = RadioGroupController();

  Widget _MotivoCancela() {
    return RadioGroup(
      controller: myMotivo,
      values: const [
        "Demora excessiva do motorista para chegar.",
        "Mudança de planos de última hora.",
        "O Motorista exigiu mais dinheiro.",
        "Problemas com a localização do motorista.",
        "O motorita não aceitou a forma de pagamento.",
        "Solicitação feita por engano.",
        "A viatura não oferece segurança Nenhuma.",
        "Outros motivos."
      ],
      indexOfDefault: 0,
      orientation: RadioGroupOrientation.vertical,
      decoration: const RadioGroupDecoration(
        toggleable: true,
        splashRadius: 10,
        spacing: 80.0,
        labelStyle: TextStyle(
          color: Colors.black,
        ),
        activeColor: Color(0xFFEDBD1D),
      ),
    );
  }

  Widget _BtnCancelar() {
    return SizedBox(
      width: 200,
      height: 50,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.red,
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: estado_pedido == "2" || estado_pedido == "3"
            ? () {
                PanaraConfirmDialog.showAnimatedGrow(
                  color: Colors.red,
                  context,
                  title: "Cancelar Viagem",
                  message: "Tem a certeza que deseja cancelar a viagem?",
                  confirmButtonText: "Sim",
                  cancelButtonText: "Não",
                  onTapConfirm: () {
                    Navigator.of(context).pop;
                    // ignore: use_build_context_synchronously
                    CancelarPedido();
                  },
                  onTapCancel: () {
                    Navigator.of(context).pop;
                  },
                  panaraDialogType: PanaraDialogType.warning,
                );
              }
            : () async {
                PanaraConfirmDialog.showAnimatedGrow(
                  color: Colors.red,
                  context,
                  title: "Abandonar Viagem",
                  message: "Tem a certeza que deseja abandonar a viagem?",
                  confirmButtonText: "Sim",
                  cancelButtonText: "Não",
                  onTapConfirm: () async {
                    Navigator.of(context).pop();
                    LocalNotification.showBigTextNotification(
                        title: 'Saída forçada',
                        body:
                            'Ocorreu um erro inesperado que forçou a abandonar a viagem',
                        fln: flutterLocalNotificationsPlugin);
                    estatus_viagem = "0";
                    await SessionManager().set("estatus_viagem", "0");
                    idPedido = "";
                    await SessionManager().set("idPedido", "");
                    valor_estimado = 0.0;
                    await SessionManager().set("valor_estimado", "0.0");
                    await SessionManager().set("taxa_km", "0.0");
                    await SessionManager().set("tarifa_base", "0.0");
                    chegada = false;
                    stopService();
                    _viagemTimer.cancel();
                    // ignore: use_build_context_synchronously
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (context) => SplashPage()));
                  },
                  onTapCancel: () {
                    Navigator.of(context).pop;
                  },
                  panaraDialogType: PanaraDialogType.warning,
                );
              },
        child: estado_pedido == "1" ||
                estado_pedido == "2" ||
                estado_pedido == "3" ||
                estado_pedido == null
            ? const Text(
                '<< Cancelar Viagem >>',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontFamily: 'Gotham',
                    fontWeight: FontWeight.bold),
              )
            : const Text(
                '<< Abandonar Viagem >>',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontFamily: 'Gotham',
                    fontWeight: FontWeight.bold),
              ),
      ),
    );
  }

  Widget _BtnAplicarCupom() {
    return SizedBox(
      width: 200,
      height: 50,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed:
            estado_pedido == "4" || estado_pedido == "5" || estado_pedido == "6"
                ? () {
                    Dialogs.bottomMaterialDialog(
                        msg: 'Tem a certeza que deseja Aplicar o Cupom?',
                        title: 'Aplicar Cupom',
                        context: context,
                        actions: [
                          IconsOutlineButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            text: 'Não',
                            textStyle: const TextStyle(color: Colors.grey),
                            iconColor: Colors.grey,
                          ),
                          IconsButton(
                            onPressed: () async {
                              AplicarCupom();
                              Navigator.of(context).pop();
                            },
                            text: 'Sim',
                            color: const Color(0xFFEDBD1D),
                            textStyle: const TextStyle(color: Colors.white),
                            iconColor: Colors.white,
                          ),
                        ]);
                  }
                : () {},
        child:
            estado_pedido == "4" || estado_pedido == "5" || estado_pedido == "6"
                ? const Text(
                    'Aplicar Cupom',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 13,
                        fontFamily: 'Gotham',
                        fontWeight: FontWeight.bold),
                  )
                : const Text(
                    'Cupom Indisponível',
                    style: TextStyle(
                        color: Colors.grey,
                        fontSize: 13,
                        fontFamily: 'Gotham',
                        fontWeight: FontWeight.bold),
                  ),
      ),
    );
  }

  Widget _TempoEspera() {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            )),
        onPressed: () {},
        child: estado_pedido == "1" ||
                estado_pedido == "2" ||
                estado_pedido == null
            ? Text(
                tempoEspera == null
                    ? "Calculando o tempo de chegada..."
                    : "Chagada em $tempoEspera min.",
                style: const TextStyle(
                    color: Colors.black,
                    fontSize: 14,
                    fontFamily: 'Gotham',
                    fontWeight: FontWeight.bold),
              )
            : estado_pedido == "3"
                ? const Text(
                    'Chegou no local!',
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 14,
                        fontFamily: 'Gotham',
                        fontWeight: FontWeight.bold),
                  )
                : estado_pedido == "5"
                    ? const Text(
                        'Viagem Parada',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontFamily: 'Gotham',
                            fontWeight: FontWeight.bold),
                      )
                    : const Text(
                        'Viagem em Curso',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 14,
                            fontFamily: 'Gotham',
                            fontWeight: FontWeight.bold),
                      ),
      ),
    );
  }

  Widget _BtnSOS() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFFFFFF),
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          _CallSOS();
        },
        child: const Image(
          image: AssetImage("assets/images/sos.png"),
          width: 50,
          height: 50,
        ),
      ),
    );
  }

  Widget _BtnChat() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFFFFFF),
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.of(context).push(CupertinoPageRoute(
              builder: (BuildContext context) => ChatPage()));
        },
        child: const Icon(
          Icons.chat_outlined,
          color: Color(0xFF000000),
          size: 45,
        ),
      ),
    );
  }

  Widget _BtnCall() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFF000000),
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          _Call();
        },
        child: const Icon(
          Icons.call,
          color: Color(0xFF000000),
          size: 45,
        ),
      ),
    );
  }

  Future<void> _Call() async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: contacto_motorista,
    );
    await launchUrl(launchUri);
  }

  Future<void> _CallSOS() async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: '111',
    );
    await launchUrl(launchUri);
  }

  void ActivarViagem() async {
    // service.startService();
    await SessionManager().set("estatus_viagem", 1);
    estatus_viagem = 1;
  }

  void limparDadosViagem() async {
    await SessionManager().set("estatus_viagem", 0);
    await SessionManager().set("idPedido", "");
    estatus_viagem = 0;
    idPedido = "";
  }

  // return jsonDecode(response.body)["message"];

  Future DadosPedido() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/pedido/dados-pedido";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": idPedido.toString(),
      });
      final map = json.decode(response.body);
      final dados = map['pedido'];
      final motorista = map['motorista'];
      final infoMotorista = map['info_motorista'];
      rating_motorista = double.tryParse(map['avaliacao'])!;
      estado_pedido = dados['status'];
      desc_origem_pedido = dados['desc_origem'];
      desc_destino_pedido = dados['desc_destino'];
      posicaoMotorista = infoMotorista['localizacao_actual'];
      origem_viagem = dados['origem'];
      destino_viagem = dados['destino'];
      final nomeMoto = motorista['nome'];
      nome_motorista = "$nomeMoto";
      foto_motorista = motorista['foto'];
      contacto_motorista = motorista['telefone'];
      id_motorista = motorista['id'];
      viatura_motorista = infoMotorista['categoria'];
      matricula_motorista = infoMotorista['matricula'];
      setState(() {
        carregarViagem = true;
      });
    } catch (e) {
      print(e);
    }
  }

  Future EstadoPedido() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/pedido/dados-pedido";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": idPedido.toString(),
      });
      final map = json.decode(response.body);
      final dados = map['pedido'];
      setState(() {
        estado_pedido = dados['status'];
      });
    } catch (e) {
      print(e);
    }
  }

  void LatLong() {
    lat1 = double.tryParse(origem_viagem.toString().split(',')[0]);
    long1 = double.tryParse(origem_viagem.toString().split(',')[1]);
    lat2 = double.tryParse(destino_viagem.toString().split(',')[0]);
    long2 = double.tryParse(destino_viagem.toString().split(',')[1]);
    latPosMoto = double.tryParse(posicaoMotorista.toString().split(',')[0]);
    longPosMoto = double.tryParse(posicaoMotorista.toString().split(',')[1]);
  }

  Future CancelarPedido() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/pedido/cancelar');
      var response = await http.post(url, body: {
        "passageiro": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": idPedido.toString(),
       // "motivo": myMotivo.value.toString(),
      });
      final map = json.decode(response.body);
      setState(() async {
        final msgr = map["retorno"];
        if (msgr == 1) {
          stopService();
          _viagemTimer.cancel();
          _viagemTimer2.cancel();
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => const TelaMotivoCancelamento()),
                (route) => false,
          );
        }
      });
    } catch (e) {}
  }

  Future InfoViagem() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/viagem/ver-dados');
      var response = await http.post(url, body: {
        "pedido": idPedido.toString(),
      });
      final map = json.decode(response.body);
      final DadosPagamento = map["pagamento"];
      final Dadosviagem = map["viagem"];
      setState(() {
        idViagem = Dadosviagem["id"];
        totalPagar = double.parse(DadosPagamento["valor"]);
      });
    } catch (e) {
      print(e);
    }
  }

  void VerificarPedido() async {
    if (estado_pedido == "8") {
      stopService();
      await SessionManager().set("valor_estimado", "0.0");
      await SessionManager().set("taxa_km", "0.0");
      await SessionManager().set("tarifa_base", "0.0");
      _viagemTimer.cancel();
      _viagemTimer2.cancel();
      // ignore: use_build_context_synchronously
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => AvaliarPage()));
    } else if (estado_pedido == "0") {
      stopService();
      // Notificar cancelamento
      LocalNotification.showBigTextNotification(
          title: 'Viagem Cancelada',
          body: 'A sua viagem foi cancelada pelo Motorista',
          fln: flutterLocalNotificationsPlugin);
      estatus_viagem = "0";
      await SessionManager().set("estatus_viagem", "0");
      idPedido = "";
      await SessionManager().set("idPedido", "");
      valor_estimado = 0.0;
      await SessionManager().set("valor_estimado", "0.0");
      await SessionManager().set("taxa_km", "0.0");
      await SessionManager().set("tarifa_base", "0.0");
      chegada = false;
      _viagemTimer.cancel();
      _viagemTimer2.cancel();
      // ignore: use_build_context_synchronously
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => SplashPage()));
    } else if (estado_pedido == "3" && chegada == false) {
      chegada = true;
      LocalNotification.showBigTextNotification(
        title: 'O Motorista chegou',
        body: 'Fique no local combinado.',
        fln: flutterLocalNotificationsPlugin,
      );
    } else if (estado_pedido == "4") {
      InfoViagem();
      // VerificarCupom();
    } else {}
  }

  Future VerificarCupom() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/viagem/verificar-cupom');
      var response = await http.post(url, body: {
        "cupom": CodigoCupom.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final valor = map["desconto"];
      if (msgr == 1) {
        //  AplicarCupom();
      } else {}
    } catch (e) {
      print(e);
    }
  }

  Future AplicarCupom() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/viagem/aplicar-cupom');
      var response = await http.post(url, body: {
        "cupom": CodigoCupom.toString(),
        "viagem": idViagem.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        // ignore: use_build_context_synchronously
        showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Cupom aplicado com sucesso.',
          ),
        );
        setState(() async {
          CodigoCupom = "";
          ValorCupom = "";
          await SessionManager().set("CodigoCupom", "");
          await SessionManager().set("ValorCupom", "");
        });
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.info(
            message: 'Não foi possível aplicar o Cupom.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        // ignore: use_build_context_synchronously
        Overlay.of(context),
        const CustomSnackBar.error(
          message: 'Ops! Ocorreu um erro ao aplicar o Cupom.',
        ),
      );
      print(e);
    }
  }

  Future verificarSMS() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/chat/notificacao";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      var msgRotor = map["retorno"];
      if (msgRotor == 1) {
        LocalNotification.showBigTextNotification(
            title: 'Nova Mensagem do Motorista',
            body: 'Abrir conversa no Chat',
            fln: flutterLocalNotificationsPlugin,
            // ignore: use_build_context_synchronously
            payload: Navigator.of(context).push(CupertinoPageRoute(
                builder: (BuildContext context) => ChatPage())));
      }
      abrirSMS();
      // ignore: use_build_context_synchronously
    } catch (e) {}
  }

  Future abrirSMS() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/chat/abrir-msg";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      var msgChat = map["mensagens"];
      // print(msgChat);
    } catch (e) {
      print(e);
    }
  }

  Future CalcularTempo() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/motoristaonlinemaisproximo');
      var response = await http.post(url, body: {
        "localizacao_passageiro": posicaoMotorista.toString(),
      });
      final map = json.decode(response.body);
      setState(() {
        tempoEspera = map["tempo"];
        print("motorista-mais-proximo");
        print(viatura_proxima);
      });
    } catch (e) {
      print(e);
    }
  }

  late Timer _viagemTimer;
  late Timer _viagemTimer2;

  List<LatLng> polylineCoordinates = [];


  List<LatLng> polylineCoordinates2 = [];



  /* Future<String> _getGeolocation() async {
    String posicao = await Future.delayed(const Duration(seconds: 2), (() {
      return posicaoMotorista;
    }));
    return posicao;
  }*/

  Future<String> _getGeolocation() async {
    String posicao = posicaoMotorista;
    return posicao;
  }

  void stopService() {
    FlutterForegroundTask.stopService();
  }

  @override
  void initState() {
    conexao();
    viagem = true;
    DadosPedido();
    LatLong();
    ActivarViagem();
    addCustomIcon();
    getCurrentLocation();
    pegarCurrentLocation();
    CalcularTempo();
    _viagemTimer = Timer.periodic(const Duration(seconds: 4), (Timer t) {
      conexao();
      if (con == true) {
        DadosPedido();
        LatLong();
        verificarSMS();
        EstadoPedido();
        VerificarPedido();
        // addCustomIcon();
      } else {}
    });
    _viagemTimer2 = Timer.periodic(const Duration(seconds: 15), (Timer t) {
      if (estado_pedido == "2") {
        CalcularTempo();
      } else {
        _viagemTimer2.cancel();
      }
    });
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'Gotham'),
      home: FutureBuilder(
          future: _getGeolocation(),
          builder: (context, snapshot) {
            if (snapshot.data == null || snapshot.data == "") {
              return const Scaffold(
                  body: Center(
                      child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text("",
                      style: TextStyle(
                          color: Colors.black,
                          fontFamily: 'gotham',
                          fontSize: 20,
                          fontWeight: FontWeight.bold)),
                  SizedBox(
                    height: 10,
                  ),
                ],
              )));
            } else {
              if (snapshot.hasData && !snapshot.hasError) {
                string1 =
                    double.tryParse(snapshot.data.toString().split(',')[0])!;
                string2 =
                    double.tryParse(snapshot.data.toString().split(',')[1])!;
                return Scaffold(
                  body: carregarViagem == false
                      ? const Center(
                          child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text("Só mais um momento.",
                                style: TextStyle(
                                    color: Colors.black,
                                    fontFamily: 'gotham',
                                    fontSize: 20,
                                    fontWeight: FontWeight.bold)),
                            SizedBox(
                              height: 10,
                            ),
                            Text("Estamos a carregar a sua viagem...",
                                style: TextStyle(
                                    color: Colors.black,
                                    fontFamily: 'gotham',
                                    fontSize: 14,
                                    fontWeight: FontWeight.normal)),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            CircularProgressIndicator(
                              backgroundColor: Colors.white,
                              valueColor: AlwaysStoppedAnimation<Color>(
                                  Color(0xFFEDBD1D)),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                          ],
                        ))
                      : Stack(
                          children: [
                            DraggableBottomSheet(
                              backgroundWidget: estado_pedido == "2"
                                  ? GoogleMap(
                                      markers: {
                                        Marker(
                                            markerId:
                                                const MarkerId("MotoLocation"),
                                            position: LatLng(string1, string2),
                                            icon: markerIcon2)
                                      },
                                      polylines: _polylines2,
                                      mapType: MapType.normal,
                                      initialCameraPosition: _initialLocation,
                                      myLocationEnabled: true,
                                      myLocationButtonEnabled: false,
                                      zoomGesturesEnabled: true,
                                      zoomControlsEnabled: false,
                                      onMapCreated: (GoogleMapController
                                          controller) async {
                                        _controller.complete(controller);
                                      },
                                    )
                                  :GoogleMap(
                                      markers: {
                                        Marker(
                                            markerId:
                                                const MarkerId("MotoLocation"),
                                            position: LatLng(string1, string2),
                                            icon: markerIcon2)
                                      },
                                     // polylines: _polylines,
                                      mapType: MapType.normal,
                                      initialCameraPosition: _initialLocation,
                                      myLocationEnabled: true,
                                      myLocationButtonEnabled: false,
                                      zoomGesturesEnabled: true,
                                      zoomControlsEnabled: false,
                                      onMapCreated: (GoogleMapController
                                          controller) async {
                                        _controller.complete(controller);
                                        ajustarCamera(origem, destino);

                                      },
                                    ),
                              previewChild: Container(
                                padding: const EdgeInsets.all(16),
                                decoration: const BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      Color(0xFFEDBD1D),
                                      Color(0xFFEDBD1D),
                                    ],
                                  ),
                                  //color: Color(0xFF00008B),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(15),
                                    topRight: Radius.circular(15),
                                  ),
                                ),
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      width: 40,
                                      height: 6,
                                      decoration: BoxDecoration(
                                        gradient: const LinearGradient(
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter,
                                          colors: [
                                            Color(0xFF000000),
                                            Color(0xFF000000),
                                          ],
                                        ),
                                        // color: Colors.white,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "$marca_viatura-$modelo_viatura "
                                              .toUpperCase(),
                                          style: const TextStyle(
                                              fontFamily: "Gotham",
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold,
                                              color: Color(0xFF000000)),
                                        ),
                                       /* Text(
                                          "$cor_viatura"
                                              .toUpperCase(),
                                          style: const TextStyle(
                                              fontFamily: "Gotham",
                                              fontSize: 12,
                                              fontWeight: FontWeight.bold,
                                              color: Color(0xFF000000)),
                                        ),*/
                                        Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    width: 2,
                                                    color: Colors.black),
                                                borderRadius:
                                                    const BorderRadius.all(
                                                        Radius.circular(5))),
                                            width: 150,
                                            height: 35,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "$matricula_motorista"
                                                      .toUpperCase(),
                                                  style: const TextStyle(
                                                      fontFamily: "Gotham",
                                                      fontSize: 18,
                                                      color: Color(0xFF000000)),
                                                ),
                                              ],
                                            ))
                                      ],
                                    ),
                                    const Divider(
                                      height: 30,
                                      color: Color(0xFF000000),
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    width: 0,
                                                    color: const Color(
                                                        0xFFEDBD1D))),
                                            width: 120,
                                            height: 120,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                CircleAvatar(
                                                  radius: 30,
                                                  backgroundImage: foto_motorista ==
                                                          null
                                                      ? Image.asset(
                                                              'assets/images/nofoto.png')
                                                          .image
                                                      : Image.network(urlImagem +
                                                              foto_motorista)
                                                          .image,
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                Text(
                                                  nome_motorista.toUpperCase(),
                                                  style: const TextStyle(
                                                    color: Color(0xFF000000),
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                    fontFamily: 'gotham',
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 5,
                                                ),
                                                SmoothStarRating(
                                                  rating:
                                                      rating_motorista ?? 0.0,
                                                  size: 12,
                                                  filledIconData: Icons.star,
                                                  halfFilledIconData:
                                                      Icons.star_half,
                                                  defaultIconData:
                                                      Icons.star_border,
                                                  color: Colors.black,
                                                  borderColor:
                                                      const Color(0xFF000000),
                                                  starCount: 5,
                                                  allowHalfRating: false,
                                                  spacing: 0.0,
                                                ),
                                              ],
                                            )),
                                        Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    width: 0,
                                                    color: const Color(
                                                        0xFFEDBD1D))),
                                            width: 120,
                                            height: 120,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                _BtnChat(),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                const Text(
                                                  "Chat",
                                                  style: TextStyle(
                                                    color: Color(0xFF000000),
                                                    fontSize: 12.0,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                    fontFamily: 'gotham',
                                                  ),
                                                ),
                                              ],
                                            )),
                                        Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    width: 0,
                                                    color: const Color(
                                                        0xFFEDBD1D))),
                                            width: 120,
                                            height: 120,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                _BtnSOS(),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                const Text("SOS",
                                                    style: TextStyle(
                                                      color: Color(0xFF000000),
                                                      fontSize: 12.0,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      fontFamily: 'gotham',
                                                    )),
                                              ],
                                            ))
                                      ],
                                    ),
                                    const SizedBox(
                                      height: 20,
                                    ),
                                  ],
                                ),
                              ),
                              expandedChild: Container(
                                padding: const EdgeInsets.all(16),
                                decoration: const BoxDecoration(
                                  color: Color(0xFFEDBD1D),
                                  borderRadius: BorderRadius.only(
                                    topLeft: Radius.circular(15),
                                    topRight: Radius.circular(15),
                                  ),
                                ),
                                child: Column(
                                  children: <Widget>[
                                    Container(
                                      width: 40,
                                      height: 6,
                                      decoration: BoxDecoration(
                                        gradient: const LinearGradient(
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter,
                                          colors: [
                                            Color(0xFF000000),
                                            Color(0xFF000000),
                                          ],
                                        ),
                                        // color: Colors.white,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          "$marca_viatura-$modelo_viatura"
                                              .toUpperCase(),
                                          style: const TextStyle(
                                              fontFamily: "Gotham",
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: Color(0xFF000000)),
                                        ),
                                        Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    width: 2,
                                                    color: Colors.black),
                                                borderRadius:
                                                    const BorderRadius.all(
                                                        Radius.circular(5))),
                                            width: 150,
                                            height: 40,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                Text(
                                                  "$matricula_motorista"
                                                      .toUpperCase(),
                                                  style: const TextStyle(
                                                      fontFamily: "Gotham",
                                                      fontSize: 18,
                                                      color: Color(0xFF000000)),
                                                ),
                                              ],
                                            ))
                                      ],
                                    ),
                                    const Divider(
                                      height: 30,
                                      color: Color(0xFF000000),
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    width: 0,
                                                    color: const Color(
                                                        0xFFEDBD1D))),
                                            width: 120,
                                            height: 120,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                CircleAvatar(
                                                  radius: 30,
                                                  backgroundImage: foto_motorista ==
                                                          null
                                                      ? Image.asset(
                                                              'assets/images/nofoto.png')
                                                          .image
                                                      : Image.network(urlImagem +
                                                              foto_motorista)
                                                          .image,
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                Text(
                                                  nome_motorista.toUpperCase(),
                                                  style: const TextStyle(
                                                    color: Color(0xFF000000),
                                                    fontSize: 14.0,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                    fontFamily: 'gotham',
                                                  ),
                                                ),
                                                const SizedBox(
                                                  height: 5,
                                                ),
                                                SmoothStarRating(
                                                  rating:
                                                      rating_motorista ?? 0.0,
                                                  size: 12,
                                                  filledIconData: Icons.star,
                                                  halfFilledIconData:
                                                      Icons.star_half,
                                                  defaultIconData:
                                                      Icons.star_border,
                                                  color: Colors.red,
                                                  borderColor:
                                                      const Color(0xFF000000),
                                                  starCount: 5,
                                                  allowHalfRating: false,
                                                  spacing: 0.0,
                                                ),
                                              ],
                                            )),
                                        Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    width: 0,
                                                    color: const Color(
                                                        0xFFEDBD1D))),
                                            width: 120,
                                            height: 120,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                _BtnChat(),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                const Text(
                                                  "Chat",
                                                  style: TextStyle(
                                                    color: Color(0xFF000000),
                                                    fontSize: 12.0,
                                                    fontWeight:
                                                        FontWeight.normal,
                                                    fontFamily: 'gotham',
                                                  ),
                                                ),
                                              ],
                                            )),
                                        Container(
                                            decoration: BoxDecoration(
                                                border: Border.all(
                                                    width: 0,
                                                    color: const Color(
                                                        0xFFEDBD1D))),
                                            width: 120,
                                            height: 120,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.center,
                                              children: [
                                                _BtnSOS(),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                const Text("SOS",
                                                    style: TextStyle(
                                                      color: Color(0xFF000000),
                                                      fontSize: 12.0,
                                                      fontWeight:
                                                          FontWeight.normal,
                                                      fontFamily: 'gotham',
                                                    )),
                                              ],
                                            ))
                                      ],
                                    ),
                                    const Divider(
                                      height: 30,
                                      color: Color(0xFF000000),
                                    ),
                                    Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        const Text(
                                          "Minha Rota",
                                          style: TextStyle(
                                              fontFamily: "Gotham",
                                              fontSize: 20,
                                              fontWeight: FontWeight.bold,
                                              color: Color(0xFF000000)),
                                        ),
                                        ListTile(
                                          onTap: () {},
                                          leading: const Icon(Icons.gps_fixed,
                                              size: 20,
                                              color: Color(0xFF000000)),
                                          title: Text(
                                            desc_origem_pedido,
                                            style: const TextStyle(
                                              color: Color(0xFF000000),
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                              fontFamily: 'gotham',
                                            ),
                                          ),
                                        ),
                                        const SizedBox(
                                          height: 5,
                                        ),
                                        ListTile(
                                          onTap: () {},
                                          leading: const Icon(
                                              Icons.album_outlined,
                                              size: 20,
                                              color: Color(0xFF000000)),
                                          title: Text(
                                            desc_destino_pedido,
                                            style: const TextStyle(
                                              color: Color(0xFF000000),
                                              fontSize: 14.0,
                                              fontWeight: FontWeight.normal,
                                              fontFamily: 'gotham',
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    const Divider(
                                      height: 30,
                                      color: Color(0xFF000000),
                                    ),
                                    Column(
                                      mainAxisAlignment:
                                          MainAxisAlignment.start,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const SizedBox(
                                          height: 10,
                                        ),
                                        ListTile(
                                          title: Text(
                                            metodo_pagamento.toUpperCase(),
                                            style: const TextStyle(
                                              color: Color(0xFF000000),
                                              fontSize: 20.0,
                                              fontWeight: FontWeight.normal,
                                              fontFamily: 'gotham',
                                            ),
                                          ),
                                          trailing: valor_estimado == null
                                              ? const Text(
                                                  '0.0',
                                                  style: TextStyle(
                                                      fontFamily: "Gotham",
                                                      fontSize: 30,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Color(0xFF000000)),
                                                )
                                              : Text(
                                                  "${f.format(valor_estimado).toString()} Kz",
                                                  style: const TextStyle(
                                                      fontFamily: "Gotham",
                                                      fontSize: 30,
                                                      fontWeight:
                                                          FontWeight.bold,
                                                      color: Color(0xFF000000)),
                                                ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height:30),
                                    SizedBox(
                                      child: CodigoCupom == ""
                                          ? Column(
                                              children: [
                                                _BtnCancelar(),
                                              ],
                                            )
                                          : Column(
                                              children: [
                                                _BtnCancelar(),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                _BtnAplicarCupom(),
                                              ],
                                            ),
                                    ),
                                  ],
                                ),
                              ),
                              minExtent:
                                  MediaQuery.of(context).size.height * 0.3,
                              blurBackground: false,
                              maxExtent:
                                  MediaQuery.of(context).size.height * 0.8,
                            ),
                            SafeArea(
                                child: Padding(
                              padding: const EdgeInsets.only(
                                  top: 10, left: 5, right: 5),
                              child: Column(
                                children: [
                                  _TempoEspera(),
                                ],
                              ),
                            )),
                          ],
                        ),
                );
              } else {
                return const Scaffold(
                    body: Center(
                        child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text("Aguarde um momento.",
                        style: TextStyle(
                            color: Colors.black,
                            fontFamily: 'gotham',
                            fontSize: 20,
                            fontWeight: FontWeight.bold)),
                    SizedBox(
                      height: 10,
                    ),
                    Text("Carregando dados...",
                        style: TextStyle(
                            color: Colors.black,
                            fontFamily: 'gotham',
                            fontSize: 14,
                            fontWeight: FontWeight.normal)),
                    SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    CircularProgressIndicator.adaptive(
                      backgroundColor: Colors.white,
                      valueColor:
                          AlwaysStoppedAnimation<Color>(Color(0xFFEDBD1D)),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                )));
              }
            }
          }),
    );
  }
}
