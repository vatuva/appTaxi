import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// ignore: depend_on_referenced_packages

// ignore: depend_on_referenced_packages

// ignore: depend_on_referenced_packages
import 'package:circular_image/circular_image.dart';
import 'package:flutter/material.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import 'package:material_dialogs/material_dialogs.dart';

class DocumentosPage extends StatefulWidget {
  @override
  _DocumentosPage createState() => _DocumentosPage();
}

class _DocumentosPage extends State<DocumentosPage> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();

  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.black54,
            elevation: 5,
            padding: const EdgeInsets.all(5),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(5),
            )),
        onPressed: () {

        },
        child: const Text(
          'Salvar',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
        ),
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Center(
              child: CircularImage(
                  radius: 50,
                  borderWidth: 4,
                  borderColor: Colors.black12,
                  source: 'assets/images/nofoto.png'),
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: const Color(0xFaeb2b5),
              ),
              height:70,
              width: MediaQuery.of(context).size.width / 1.5,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Bilhete de Identidade',
                    style: TextStyle(
                      color: Colors.black87,
                      letterSpacing: 0,
                      fontSize: 14.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'gotham',
                    ),
                  ),

                  IconButton(
                      onPressed: () {
                        Dialogs.bottomMaterialDialog(
                            msg: 'Carregar Bilhete de Identidade',
                            title: 'Carregar documento',
                            context: context,
                            actions: [
                              IconsOutlineButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                text: 'Câmera',
                                iconData: Icons.camera_alt,
                                color: const Color(0xFFb21414),
                                textStyle: const TextStyle(color: Colors.white),
                                iconColor: Colors.white,
                              ),
                              IconsButton(
                                onPressed: () {
                                },
                                text: 'Galeria',
                                iconData: Icons.image,
                                color: const Color(0xFFb21414),
                                textStyle: const TextStyle(color: Colors.white),
                                iconColor: Colors.white,
                              ),
                            ]);

                      }, icon: const Icon(Icons.add_a_photo))
                ],
              ),
            ),
            Center(
              child: CircularImage(
                  radius: 50,
                  borderWidth: 4,
                  borderColor: Colors.black12,
                  source: 'assets/images/nofoto.png'),
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: const Color(0xFaeb2b5),
              ),
              height:70,
              width: MediaQuery.of(context).size.width / 1.5,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Carta de Condução',
                    style: TextStyle(
                      color: Colors.black87,
                      letterSpacing: 0,
                      fontSize: 14.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'gotham',
                    ),
                  ),
                  IconButton(
                      onPressed: () {
                        Dialogs.bottomMaterialDialog(
                            msg: 'Carregar Carta de Condução',
                            title: 'Carregar documento',
                            context: context,
                            actions: [
                              IconsOutlineButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                text: 'Câmera',
                                iconData: Icons.camera_alt,
                                color: const Color(0xFFb21414),
                                textStyle: const TextStyle(color: Colors.white),
                                iconColor: Colors.white,
                              ),
                              IconsButton(
                                onPressed: () {
                                },
                                text: 'Galeria',
                                iconData: Icons.image,
                                color: const Color(0xFFb21414),
                                textStyle: const TextStyle(color: Colors.white),
                                iconColor: Colors.white,
                              ),
                            ]);

                      }, icon: const Icon(Icons.add_a_photo))
                ],
              ),
            ),
            Center(
              child: CircularImage(
                  radius: 50,
                  borderWidth: 4,
                  borderColor: Colors.black12,
                  source: 'assets/images/nofoto.png'),
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: const Color(0xFaeb2b5),
              ),
              height:70,
              width: MediaQuery.of(context).size.width / 1.5,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Livrete',
                    style: TextStyle(
                      color: Colors.black87,
                      letterSpacing: 0,
                      fontSize: 14.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'gotham',
                    ),
                  ),

                  IconButton(
                      onPressed: () {
                        Dialogs.bottomMaterialDialog(
                            msg: 'Carregar Livrete',
                            title: 'Carregar documento',
                            context: context,
                            actions: [
                              IconsOutlineButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                text: 'Câmera',
                                iconData: Icons.camera_alt,
                                color: const Color(0xFFb21414),
                                textStyle: const TextStyle(color: Colors.white),
                                iconColor: Colors.white,
                              ),
                              IconsButton(
                                onPressed: () {
                                },
                                text: 'Galeria',
                                iconData: Icons.image,
                                color: const Color(0xFFb21414),
                                textStyle: const TextStyle(color: Colors.white),
                                iconColor: Colors.white,
                              ),
                            ]);

                      }, icon: const Icon(Icons.add_a_photo))
                ],
              ),
            ),

            Center(
              child: CircularImage(
                  radius: 50,
                  borderWidth: 4,
                  borderColor: Colors.black12,
                  source: 'assets/images/nofoto.png'),
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: const Color(0xFaeb2b5),
              ),
              height:70,
              width: MediaQuery.of(context).size.width / 1.5,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'Título de Propriedade',
                    style: TextStyle(
                      color: Colors.black87,
                      letterSpacing: 0,
                      fontSize: 14.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'gotham',
                    ),
                  ),

                  IconButton(
                      onPressed: () {
                        Dialogs.bottomMaterialDialog(
                            msg: 'Carregar Título de Propriedade',
                            title: 'Carregar documento',
                            context: context,
                            actions: [
                              IconsOutlineButton(
                                onPressed: () {
                                  Navigator.of(context).pop();
                                },
                                text: 'Câmera',
                                iconData: Icons.camera_alt,
                                color: const Color(0xFFb21414),
                                textStyle: const TextStyle(color: Colors.white),
                                iconColor: Colors.white,
                              ),
                              IconsButton(
                                onPressed: () {
                                },
                                text: 'Galeria',
                                iconData: Icons.image,
                                color: const Color(0xFFb21414),
                                textStyle: const TextStyle(color: Colors.white),
                                iconColor: Colors.white,
                              ),
                            ]);

                      }, icon: const Icon(Icons.add_a_photo))
                ],
              ),
            ),
          ],
        ),
      ),
      appBar: AppBar(
        actionsIconTheme: const IconThemeData(color: Color(0xFFb21414)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFb21414), size: 40),
        actions: const [

        ],
      ),
    );
  }
}
