import 'dart:convert';
import 'dart:io';
import 'package:vambora_passageiro/pages/LoginPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import '../config/Constats.dart';
import 'PrincipalPage.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'Loading.dart';
import 'SplashPage.dart';

class NovaSenhaPage extends StatefulWidget {
  @override
  _NovaSenhaPage createState() => _NovaSenhaPage();
}

class _NovaSenhaPage extends State<NovaSenhaPage> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();
  final globalKey = GlobalKey<FormState>();
  late bool _toggleVisibility = true;
  late bool _toggleVisibility2 = true;
  var seguro = true;

  final TextEditingController _senha = TextEditingController();
  final TextEditingController _senha2 = TextEditingController();

  loading load = loading();

  Future AlterarSenha() async {
    try {
      setState(() {
        btnRg2 = true;
      });
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/reset/passo3');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "novasenha1": _senha.text,
        "novasenha2": _senha2.text,
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        // ignore: use_build_context_synchronously
        await showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Senha resetada com sucesso.',
          ),
        );
        setState(() {
          btnRg2 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (BuildContext context) => LoginPage()));
      } else {
        setState(() {
          btnRg2 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'As senhas digitadas são diferentes.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg2 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        CustomSnackBar.error(
          message:
              'Ops! Ocorreu um erro. Erro $e.',
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: btnRg2 == false
            ? () {
          if (_senha.text == '') {
            showTopSnackBar(
              // ignore: use_build_context_synchronously
              Overlay.of(context),
              const CustomSnackBar.error(
                message:
                'Ops! Por favor, Informe a palavra-passe actual.',
              ),
            );
          } else if (_senha2.text == '') {
            showTopSnackBar(
              // ignore: use_build_context_synchronously
              Overlay.of(context),
              const CustomSnackBar.error(
                message: 'Ops! Por favor, Informe a nova palavra-passe.',
              ),
            );
          } else {
            AlterarSenha();
          }
        }
            : () {},
        child: btnRg1 == false
            ? const Text(
          'Continuar',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.w900,
            fontFamily: 'gotham',
          ),
          textAlign: TextAlign.center,
          overflow: TextOverflow.fade,
          maxLines: 1,
        )
            : const CircularProgressIndicator(
          backgroundColor: Color(0xFFEDBD1D),
          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
        ),
      ),
    );
  }


  Widget _TxtSenha() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 60,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "Nova palavra-passe",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 22,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.lock_outline,
              color: Color(0xFFEDBD1D),
              size: 25,
            ),
            suffixIcon: IconButton(
              onPressed: () {
                setState(() {
                  _toggleVisibility = !_toggleVisibility;
                });
              },
              icon: _toggleVisibility
                  ? const Icon(
                Icons.visibility_off_outlined,
                size: 20,
              )
                  : const Icon(
                Icons.visibility_outlined,
                size: 20,
              ),
              color: const Color(0xFFEDBD1D),
            ),
            validator: FormValidation.requiredTextField,
            controller: _senha,
            obscureText: _toggleVisibility,
          ),
        ));
  }

  Widget _TxtSenha2() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 60,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "Repetir nova palavra-passe",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 22,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.lock_outline,
              color: Color(0xFFEDBD1D),
              size: 25,
            ),
            suffixIcon: IconButton(
              onPressed: () {
                setState(() {
                  _toggleVisibility2 = !_toggleVisibility2;
                });
              },
              icon: _toggleVisibility2
                  ? const Icon(
                Icons.visibility_off_outlined,
                size: 20,
              )
                  : const Icon(
                Icons.visibility_outlined,
                size: 20,
              ),
              color: const Color(0xFFEDBD1D),
            ),
            validator: FormValidation.requiredTextField,
            controller: _senha2,
            obscureText: _toggleVisibility2,
          ),
        ));
  }



  Widget _BtnBack() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFFFFFF),
            elevation: 0,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.of(context).pop();
        },
        child: const Icon(
          CupertinoIcons.arrow_left,
          color: Color(0xFF000000),
          size: 40,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            Positioned(
                left: 0.0,
                top: 0.0,
                width: MediaQuery.of(context).size.width,
                child: FittedBox(
                  alignment: Alignment.center,
                  //fit: BoxFit.fill,
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(0),
                            bottomRight: Radius.circular(0),
                            topLeft: Radius.circular(0),
                            topRight: Radius.circular(0)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Colors.white, Colors.white])),
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.6,
                    margin: const EdgeInsets.all(0),
                  ),
                )),
            Positioned(
                left: 10.0,
                top: 30.0,
                width: 60,
                child: FittedBox(
                  alignment: Alignment.center,
                  //fit: BoxFit.fill,
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(100),
                            bottomRight: Radius.circular(100),
                            topLeft: Radius.circular(100),
                            topRight: Radius.circular(100)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Colors.white, Colors.white])),
                    width: 60,
                    height: 60,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        _BtnBack()
                      ],
                    ),
                  ),
                )),
            Positioned(
                left: 0.0,
                bottom: 0.0,
                width: MediaQuery.of(context).size.width,
                child: FittedBox(
                  alignment: Alignment.center,
                  //fit: BoxFit.fill,
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(0),
                            bottomRight: Radius.circular(0),
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)])),
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.3,
                    margin: const EdgeInsets.all(0),
                    child: const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [

                      ],
                    ),
                  ),
                )),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(20),
                              bottomRight: Radius.circular(20),
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20)),
                          gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)])),
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.50,
                      margin: const EdgeInsets.all(0),
                      child: Container(
                        margin: const EdgeInsets.only(
                            right: 5, top: 50, left: 5, bottom: 5),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text(
                              'Crie a nova palavra-passe',
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: 20.0,
                                fontWeight: FontWeight.normal,
                                fontFamily: 'gotham',
                              ),
                              textAlign: TextAlign.left,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            _TxtSenha(),
                            const SizedBox(
                              height: 7,
                            ),
                            _TxtSenha2(),
                            const SizedBox(
                              height: 15,
                            ),
                            _BtnComecar(),
                            const SizedBox(
                              height: 20,
                            ),
                          ],
                        ),
                      ))
                ],
              ),
            )
          ],
        ));
  }
}
