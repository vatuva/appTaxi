import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
import 'package:flutter/material.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import 'Loading.dart';
import 'PrincipalPage.dart';
import 'package:dropdown_button2/dropdown_button2.dart';

class InfoViaturaPage extends StatefulWidget {
  @override
  _InfoViaturaPage createState() => _InfoViaturaPage();
}

class _InfoViaturaPage extends State<InfoViaturaPage> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();
  loading load = loading();
  String? selectedCategoria;
  final TextEditingController _marca = TextEditingController();
  final TextEditingController _modelo = TextEditingController();
  final TextEditingController _matricula = TextEditingController();
  final TextEditingController _cor = TextEditingController();
  final TextEditingController _livrete = TextEditingController();
  final TextEditingController _titulo = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.black54,
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {

        },
        child: const Text(
          'Salvar',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
        ),
      ),
    );
  }

  List<String> items = [
    'Categoria 1',
    'Categoria 2',
  ];

  Widget _TxtCategoria() {
    return DropdownButtonHideUnderline(
      child: DropdownButton2(
        barrierColor: Colors.black12,
        style: const TextStyle(
          fontFamily: 'Gotham',
          color: Colors.black,
        ),
        isExpanded: true,
        hint: const Text(
          'Categoria',
          style: TextStyle(
            fontSize: 14,
            color: Colors.black,
          ),
        ),
        items: items
            .map((item) => DropdownMenuItem<String>(
          value: item,
          child: Text(
            item,
            style: const TextStyle(
              fontSize: 14,
            ),
          ),
        ))
            .toList(),
        value: selectedCategoria,
        onChanged: (value) {
          setState(() {
            selectedCategoria = value as String;
            print(value);
          });
        },
      ),
    );
  }

  Widget _TxtMarca() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Marca da Viatura",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.car_crash_outlined),
        validator: FormValidation.requiredTextField,
        controller: _marca,
      ),
    );
  }

  Widget _TxtModelo() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Modelo da Viatura",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.car_crash_outlined),
        validator: FormValidation.requiredTextField,
        controller: _modelo,
      ),
    );
  }

  Widget _TxtCor() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Cor da Viatura",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.car_crash_outlined),
        validator: FormValidation.requiredTextField,
        controller: _cor,
      ),
    );
  }

  Widget _TxtMatricula() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Matrícula da Viatura",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.car_crash_outlined),
        validator: FormValidation.requiredTextField,
        controller: _matricula,
      ),
    );
  }

  Widget _TxtLivrete() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Nº. Livrete da Viatura",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.car_crash_outlined),
        validator: FormValidation.requiredTextField,
        controller: _livrete,
      ),
    );
  }

  Widget _TxtTitulo() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Nº. Título da Viatura",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.car_crash_outlined),
        validator: FormValidation.requiredTextField,
        controller: _titulo,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: const Color(0xFaeb2b5),
              ),
              height: 40,
              width: MediaQuery.of(context).size.width / 1.5,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Informação da Viatura',
                    style: TextStyle(
                      color: Colors.black87,
                      letterSpacing: 0,
                      fontSize: 14.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'gotham',
                    ),
                  ),
                ],
              ),
            ),
            const Align(
              alignment: Alignment.center,
            ),
            const SizedBox(
              height: 5,
            ),
            _TxtCategoria(),
            const SizedBox(
              height: 10,
            ),
            _TxtMarca(),
            const SizedBox(
              height: 10,
            ),
            _TxtModelo(),
            const SizedBox(
              height: 10,
            ),
            _TxtCor(),
            const SizedBox(
              height: 10,
            ),
            _TxtMatricula(),
            const SizedBox(
              height: 10,
            ),
            _TxtLivrete(),
            const SizedBox(
              height: 10,
            ),
            _TxtTitulo(),
            const SizedBox(
              height: 20,
            ),
            _BtnComecar(),
          ],
        ),
      ),
      appBar: AppBar(
        actionsIconTheme: const IconThemeData(color: Color(0xFFb21414)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFFb21414), size: 40),
        actions: const [],
      ),
    );
  }
}
