import 'package:vambora_passageiro/pages/TelaRegisto.dart';
import 'package:vambora_passageiro/pages/DriverPage.dart';
import 'package:vambora_passageiro/pages/PrincipalPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

// ignore: depend_on_referenced_packages
import 'package:otp_text_field/otp_field.dart';

// ignore: depend_on_referenced_packages
import 'package:otp_text_field/otp_text_field.dart';

// ignore: depend_on_referenced_packages
import 'package:otp_text_field/style.dart';
import 'package:lite_rolling_switch/lite_rolling_switch.dart';

class ChamadaPage extends StatefulWidget {
  @override
  _ChamadaPage createState() => _ChamadaPage();
}

class _ChamadaPage extends State<ChamadaPage> {
  @override
  void initState() {
    super.initState();
  }

  Widget _BtnRejeitar() {
    return SizedBox(
      width: 50,
      height: 50,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.of(context).pushReplacement(CupertinoPageRoute(
              builder: (BuildContext context) => PrincipalPage()));
        },
        child: const Icon(
          Icons.cancel,
          color: Colors.red,
          size: 50,
        ),
      ),
    );
  }

  Widget _BtnEnviar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: Colors.white,
        ),
        onPressed: () {},
        child: const Text(
          'Reenviar código',
          style: TextStyle(
            color: Colors.black87,
            fontSize: 14.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
        ),
      ),
    );
  }

/*
  final seconds = strDigits(myDuration.inSeconds.remainder(60));
  Text($seconds',
  style: TextStyle(
  fontWeight: FontWeight.bold,
  color: Colors.black,
  fontSize: 50),
  ),
*/
  Widget _BtnAlterar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: Colors.white,
        ),
        onPressed: () {
          Navigator.of(context).pop();
        },
        child: const Text(
          'Corrigir número',
          style: TextStyle(
            color: Colors.black87,
            fontSize: 12.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
        ),
      ),
    );
  }

  Widget _TxtOPT() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 70,
      child: OTPTextField(
        length: 5,
        width: MediaQuery.of(context).size.width,
        fieldWidth: 40,
        style: const TextStyle(
            fontFamily: 'Gotham', fontWeight: FontWeight.bold, fontSize: 20),
        textFieldAlignment: MainAxisAlignment.spaceAround,
        fieldStyle: FieldStyle.underline,
        onCompleted: (pin) {
          print("Completed: $pin");
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFFb21414),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              height: 100,
            ),
            const Align(
              alignment: Alignment.center,
              child: Text(
                'Passageiro Chamando',
                style: TextStyle(
                  color: Colors.white,
                  letterSpacing: 0,
                  fontSize: 15.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham light',
                ),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            CircleAvatar(
              radius: 45,
              backgroundColor: Colors.white,
              child: CircleAvatar(
                radius: 40,
                backgroundImage: Image.asset('assets/images/nofoto.png').image,
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const Text(
              'João Silva',
              style: TextStyle(
                color: Colors.white,
                letterSpacing: 0,
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
                fontFamily: 'gotham',
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const ListTile(
              leading: Icon(Icons.location_on, size: 30, color: Colors.white),
              title: Text(
                "Avenida Brasil",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const ListTile(
              leading: Icon(Icons.flag, size: 30, color: Colors.white),
              title: Text(
                "Avenida Brasil",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const Divider(
              height: 30,
              color: Colors.white,
            ),
            const ListTile(
              leading: Icon(Icons.access_time_filled_rounded,
                  size: 30, color: Colors.white),
              trailing: Icon(Icons.monetization_on_sharp,
                  size: 30, color: Colors.white),
              title: Text(
                "12 Min.",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
              subtitle: Text(
                "1 200 Kz",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 35.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const Divider(
              height: 30,
              color: Colors.white,
            ),
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: LiteRollingSwitch(
                value: false,
                textOn: 'Cancelar',
                textOff: 'Atender',
                colorOn: Colors.red,
                colorOff: Colors.green,
                iconOn: Icons.call_end,
                iconOff: Icons.call,
                width: MediaQuery.of(context).size.width / 2,
                textOffColor: Colors.white,
                textOnColor: Colors.white,
                textSize: 20.0,
                onChanged: (bool state) {
                  if (state == true) {
                    Navigator.of(context).pushReplacement(CupertinoPageRoute(
                        builder: (BuildContext context) => DriverPage()));
                  } else {}
                },
                onTap: (bool state) {
                  if (state == true) {
                    Navigator.of(context).pushReplacement(CupertinoPageRoute(
                        builder: (BuildContext context) => DriverPage()));
                  } else {}
                },
                onDoubleTap: (bool state) {
                  if (state == true) {
                    Navigator.of(context).pushReplacement(CupertinoPageRoute(
                        builder: (BuildContext context) => DriverPage()));
                  } else {}
                },
                onSwipe: (bool state) {
                  if (state == true) {
                    Navigator.of(context).pushReplacement(CupertinoPageRoute(
                        builder: (BuildContext context) => DriverPage()));
                  } else {}
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(
                top: 20,
              ),
              child: _BtnRejeitar(),
            )
          ],
        ));
  }
}
