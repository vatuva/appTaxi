import 'dart:async';
import 'dart:convert';
import 'package:vambora_passageiro/controller/MapController.dart';
import 'package:vambora_passageiro/pages/SelectViaturaPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:uuid/uuid.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import '../config/Constats.dart';
import '../controller/endereco_controller.dart';
import '../modelos/CardPagamentos.dart';
import '../modelos/Endereco_Model.dart';
import 'DefineRotaMapaPage.dart';
import 'package:intl/intl.dart';
import 'PrincipalPage.dart';
import 'lista_enderecos_widget.dart';

double distance_rota = 0.0;
var localRecolha = "Minha Localização";
double distancia_viatura = 0.0;
double calc_distancia_viatura = 0.0;

class DefineRotaPage extends StatefulWidget {
  @override
  _DefineRotaPage createState() => _DefineRotaPage();
}

class _DefineRotaPage extends State<DefineRotaPage> {
  final controllerMap = Get.put(MapController());
  final TextEditingController localController = TextEditingController();
  final TextEditingController destinoController = TextEditingController();
  NumberFormat formatter = NumberFormat("00.00");
  int currentStep = 0;
  final latitude = 0.0.obs;
  final longitude = 0.0.obs;
  DateTime now = DateTime.now();
  var dataActual = DateTime.now().add(const Duration(days: -365));
  var dataActual2 = DateTime.now().add(const Duration(days: 1));

  bool carregadoV = false;

  Widget TxtLocalizacaoActual() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.85,
      height: 50,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black12)),
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        hint: "Minha Localização",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          focusedColor: const Color(0xFFEDBD1D),
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 13,
          fontWeight: FontWeight.w800,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.gps_fixed,
          color: Color(0xFF000000),
          size: 20,
        ),
        suffixIcon: IconButton(
            onPressed: () {
              controllerMap.getPosition();
              controllerMap.getAddress();
              localController.text = "";
            },
            icon: const Icon(
              CupertinoIcons.delete_left_fill,
              size: 20,
              color: Colors.black54,
            )),
        controller: localController,
      ),
    );
  }

  Widget TxtDestino() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.85,
      height: 50,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black12)),
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        hint: "Escolher Destino",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          focusedColor: const Color(0xFFEDBD1D),
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 13,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.search,
          color: Color(0xFF000000),
          size: 20,
        ),
        suffixIcon: IconButton(
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => DefineRotaMapaPage()));
            },
            icon: const Icon(
              CupertinoIcons.map_fill,
              size: 40,
              color: Color(0xFF000000),
            )),
        controller: destinoController,
      ),
    );
  }

  Widget BarraSuperior() {
    return Card(
        elevation: 2,
        child: Container(
            padding: EdgeInsets.zero,
            width: MediaQuery.of(context).size.width,
            height: 150,
            decoration: const BoxDecoration(
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(0),
                  bottomLeft: Radius.circular(5),
                  bottomRight: Radius.circular(5),
                  topRight: Radius.circular(0)),
              color: Color(0xFFFFFFFF),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SafeArea(
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: Column(
                      children: [
                        Column(
                          children: [
                            Row(
                              children: [
                                const Column(
                                  children: [
                                    SizedBox(
                                      width: 10,
                                    )
                                  ],
                                ),
                                Column(
                                  children: [
                                    const Icon(
                                      Icons.circle,
                                      color: Color(0xFF000000),
                                    ),
                                    Container(
                                      width: 2,
                                      height: 30,
                                      color: const Color(0xFF000000),
                                    ),
                                    const Icon(
                                      Icons.album_outlined,
                                      color: Color(0xFF000000),
                                    )
                                  ],
                                ),
                                Column(
                                  children: [
                                    TxtLocalizacaoActual(),
                                    const SizedBox(
                                      height: 8,
                                    ),
                                    TxtDestino(),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            )));
  }

  var uuid = Uuid();
  String _sessionToken = "123456";
  List<dynamic> _placeListOrigem = [];
  List<dynamic> _placeListDestino = [];
  String tipo_endereco = "";

  Future CalculaTempoViatura() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/motoristaonlinemaisproximo');
      var response = await http.post(url, body: {
        "localizacao_passageiro": origem_pedido.toString(),
      });
      final map = json.decode(response.body);
      setState(() {
        viatura_proxima = map["tempo"];
        print("motorista-mais-proximo");
        print(viatura_proxima);
      });
    } catch (e) {
      print(e);
    }
  }

  @override
  void initState() {
    super.initState();
    controllerMap.getPosition();
    controllerMap.getAddress();
    destinoController.addListener(() {
      onChangeDestino();
    });
    localController.addListener(() {
      onChangeOrigem();
    });
  }



  void onChangeDestino() {
    tipo_endereco = "Destino";
    if (_sessionToken == "") {
      setState(() {
        carregadoV = false;
        _sessionToken = uuid.v4();
      });
    }
    getSuggestionDestino(destinoController.text);
  }

  void onChangeOrigem() {
    tipo_endereco = "Origem";
    if (_sessionToken == "") {
      setState(() {
        _sessionToken = uuid.v4();
      });
    }
    getSuggestionOrigem(localController.text);
  }

  Future<List<String>> getSuggestionDestino(String input) async {
    String baseURL =
        "https://api.geoapify.com/v1/geocode/autocomplete?text=$input&apiKey=$Token_Mapbox&countrycode:ao&lang=pt";

    final response = await http.get(Uri.parse(baseURL));
    final data = response.body;
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      final List features = data['features'] ?? [];
      setState(() {
        carregadoV = false;
        _placeListDestino = jsonDecode(response.body.toString())['features'];
      });
      return features.map((e) => e['properties'].toString()).toList();
    } else {
      setState(() {
        carregadoV = true;
      });
      throw Exception("Falha ao carregar dados");
    }
  }

 Future<List<String>> getSuggestionOrigem(String input) async {
    String baseURL =
        "https://api.geoapify.com/v1/geocode/autocomplete?text=$input&apiKey=$Token_Mapbox&countrycode:ao&lang=pt";
    final response = await http.get(Uri.parse(baseURL));
    final data = response.body;
    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      final List features = data['features'] ?? [];
      setState(() {
        carregadoV = false;
        _placeListOrigem = jsonDecode(response.body.toString())['features'];
      });
      return features.map((e) => e['properties'].toString()).toList();
    } else {
      setState(() {
        carregadoV = true;
      });
      throw Exception("Falha ao carregar dados");
    }
  }



  CalculaViagem(double Latorigem, double Longorigem, double Latdestino,
      double Longdestino) {
    try {
      distance_rota = Geolocator.distanceBetween(
          posicaoV1, posicaoV2, destinoV1, destinoV2);
      calc_distancia_viatura = distance_rota / 1000;
    } catch (e) {
      print(e);
    }
  }

  Future<void> PegarLatLng(String Tipo) async {
    try {
      if (Tipo == "Destino") {
        destino_pedido = "$destinoV1,$destinoV2";
        distance_rota = Geolocator.distanceBetween(
            posicaoV1, posicaoV2, destinoV1, destinoV2);
        calc_distancia_viatura = distance_rota / 1000;
        CalculaTempoViatura();
        // ignore: use_build_context_synchronously
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => SelectViaturaPage()));
      } else {
        posicaoV1 = destinoV1;
        posicaoV2 = destinoV2;
        origem_pedido = "$destinoV1,$destinoV2";
      }
      print("distance");
      print(distance_rota / 1000);
    } catch (e) {
      showTopSnackBar(
        // ignore: use_build_context_synchronously
        Overlay.of(context),
        const CustomSnackBar.error(
          message: "Ops! Ocorreu um erro ao selecionar a rota",
        ),
      );
      print(e);
    }
  }

  Widget buildListaOrigem() {
    if ( localController.text == "") {
      return FutureBuilder<List<EnderecoModel>>(
        future: controller.obterHistorico("Origem"),
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const SizedBox();
          }return ListaEnderecosWidget(
            icon: Icons.history,
            enderecos: snapshot.data!,
            onTap: (item) {
              destinoV1 = item.lat;
              destinoV2 = item.lon;
              desc_origem_pedido = item.formatted;
              localController.text = item.formatted;
              PegarLatLng("Origem");
            },
          );
        },
      );
    } else {
      return ListView.separated(
          separatorBuilder: (context, index) =>
          const Divider(
            height: 2.0,
          ),
          itemCount: _placeListOrigem.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Text(
                _placeListOrigem[index]
                ['properties']['formatted'],
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: const TextStyle(
                  color: Colors.black87,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              leading: const Icon(Icons.location_on),
              subtitle: Text(
                _placeListOrigem[index]
                ['properties']
                ['address_line1']
                    .toString(),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: const TextStyle(
                  color: Colors.black54,
                  fontWeight: FontWeight.normal,
                  fontSize: 11,
                ),
              ),
              onTap: () async{
                  destinoV1 = _placeListOrigem[index]
                  ['properties']['lat'];
                  destinoV2 = _placeListOrigem[index]
                  ['properties']['lon'];
                  desc_origem_pedido =
                  _placeListOrigem[index]
                  ['properties']['formatted'];
                  localController.text =
                  _placeListOrigem[index]
                  ['properties']['formatted'];
                  // 1. Guarda no histórico
                  final endereco = EnderecoModel(
                    formatted: _placeListOrigem[index]['properties']['formatted'],
                    addressLine:
                    _placeListOrigem[index]['properties']['address_line1'],
                    lat: _placeListOrigem[index]['properties']['lat'],
                    lon: _placeListOrigem[index]['properties']['lon'],
                  );
                  await controller.salvarEndereco("Origem", endereco);
                  PegarLatLng("Origem");
                },
            );
          });// ListView acima
    }
  }

  Widget buildListaDestino() {
    if (destinoController.text == "") {
      return FutureBuilder<List<EnderecoModel>>(
        future: controller.obterHistorico("Destino"),
        builder: (context, snapshot) {
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const SizedBox();
          }return ListaEnderecosWidget(
            icon: Icons.history_sharp,
            enderecos: snapshot.data!,
            onTap:(item) {
              destinoV1 = item.lat;
              destinoV2 = item.lon;
              desc_destino_pedido = item.formatted;
              destinoController.text = item.formatted;
              PegarLatLng("Destino");
            },
          );
        },
      );
    } else {
      return ListView.separated(
          separatorBuilder: (context, index) =>
          const Divider(
            height: 2.0,
          ),
          itemCount: _placeListDestino.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Text(
                _placeListDestino[index]
                ['properties']['formatted'],
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: const TextStyle(
                  color: Colors.black87,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
              leading: const Icon(Icons.location_on),
              subtitle: Text(
                _placeListDestino[index]
                ['properties']
                ['address_line1']
                    .toString(),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
                style: const TextStyle(
                  color: Colors.black54,
                  fontWeight: FontWeight.normal,
                  fontSize: 11,
                ),
              ),
              onTap: () async{
                  destinoV1 = _placeListDestino[index]
                  ['properties']['lat'];
                  destinoV2 = _placeListDestino[index]
                  ['properties']['lon'];
                  desc_destino_pedido =
                  _placeListDestino[index]
                  ['properties']['formatted'];
                  destinoController.text = "";
                  destinoController.text =
                  _placeListDestino[index]
                  ['properties']['formatted'];
                  // 1. Guarda no histórico
                  final endereco = EnderecoModel(
                    formatted: _placeListDestino[index]['properties']['formatted'],
                    addressLine:
                    _placeListDestino[index]['properties']['address_line1'],
                    lat: _placeListDestino[index]['properties']['lat'],
                    lon: _placeListDestino[index]['properties']['lon'],
                  );
                  await controller.salvarEndereco("Destino", endereco);
                  PegarLatLng("Destino");
              },
            );
          });// ListView acima
    }
  }


  @override
  void dispose() {
    super.dispose();
  }
  final controller = EnderecoController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          BarraSuperior(),
          const Divider(
            height: 2,
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                  padding: const EdgeInsets.only(
                      right: 20, bottom: 10, top: 150, left: 20),
                  child: Column(
                    children: [
                      // Sugestoes de locais
                      Expanded(
                          child:tipo_endereco == "Origem"
                              ? buildListaOrigem():buildListaDestino(),)
                    ],
                  )),
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "A Sua Rota",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFFEDBD1D),
        elevation: 5,
        iconTheme: const IconThemeData(color: Colors.white, size: 40),
      ),
    );
  }
}
