// ignore_for_file: use_build_context_synchronously
import 'dart:io';

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'LoginPage.dart';
import 'TelaRegisto.dart';


class IniciarPage extends StatefulWidget {
  @override
  _IniciarPage createState() => _IniciarPage();
}

class _IniciarPage extends State<IniciarPage> {
  late LocationPermission permission;
  late bool activado;

  @override
  void initState() {
    super.initState();
  }

  Future<Position> posicaoActual() async {
    activado = await Geolocator.isLocationServiceEnabled();
    if (!activado) {
      return Future.error('Por favor, habilite a sua localização');
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      return Future.error('Você precisa autorizar o acesso à localização');
    }
    Navigator.of(context).pushReplacement(CupertinoPageRoute(
        builder: (BuildContext context) => LoginPage()));
    return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best);
  }

  Future<void> _SolicitarPermissao() async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // user must tap button!
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Política de Privacidade'),
          content: const SingleChildScrollView(
            child: ListBody(
              children: <Widget>[
                Center(
                  child: Text(
                      'Melhore a sua experiência de viagem com informações de Localização!',
                      overflow: TextOverflow.visible,
                      maxLines: 2,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 18.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'gotham',
                      )),
                ),
                SizedBox(height: 10),
                Center(
                  child: Text('Porquê pedimos acesso à sua localização?',
                      overflow: TextOverflow.visible,
                      maxLines: 2,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'gotham',
                      )),
                ),
                SizedBox(height: 10),
                Center(
                  child: Text(
                      "O aplicativo recolhe as suas informações de localização mesmo quando o aplicativo estiver em segundo plano para rastrear a sua posição. Deste modo, permite que o aplicativo lhe atribua o motorista mais próximo e fornece actualizações precisas sobre a chegada do mesmo ao local de recolha.",
                      overflow: TextOverflow.visible,
                      maxLines: 5,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 14.0,
                        fontWeight: FontWeight.normal,
                        fontFamily: 'gotham',
                      )),
                ),
              ],
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Rejeitar'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Aceitar'),
              onPressed: () {
                Navigator.of(context).pop();
                posicaoActual();
              },
            ),
          ],
        );
      },
    );
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
          style: TextButton.styleFrom(
              backgroundColor: const Color(0xFFEDBD1D),
              elevation: 10,
              padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(90),
              )),
          onPressed: () async{
            permission = await Geolocator.checkPermission();
            if (permission == LocationPermission.denied) {
              _SolicitarPermissao();
            } else {
              Navigator.of(context).pushReplacement(CupertinoPageRoute(
                  builder: (BuildContext context) => LoginPage()));
            }
          },
          child: const Text(
            'Vambora',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18.0,
              fontWeight: FontWeight.w900,
              fontFamily: 'gotham',
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.fade,
            maxLines: 1,
          )),
    );
  }

  Widget _BtnRegisto() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
          style: TextButton.styleFrom(
              backgroundColor: const Color(0xFFFFFFFF),
              elevation: 2,
              padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
              shape: RoundedRectangleBorder(
                side: const BorderSide(width: 1, color: Color(0xFFEDBD1D)),
                borderRadius: BorderRadius.circular(90),
              )),
          onPressed: () {
            Navigator.of(context).push(CupertinoPageRoute(
                builder: (BuildContext context) => TelaRegisto()));
          },
          child: const Text(
            'Criar uma conta',
            style: TextStyle(
              color: Color(0xFFEDBD1D),
              fontSize: 18.0,
              fontWeight: FontWeight.w900,
              fontFamily: 'gotham',
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.fade,
            maxLines: 1,
          )),
    );
  }

  final List<String> titleList = [
    'Bem-vindo ao seu novo\n jeito de se locomover!',
    'A sua jornada começa aqui.',
    'Mobilidade na palma da sua mão.',
    'Chegue com conforto, viaje com \ntranquilidade.',
    'Você no controlo do seu trajeto.'
  ];

  final List<String> subtitleList = [
    'Rápido, seguro e prático.\n É só pedir e a corrida começa!',
    'Encontre motoristas confiáveis\n a qualquer hora, em qualquer lugar.',
    'Com poucos toques, você \nchega onde quiser.',
    'A nossa prioridade é o seu \nbem-estar em cada corrida.',
    'Acompanhe tudo em tempo real e \npague como preferir.'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Center(
                    child: Image(
                      image: AssetImage("assets/images/logotipo.png"),
                    ),
                  ),
                  Card(
                      shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(20))),
                      elevation: 0,
                      color: const Color(0xFFFFFFFF),
                      child: Container(
                          decoration: const BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(20),
                                  bottomRight: Radius.circular(20),
                                  topLeft: Radius.circular(20),
                                  topRight: Radius.circular(20)),
                              gradient: LinearGradient(
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                  colors: [
                                    Color(0xFFFFFFFF),
                                    Color(0xFFFFFFFF)
                                  ])),
                          width: MediaQuery.of(context).size.width,
                          height: MediaQuery.of(context).size.height * 0.5,
                          margin: const EdgeInsets.all(0),
                          child: Container(
                            margin: const EdgeInsets.only(
                                right: 5, top: 50, left: 5, bottom: 5),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.end,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                const SizedBox(
                                  height: 15,
                                ),
                                _BtnComecar(),
                                const SizedBox(
                                  height: 10,
                                ),
                                _BtnRegisto(),
                                const SizedBox(
                                  height: 20,
                                ),
                              ],
                            ),
                          )))
                ],
              ),
            )
          ],
        ));
  }
}
