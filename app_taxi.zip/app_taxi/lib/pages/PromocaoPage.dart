import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import '../config/Constats.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'Loading.dart';
import 'SplashPage.dart';

var ValorCupom;
var CodigoCupom = "";

class PromocaoPage extends StatefulWidget {
  @override
  _PromocaoPage createState() => _PromocaoPage();
}

class _PromocaoPage extends State<PromocaoPage> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();

  final TextEditingController _cupom = TextEditingController();

  final globalKey = GlobalKey<FormState>();
  var seguro = true;

  loading load = loading();

  Future Registar() async {
    try {
      setState(() {
        btnRg2 = true;
      });
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/viagem/verificar-cupom');
      var response = await http.post(url, body: {
        "cupom": _cupom.text,
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final valor = map["desconto"];
      if (msgr == 1) {
        setState(() async {
          CodigoCupom = _cupom.text.toString();
          ValorCupom = valor;
          await SessionManager().set("CodigoCupom", CodigoCupom.toString());
          await SessionManager().set("ValorCupom", ValorCupom.toString());
          _cupom.text == '';
        });
        // ignore: use_build_context_synchronously
        await showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Aplicado com sucesso.',
          ),
        );
        setState(() {
          btnRg2 = false;
        });
      } else if (msgr == 0) {
        setState(() {
          btnRg2 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Código Inválido.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg2 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        CustomSnackBar.error(
          message: 'Ops! Ocorreu um erro. Erro $e.',
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
  }

  Widget _BtnAplicar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: btnRg2 == false
            ? () {
                if (_cupom.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message:
                          'Ops! Por favor, Informe o seu Código Promocional.',
                    ),
                  );
                } else {
                  Registar();
                }
              }
            : () {},
        child: btnRg2 == false
            ? const Text(
                'Aplicar Código',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator(
                backgroundColor: Color(0xFFEDBD1D),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  Widget _BtnRemover() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFF0000),
            elevation: 10,
            padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: btnRg2 == false
            ? () {
                setState(() async {
                  _cupom.text == '';
                  btnRg2 = true;
                  CodigoCupom = "";
                  ValorCupom = "";
                  await SessionManager().set("CodigoCupom", "");
                  await SessionManager().set("ValorCupom", "");
                });
                // ignore: use_build_context_synchronously
                showDialog(
                  context: context,
                  builder: (context) => FutureProgressDialog(load.getFuture()),
                );
                showTopSnackBar(
                  // ignore: use_build_context_synchronously
                  Overlay.of(context),
                  const CustomSnackBar.success(
                    message: 'Cupom Removido com sucesso.',
                  ),
                );
                setState(() {
                  btnRg2 = false;
                });
              }
            : () {},
        child: btnRg2 == false
            ? const Text(
                'Remover Código',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator(
                backgroundColor: Color(0xFFFF0000),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  Widget _TxtCupom() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 50,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "Digite o Código",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Color(0xFF000000),
              fontSize: 12,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.local_offer_outlined,
              size: 25,
              color: Color(0xFFEDBD1D),
            ),
            validator: FormValidation.requiredTextField,
            controller: _cupom,
          ),
        ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          SafeArea(
              child: Column(
            children: [
              SingleChildScrollView(
                child: Column(
                  children: [
                    const SizedBox(
                      height: 20,
                    ),
                    _TxtCupom(),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      alignment: Alignment.bottomCenter,
                      child: CodigoCupom == ""
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                _BtnAplicar(),
                                const SizedBox(
                                  height: 10,
                                )
                              ],
                            )
                          : Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                _BtnRemover(),
                                const SizedBox(
                                  height: 10,
                                )
                              ],
                            ),
                    ),
                   const SizedBox(height: 50,),
                    Card(
                      margin: const EdgeInsets.all(0),
                      elevation: 5,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10)),
                      ),
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.9,
                        height: 100,
                        child: Column(
                        children: [
                          const SizedBox(height: 15,),
                          const Text(
                            'Código Promocional',
                            style: TextStyle(
                              color: Colors.black54,
                              letterSpacing: 0,
                              fontSize: 16.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          CodigoCupom == ""
                              ? const Text(
                                  "-",
                                  style: TextStyle(
                                    color: Color(0xFFFF0066),
                                    letterSpacing: 0,
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'gotham',
                                  ),
                                )
                              : Text(
                                  "$CodigoCupom($ValorCupom %)",
                                  style: const TextStyle(
                                    color: Color(0xFFFF0000),
                                    letterSpacing: 0,
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'gotham',
                                  ),
                                ),
                        ],
                    )),
                    ),
                  ],
                ),
              ),
            ],
          )),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Promoções",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFFEDBD1D),
        elevation: 5,
        iconTheme: const IconThemeData(color: Colors.white, size: 40),
      ),
    );
  }
}
