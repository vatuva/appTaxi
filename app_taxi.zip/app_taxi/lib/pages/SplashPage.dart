import 'dart:async';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:panara_dialogs/panara_dialogs.dart';
import '../controller/MapController.dart';
import 'CarregarPerfilPage.dart';
import 'CarregarViagem.dart';
import 'IniciarPage.dart';
import 'PrincipalPage.dart';
import 'package:get/get.dart';
import 'DriverPage.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'PromocaoPage.dart';
import 'SelectPagamentoPage.dart';

bool btnRg1 = false;
bool btnRg2 = false;
bool btnRg3 = false;
bool btnRg4 = false;

class SplashPage extends StatefulWidget {
  @override
  // ignore: library_private_types_in_public_api
  _SplashPage createState() => _SplashPage();
}

class _SplashPage extends State<SplashPage> {
  final controller = Get.put(MapController());

  bool con = false;

  Future conexao() async {
    try {
      final result = await InternetAddress.lookup('www.mvconws.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        con = true;
      }
    } on SocketException catch (_) {
      con = false;
    }
    print(con);
  }

  void RecuperarSessao() async {
    sessao_usuario = await SessionManager().get("sessao_usuario");
    idPassageiro = await SessionManager().get("idPassageiro");
    ChavePublica = await SessionManager().get("ChavePublica");
    estatus_viagem = await SessionManager().get("estatus_viagem");
    idPedido = await SessionManager().get("idPedido");
    btnRg1 = false;
    btnRg2 = false;
    btnRg3 = false;
    btnRg4 = false;
    ValorCupom = await SessionManager().get("ValorCupom");
    CodigoCupom = await SessionManager().get("CodigoCupom");
  }

  @override
  void initState() {
    super.initState();
    controller.getPosition();
    controller.getAddress();
    conexao();
    RecuperarSessao();
    Timer(const Duration(seconds: 5), () {
      controller.getPosition();
      controller.getAddress();
      if (con == true) {
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => sessao_usuario == 1
                ? estatus_viagem == 1
                    ? CarregarViagem()
                    : CarregarPerfilPage()
                : IniciarPage()));
      } else {
        PanaraConfirmDialog.showAnimatedGrow(
          color: Colors.red,
          context,
          title: "Falha de Conexão",
          message:
              "A sua internet não é boa o suficiente para usar este app. Deseja tentar novamente?",
          confirmButtonText: "Sim",
          cancelButtonText: "Não",
          onTapConfirm: () {
            Navigator.of(context).pop;
            Navigator.of(context).pushReplacement(CupertinoPageRoute(
                builder: (BuildContext context) => SplashPage()));
          },
          onTapCancel: () {
            Future.delayed(const Duration(milliseconds: 1000), () {
              if (Platform.isAndroid) {
                SystemNavigator.pop();
              } else if (Platform.isIOS) {
                exit(0);
              }
            });
          },
          panaraDialogType: PanaraDialogType.warning,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    //OneSignal.shared.init('9b0d8586-e6b1-4f4d-9e37-b79bf4958dc3');
    return MaterialApp(
        theme: ThemeData(fontFamily: 'Gotham'),
        home: Scaffold(
            backgroundColor: const Color(0xFFEDBD1D),
            body: Stack(
              alignment: Alignment.center, //Color(0xFFb21414)
              children: [
                const Center(
                  child: Image(
                    image: AssetImage("assets/images/logotipo.png"),
                  ),
                ),
                Container(
                  alignment: Alignment.bottomCenter,
                  child: const Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircularProgressIndicator.adaptive(
                        backgroundColor: Color(0xFFEDBD1D),
                        valueColor:
                            AlwaysStoppedAnimation<Color>(Color(0xFF15191C)),
                      ),
                      SizedBox(
                        height: 200,
                      )
                    ],
                  ),
                ),
              ],
            )));
  }
}
