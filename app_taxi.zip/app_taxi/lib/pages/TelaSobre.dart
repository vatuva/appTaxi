import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:material_dialogs/dialogs.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';

// ignore: depend_on_referenced_packages
import '../config/Constats.dart';
import 'package:share_and_open_url/share_and_open_url.dart';

import 'PrivacyPolicyScreen.dart';

class TelaSobre extends StatefulWidget {
  @override
  _TelaSobre createState() => _TelaSobre();
}

class _TelaSobre extends State<TelaSobre> {
  final ShareAndOpenUrl _shareAndOpenUrlPlugin = ShareAndOpenUrl();
  final GlobalKey<FormState> _key = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEDEEE9),
      body: Stack(
        children: [
          SafeArea(
              child: Padding(
            padding: const EdgeInsets.only(
              left: 10,
              top: 10,
              right: 10,
            ),
            child: Column(
              children: [
                Card(
                  margin: const EdgeInsets.all(0),
                  elevation: 5,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(10),
                        bottomRight: Radius.circular(10),
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10)),
                  ),
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)])),
                    height: 70,
                    width: MediaQuery.of(context).size.width,
                    child: const Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          'Versão do App: $versionApp',
                          style: TextStyle(
                            color: Colors.black87,
                            fontSize: 16.0,
                            fontWeight: FontWeight.normal,
                            fontFamily: 'gotham',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          )),
          SafeArea(
              child: Padding(
            padding: const EdgeInsets.only(
              left: 10,
              top: 100,
              right: 10,
            ),
            child: Column(
              children: [
                Card(
                  margin: const EdgeInsets.all(0),
                  elevation: 5,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(10),
                        bottomRight: Radius.circular(10),
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10)),
                  ),
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)])),
                    height: 200,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                      /* ListTile(
                          onTap: () async {
                            try {
                              await _shareAndOpenUrlPlugin.openUrl(
                                  Platform.isAndroid
                                      ? urlplaystore
                                      : urlappstore);
                            } on PlatformException catch (e) {
                              throw PlatformException(
                                  code: e.code,
                                  message:
                                      "Failed to open url: '${e.message}'.");
                            }
                          },
                          leading: const Icon(Icons.star,
                              size: 25, color: Color(0xFFEDBD1D)),
                          trailing: const Icon(Icons.navigate_next,
                              size: 25, color: Color(0xFFEDBD1D)),
                          title: const Text(
                            'Classificar a App',
                            style: TextStyle(
                              color: Colors.black87,
                              fontSize: 16.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          ),
                        ),
                        const Divider(
                          height: 10,
                        ),*/
                        ListTile(
                          onTap: () async {
                            try {
                              await _shareAndOpenUrlPlugin.openUrl(urlsite);
                            } on PlatformException catch (e) {
                              throw PlatformException(
                                  code: e.code,
                                  message:
                                      "Failed to open url: '${e.message}'.");
                            }
                          },
                          leading: const Icon(Icons.language,
                              size: 25, color: Color(0xFFEDBD1D)),
                          trailing: ElevatedButton.icon(
                            onPressed: () {
                              Dialogs.bottomMaterialDialog(
                                  msg: 'O app está disponível apenas em Português',
                                  title: 'Idioma',
                                  context: context,
                                  actions: [
                                    IconsOutlineButton(
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                      },
                                      text: 'Cancelar',
                                      iconData: Icons.cancel_outlined,
                                      textStyle: const TextStyle(
                                          color: Color(0xFFFFFFFF)),
                                      iconColor: const Color(0xFFFFFFFF),
                                      color: const Color(0xFFEDBD1D),
                                    ),
                                  ]);
                            },
                            label: const Text('Português',
                              textAlign: TextAlign.end,
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: 14.0,
                                fontWeight: FontWeight.normal,
                                fontFamily: 'gotham',
                              ),),
                            icon: const Icon(Icons.navigate_next,
                                size: 35, color: Color(0xFFEDBD1D)),

                          ),
                          title: const Text(
                            'Idioma',
                            style: TextStyle(
                              color: Colors.black87,
                              fontSize: 16.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          ),
                        ),
                        const Divider(
                          height: 10,
                        ),
                        ListTile(
                          onTap: () async {
                            Navigator.of(context).push(CupertinoPageRoute(
                                builder: (BuildContext context) => const PrivacyPolicyScreen()));
                          },
                          leading: const Icon(Icons.privacy_tip,
                              size: 25, color: Color(0xFFEDBD1D)),
                          trailing: const Icon(Icons.navigate_next,
                              size: 25, color: Color(0xFFEDBD1D)),
                          title: const Text(
                            'Política de Privacidade',
                            style: TextStyle(
                              color: Colors.black87,
                              fontSize: 16.0,
                              fontWeight: FontWeight.normal,
                              fontFamily: 'gotham',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          )),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Sobre nós",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFFEDBD1D),
        elevation: 5,
        iconTheme: const IconThemeData(color: Colors.white, size: 40),
      ),
    );
  }
}
