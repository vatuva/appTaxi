import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages

import 'AvaliarPage.dart';

class FinalizarPage extends StatefulWidget {
  @override
  _FinalizarPage createState() => _FinalizarPage();
}

class _FinalizarPage extends State<FinalizarPage> {
  @override
  void initState() {
    super.initState();
  }

  Widget _BtnFinalizar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFb21414),
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.of(context).pushReplacement(CupertinoPageRoute(
              builder: (BuildContext context) => AvaliarPage()));
        },
        child: const Text(
          'Finalizar',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              height: 100,
            ),
            _BtnFinalizar(),
            const SizedBox(
              height: 10,
            ),
            CircleAvatar(
              radius: 45,
              backgroundColor: Colors.redAccent,
              child: CircleAvatar(
                radius: 40,
                backgroundImage:
                Image.asset('assets/images/nofoto.png')
                    .image,
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const Text(
              'João Silva',
              style: TextStyle(
                color: Colors.redAccent,
                letterSpacing: 0,
                fontSize: 20.0,
                fontWeight: FontWeight.bold,
                fontFamily: 'gotham',
              ),
            ),
            const Divider(
              height: 30,
              color: Colors.redAccent,
            ),
            const ListTile(
              leading: Icon(Icons.access_time_filled_rounded, size: 30, color: Colors.redAccent),
              title: Text(
                "Tempo",
                style: TextStyle(
                  color: Colors.redAccent,
                  fontSize: 14.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const ListTile(
              leading: Icon(Icons.flag, size: 30, color: Colors.redAccent),
              title: Text(
                "Distância",
                style: TextStyle(
                  color: Colors.redAccent,
                  fontSize: 14.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),

            const ListTile(
              leading: Icon(Icons.access_time_filled_rounded, size: 30, color:  Colors.redAccent),
              trailing: Icon(Icons.monetization_on_sharp, size: 30, color:  Colors.redAccent),
              title: Text(
                "Taxa",
                style: TextStyle(
                  color:  Colors.redAccent,
                  fontSize: 14.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
              subtitle: Text(
                "1 200 Kz",
                style: TextStyle(
                  color:  Colors.redAccent,
                  fontSize: 35.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),   const ListTile(
             //eading: Icon(Icons.access_time_filled_rounded, size: 30, color:  Colors.redAccent),
              leading: Icon(Icons.monetization_on_sharp, size: 30, color:  Colors.redAccent),
              title: Text(
                "Valor da Viagem",
                style: TextStyle(
                  color:  Colors.redAccent,
                  fontSize: 14.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
              subtitle: Text(
                "1 200 Kz",
                style: TextStyle(
                  color:  Colors.redAccent,
                  fontSize: 35.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const Divider(
              height: 30,
              color:  Colors.redAccent,
            ),

          ],
        ));
  }
}
