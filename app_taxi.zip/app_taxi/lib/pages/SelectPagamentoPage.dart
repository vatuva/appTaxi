import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import '../config/Constats.dart';
import '../modelos/Viaturas.dart';
import 'PrincipalPage.dart';
import 'RadarPage.dart';
import 'package:google_maps_flutter_platform_interface/google_maps_flutter_platform_interface.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../controller/MapController.dart';
import 'Loading.dart';
import 'package:get/get.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'SelectViaturaPage.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:intl/intl.dart';
import 'SplashPage.dart';

var dadosCarteira;
double SaldoCarteira = 0.0;
var idPedido;

class SelectPagamentoPage extends StatefulWidget {
  @override
  _SelectPagamentoPageState createState() => _SelectPagamentoPageState();
}

class _SelectPagamentoPageState extends State<SelectPagamentoPage> {
  final f = NumberFormat("#,##0", "pt_BR");
  final controllerMap = Get.put(MapController());
  final Completer<GoogleMapController> _controller =
  Completer<GoogleMapController>();
  BitmapDescriptor markerIcon = BitmapDescriptor.defaultMarker;

  loading load = loading();

  final CameraPosition _initialLocation =
  CameraPosition(target: LatLng(posicaoV1, posicaoV2), zoom: 13);
  late GoogleMapController mapController;

  Future<void> ajustarCamera(LatLng origem, LatLng destino) async {
    final controller = await _controller.future;

    final bounds = LatLngBounds(
      southwest: LatLng(
        origem.latitude < destino.latitude
            ? origem.latitude
            : destino.latitude,
        origem.longitude < destino.longitude
            ? origem.longitude
            : destino.longitude,
      ),
      northeast: LatLng(
        origem.latitude > destino.latitude
            ? origem.latitude
            : destino.latitude,
        origem.longitude > destino.longitude
            ? origem.longitude
            : destino.longitude,
      ),
    );

    controller.animateCamera(CameraUpdate.newLatLngBounds(bounds, 80));
  }



  Future getSaldoCarteira() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/carteira/consultar-saldo');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      dadosCarteira = map['carregamentos'];
      setState(() {
        SaldoCarteira = double.tryParse(map['saldo'])!;
        print(SaldoCarteira);
      });
    } catch (e) {
      print(e);
    }
  }

  Future enviarPedido() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/pedido/cadastro');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "origem": origem_pedido.toString(),
        "destino": destino_pedido.toString(),
        "viajante": viajante_pedido.toString(),
        "contacto": contacto_pedido.toString(),
        "tipo_viatura": tipo_viatura.toString(),
        "metodo_pagamento": metodo_pagamento.toString(),
        "desc_origem": desc_origem_pedido.toString(),
        "desc_destino": desc_destino_pedido.toString(),
        "estimativa": valor_estimado.toString()
      });
      final map = json.decode(response.body);
      final dadosPedido = map['pedido'];
      idPedido = dadosPedido['id'];
      final retorno = map['retorno'];
      setState(() {});
      if (retorno == 1) {
        Pesquisar(idPedido);
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.info(
            message:
            'Caro passageiro, ocorreu um erro ao processar o seu pedido. Tente novamente.',
          ),
        );
      }
    } catch (e) {
      print(e);
    }
  }

  Future Pesquisar(String id) async {
    try {
      setState(() {
        btnRg3 = true;
      });
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https', host: dom, path: '$endpoint/corridaapi/pesquisa');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "categoria": tipo_viatura.toString(),
        "pedido": id.toString(),
      });
      final map = json.decode(response.body);
      final dadosPesquisa = map['motoristas_disponiveis'];
      final total = map['total'];

      if (total > 0) {
        await SessionManager().set("idPedido", id.toString());
        notificacao_aceite = false;
        await SessionManager().set("notificacao_aceite", false);
        // ignore: use_build_context_synchronously
        Navigator.pushReplacement(context,
            MaterialPageRoute(builder: (context) => RadarPage()));
      } else {
        setState(() {
          btnRg3 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.info(
            message:
            'Caro passageiro, infelizmente estamos sem Viaturas disponíveis para esta rota.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg3 = false;
      });
      showTopSnackBar(
        // ignore: use_build_context_synchronously
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
          'Caro passageiro, infelizmente estamos com problemas técnicos em processar o seu pedido.',
        ),
      );
    }
  }

  List<Map> staticData = MyPay.data;

  // List dataV = ["Cash", "TPA", "Mulcaixa Express"];

  List<bool> _isSelectedlist = [
    true,
    false,
    false,
  ];

  Widget _BtnContinuar() {
    return SizedBox(
      width: MediaQuery
          .of(context)
          .size
          .width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFF15191C),
            elevation: 20,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: btnRg3 == false
            ? () {
          enviarPedido();
        }
            : () {},
        child: btnRg3 == false
            ? const Text(
          'Confirmar',
          style: TextStyle(
            color: Color(0xFFEDBD1D),
            fontSize: 18.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
          textAlign: TextAlign.center,
          overflow: TextOverflow.fade,
          maxLines: 1,
        )
            : const Text(
          'Aguarde...',
          style: TextStyle(
            color: Color(0xFFEDBD1D),
            fontSize: 16.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
          textAlign: TextAlign.center,
          overflow: TextOverflow.fade,
          maxLines: 1,
        ),
      ),
    );
  }

  Widget InfoBar() {
    return Container(
        width: MediaQuery
            .of(context)
            .size
            .width,
        height: MediaQuery
            .of(context)
            .size
            .height * 0.40,
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15),
            bottomLeft: Radius.circular(0),
            bottomRight: Radius.circular(0),
            topRight: Radius.circular(15),
          ),
          color: Color(0xFFEDBD1D),
        ),
        child: Column(
          children: [
            const SizedBox(
              height: 5,
            ),
            Catreira(),
            const Divider(
              height: 10,
              color: Colors.black12,
            ),
            Metodos(),
            const SizedBox(
              height: 20,
            ),
            _BtnContinuar(),
            const SizedBox(
              height: 20,
            )
          ],
        ));
  }

  Widget Metodos() {
    return Expanded(
      child: ListView.builder(
        padding: const EdgeInsets.only(top: 0),
        scrollDirection: Axis.vertical,
        itemCount: staticData.length,
        itemBuilder: (BuildContext context, int index) =>
            Card(
              shape: RoundedRectangleBorder(
                  side: BorderSide(
                    color: _isSelectedlist[index] == true
                        ? const Color(0xFF15191C)
                        : const Color(0xFF15191C),
                    width: _isSelectedlist[index] == true ? 1 : 1,
                  ),
                  borderRadius: BorderRadius.circular(10)),
              borderOnForeground: true,
              elevation: _isSelectedlist[index] == true ? 2 : 0,
              color: _isSelectedlist[index] == true ? Color(0xFF15191C) : Colors
                  .transparent,
              child: ListTile(
                selected: _isSelectedlist[index],
                dense: true,
                contentPadding: const EdgeInsets.only(
                    top: 0, left: 10, right: 10),
                title: Text(
                  staticData[index]['forma'].toString(),
                  style: TextStyle(
                    fontFamily: "Gotham",
                    fontSize: _isSelectedlist[index] == true ? 25 : 20,
                    // color: Colors.white,
                  ),
                ),
                trailing: _isSelectedlist[index] == true ? Icon(
                  Icons.done, size: 15, color: _isSelectedlist[index] == true
                    ? const Color(0xFFEDBD1D)
                    : Colors.white,):null,
                leading: staticData[index]['forma'] == "Cash" ?  Icon(
                    Icons.money_sharp, color: _isSelectedlist[index] == true
                    ? const Color(0xFFEDBD1D)
                    : Colors.black54,) : staticData[index]['forma'] ==
                    "TPA" ? Icon(Icons.credit_card_sharp, color: _isSelectedlist[index] == true
                    ? const Color(0xFFEDBD1D)
                    : Colors.black54,):Icon(Icons.send_to_mobile, color: _isSelectedlist[index] == true
                    ? const Color(0xFFEDBD1D)
                    : Colors.black54,),
                selectedColor: const Color(0xFFEDBD1D),
              onLongPress: () {},
              onTap: () {
                print(staticData[index]['codigo']);
                metodo_pagamento = staticData[index]['codigo'];
                _updateList(index);
                setState(() {});
              },
            ),
      ),
    ));
  }

  Widget Catreira() {
    return Container(
      // color: Colors.white,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const SizedBox(
              height: 15,
            ),
            Text(
              tipo_viatura,
              style: const TextStyle(
                  fontSize: 25, fontFamily: "Gotham", color: Color(0xFF15191C),
            )),
            const Divider(
              height: 10,
              color: Colors.black12,
            ),
            Container(
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    bottomLeft: Radius.circular(15),
                    bottomRight: Radius.circular(15),
                    topRight: Radius.circular(15),
                  ),
                  // color: Colors.redAccent,
                ),
                width: MediaQuery
                    .of(context)
                    .size
                    .width / 1.2,
                height: 60,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Text(
                        "${f.format(valor_estimado?.roundToDouble()).toString()} Kz",
                        style: const TextStyle(
                            fontFamily: "Gotham",
                            fontSize: 40,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF15191C)),
                      ),
                    ),
                  ],
                )),
          ],
        ));
  }

  _updateList(int index) {
    _isSelectedlist[0] = false;
    _isSelectedlist[1] = false;
    _isSelectedlist[2] = false;
    if (_isSelectedlist[index] == true) {
      setState(() {
        _isSelectedlist[index] = false;
      });
    } else {
      setState(() {
        _isSelectedlist[index] = true;
      });
    }
  }

  Widget _BtnBack() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.pop(context);
        },
        child: const Icon(
          CupertinoIcons.arrow_left_circle,
          color: Color(0xFF15191C),
          size: 30,
        ),
      ),
    );
  }

// Tracking de viatura
  final Map<String, Marker> _markers = {};
  final Map<String, LatLng> _ultimaPosicao = {};
  Timer? _timer;
  late BitmapDescriptor carroIcon;

  Future<void> carregarIcone() async {
    carroIcon = await BitmapDescriptor.fromAssetImage(
      const ImageConfiguration(size: Size(48, 48)),
      'assets/images/carro_online.png',
    );
  }

  Future<void> animarViatura({
    required String id,
    required LatLng inicio,
    required LatLng destino,
  }) async {
    const int frames = 20;

    final bearing = calcularBearing(inicio, destino);

    for (int i = 0; i <= frames; i++) {
      final t = i / frames;

      final posicao = LatLng(
        inicio.latitude +
            (destino.latitude - inicio.latitude) * t,
        inicio.longitude +
            (destino.longitude - inicio.longitude) * t,
      );

      _markers[id] = Marker(
        markerId: MarkerId(id),
        position: posicao,
        icon: carroIcon,
        flat: true,
        rotation: bearing,
        anchor: const Offset(0.5, 0.5),
      );

      if (mounted) setState(() {});
      await Future.delayed(
        const Duration(milliseconds: 50),
      );
    }
  }

  double calcularBearing(LatLng inicio, LatLng fim) {
    final lat1 = inicio.latitude * pi / 180;
    final lon1 = inicio.longitude * pi / 180;
    final lat2 = fim.latitude * pi / 180;
    final lon2 = fim.longitude * pi / 180;

    final dLon = lon2 - lon1;

    final y = sin(dLon) * cos(lat2);
    final x = cos(lat1) * sin(lat2) -
        sin(lat1) * cos(lat2) * cos(dLon);

    final bearing = atan2(y, x);
    return (bearing * 180 / pi + 360) % 360;
  }



  Future<List<Viatura>> buscarViaturasOnline() async {
    final response = await http.get(
      Uri.parse('https://mvconws.com/vamborawbs/motoristasonline'),
    );

    final List data = json.decode(response.body);

    return data.map((e) => Viatura.fromJson(e)).toList();
  }

  Future<void> atualizarViaturas() async {
    final viaturas = await buscarViaturasOnline();

    if (!mounted) return;

    for (final v in viaturas) {
      final id = v.matricula;
      final novaPosicao = v.posicao;

      if (_ultimaPosicao.containsKey(id)) {
        final posicaoAnterior = _ultimaPosicao[id]!;
        animarViatura(
          id: id,
          inicio: posicaoAnterior,
          destino: novaPosicao,
        );
      } else {
        _markers[id] = Marker(
          markerId: MarkerId(id),
          position: novaPosicao,
          flat: true,
          anchor: const Offset(0.5, 0.5),
          icon: carroIcon,
          infoWindow: InfoWindow(title: v.apelido),
        );
      }

      _ultimaPosicao[id] = novaPosicao;
    }
  }

  void iniciarTracking() {
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      atualizarViaturas();
    });
  }
// fim tracking


  @override
  void initState() {
    getSaldoCarteira();
    carregarIcone().then((_) {
      atualizarViaturas();
      iniciarTracking();
    });
    super.initState();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'Gotham'),
      home: Scaffold(
        drawer: const Drawer(),
        body: Stack(
          children: [
            SafeArea(
              child: GoogleMap(
                mapType: MapType.normal,
                initialCameraPosition: _initialLocation,
                markers: Set<Marker>.of(_markers.values),
                zoomControlsEnabled: false,
                myLocationButtonEnabled: false,
                myLocationEnabled: true,
                zoomGesturesEnabled: true,
                onMapCreated: (GoogleMapController controller) async {
                  _controller.complete(controller);
                },
              ),
            ),
            SafeArea(
                child: Padding(
                  padding: EdgeInsets.only(
                    right: MediaQuery
                        .of(context)
                        .size
                        .width / 1.5,
                    top: 20,
                    left: 10,
                  ),
                  child: Column(
                    children: [
                      _BtnBack(),
                    ],
                  ),
                )),
            Container(
              alignment: Alignment.bottomCenter,
              child: Row(
                children: [
                  Row(
                    children: [
                      InfoBar(),
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}

class MyPay {
  static List<Map> data = [
    {
      "id": 1,
      "codigo": "Cash",
      "forma": "Cash",
    },
    {
      "id": 2,
      "codigo": "TPA",
      "forma": "TPA",
    },
  ];
}
