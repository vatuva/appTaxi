import 'dart:convert';
import 'package:card_loading/card_loading.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import '../config/Constats.dart';
import '../modelos/CardPagamentos.dart';
import 'PrincipalPage.dart';

var dadosPagamentos;
var dataViagem;
var origemViagem;
var destinoViagem;
var pagamentoViagem;
var valorViagem;
var horaInicio;
var horaFim;

class PagamentosPage extends StatefulWidget {
  const PagamentosPage({super.key});

  @override
  _PagamentosPage createState() => _PagamentosPage();
}

class _PagamentosPage extends State<PagamentosPage> {
  final TextEditingController chatController = TextEditingController();
  DateTime now = DateTime.now();
  late TextEditingController data1;
  late TextEditingController data2;
  var dataActual = DateTime.now().add(const Duration(days: -30));
  var dataActual2 = DateTime.now().add(const Duration(days: 1));

  bool carregadoV = false;

  Future CarregarViagens() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/listar/viagens');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "data1": data1.text,
        "data2": data2.text,
      });
      final map = json.decode(response.body);
      setState(() {
        dadosPagamentos = map['viagens'];
        carregadoV = true;
      });
      print(dadosPagamentos);
    } catch (e) {
      print(e);
    }
  }

  Widget _daoPagamentos() {
    return Container(
      height: MediaQuery.of(context).size.height / 1.3,
      margin: const EdgeInsets.only(top: 80),
      child: !carregadoV
          ? const CardLoading(
              height: 80,
              borderRadius: BorderRadius.all(Radius.circular(10)),
              margin: EdgeInsets.only(bottom: 10),
            )
          : dadosPagamentos.isEmpty
              ? const Center(
                  child: const Text(
                    "Sem histórico de corridas",
                    style: TextStyle(
                      color: Colors.black54,
                      fontSize: 12.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'gotham',
                    ),
                  ),
                )
              : ListView.builder(
                  scrollDirection: Axis.vertical,
                  itemCount: dadosPagamentos.length,
                  itemBuilder: (BuildContext context, int index) {
                    return CardPagamentos(
                      id: dadosPagamentos[index]['id'],
                      data: DateTime.parse(
                          dadosPagamentos[index]['inicio_viagem']),
                      valor: dadosPagamentos[index]['valor'],
                      destinoViagem: dadosPagamentos[index]['desc_destino'],
                      horaFim: dadosPagamentos[index]['termino_viagem'],
                      horaInicio: dadosPagamentos[index]['inicio_viagem'],
                      origemViagem: dadosPagamentos[index]['desc_origem'],
                      pagamentoViagem: dadosPagamentos[index]
                          ['metodo_pagamento'],
                      destino: dadosPagamentos[index]['destino'],
                      origem: dadosPagamentos[index]['origem'],
                    );
                  },
                ),
    );
  }

  @override
  void initState() {
    data1 = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual));
    data2 = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual2));
    CarregarViagens();

    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                  padding: const EdgeInsets.only(right: 0, bottom: 0, top: 0),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(0),
                          color: Colors.white,
                        ),
                        width: MediaQuery.of(context).size.width,
                        height: 65,
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [_Data1()],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    _Data2(),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  )),
            ),
          ),
          const SafeArea(
            child: Align(
              alignment: Alignment.topRight,
              child: Padding(
                  padding: EdgeInsets.only(right: 5, bottom: 0, top: 20),
                  child: Column(
                    children: [],
                  )),
            ),
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                  padding: const EdgeInsets.only(right: 0, bottom: 0, top: 70),
                  child: Container(
                    color: const Color(0xFFEDBD1D),
                    height: 2,
                    width: MediaQuery.of(context).size.width,
                  )),
            ),
          ),
          Container(
            alignment: Alignment.center,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                _daoPagamentos(),
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Histórico de Corridas",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFFEDBD1D),
        elevation: 5,
        iconTheme: const IconThemeData(color: Colors.white, size: 40),
      ),
    );
  }

  Future<void> showDate1(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2000),
    );
    setState(() {
      String selectdata1 = DateFormat('yyyy-MM-dd').format(picked!);
      data1 = TextEditingController(text: selectdata1);
      setState(() {
        CarregarViagens();
        print(data1.text);
      });
    });
  }

  Future<void> showDate2(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2000),
    );
    setState(() {
      String Selectdata2 = DateFormat('yyyy-MM-dd').format(picked!);
      data2 = TextEditingController(text: Selectdata2);
      setState(() {
        CarregarViagens();
        print(data2.text);
      });
    });
  }

  Widget _Data1() {
    return Column(
      children: <Widget>[
        Container(
          alignment: Alignment.centerLeft,
          height: 45.0,
          width: MediaQuery.of(context).size.width / 2.2,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            onTap: () async {
              await showDate1(context);
            },
            readOnly: true,
            controller: data1,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
              fontSize: 14,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(
                Icons.calendar_month,
                color: Color(0xFFEDBD1D),
              ),
              hintText: 'Data inicial',
            ),
          ),
        ),
      ],
    );
  }

  Widget _Data2() {
    return Column(
      children: <Widget>[
        Container(
          alignment: Alignment.centerLeft,
          height: 45.0,
          width: MediaQuery.of(context).size.width / 2.2,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            onTap: () async {
              await showDate2(context);
            },
            readOnly: true,
            controller: data2,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
              fontSize: 14,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(
                Icons.calendar_month,
                color: Color(0xFFEDBD1D),
              ),
              hintText: 'Data final',
            ),
          ),
        ),
      ],
    );
  }
}
