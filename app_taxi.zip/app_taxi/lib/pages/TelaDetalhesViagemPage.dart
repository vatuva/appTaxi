import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import '../controller/MapController.dart';
import 'DefineRotaPage.dart';
import 'PagamentosPage.dart';
import 'SelectViaturaPage.dart';


class TelaDetalhesViagemPage extends StatefulWidget {
  const TelaDetalhesViagemPage({super.key});

  @override
  _TelaDetalhesViagemPage createState() => _TelaDetalhesViagemPage();
}

class _TelaDetalhesViagemPage extends State<TelaDetalhesViagemPage> {

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
        body: Stack(
          children: [
            SafeArea(
                child: Padding(
                  padding: const EdgeInsets.only(
                    left: 10,
                    top: 10,
                    right: 10,
                  ),
                  child: Column(
                    children: [
                      Card(
                        margin: const EdgeInsets.all(0),
                        elevation: 5,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(10),
                              bottomRight: Radius.circular(10),
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10)),
                        ),
                        child: Container(
                          decoration: const BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                  topLeft: Radius.circular(10),
                                  topRight: Radius.circular(10)),
                              gradient: LinearGradient(
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                  colors: [
                                    Color(0xFFFFFFFF),
                                    Color(0xFFFFFFFF)
                                  ])),
                          height: 100,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ListTile(
                                onTap: () {
                                  calc_distancia_viatura = 0;
                                  distance_rota = Geolocator.distanceBetween(
                                      posicaoV1, posicaoV2, destinoV1, destinoV2);
                                  calc_distancia_viatura = distance_rota / 1000;
                                  // ignore: use_build_context_synchronously
                                  Navigator.push(context,
                                      MaterialPageRoute(builder: (context) => SelectViaturaPage()));
                                },
                               /* trailing: const Icon(Icons.event_repeat,
                                    size: 35, color: Color(0xFFEDBD1D)),*/
                                title: Text(
                                  DateFormat.yMMMd().format(dataViagem),
                                  style: const TextStyle(
                                    color: Colors.black87,
                                    fontSize: 22.0,
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'gotham',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                )),
            SafeArea(
                child: Padding(
                  padding: const EdgeInsets.only(
                    left: 10,
                    top: 120,
                    right: 10,
                  ),
                  child: Column(
                    children: [
                      const Divider(height: 20,),
                      Card(
                        margin: const EdgeInsets.all(0),
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(10),
                              bottomRight: Radius.circular(10),
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10)),
                        ),
                        child: Container(
                          decoration: const BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                  topLeft: Radius.circular(10),
                                  topRight: Radius.circular(10)),
                              gradient: LinearGradient(
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                  colors: [
                                    Color(0xFFFFFFFF),
                                    Color(0xFFFFFFFF)
                                  ])),
                          height: 150,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ListTile(
                                onTap: () {
                                },
                                leading: const Icon(Icons.circle_outlined,
                                    size: 25, color: Color(0xFFEDBD1D)),
                                title: Text(
                                  '$origemViagem',
                                  style: const TextStyle(
                                    color: Colors.black87,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'gotham',
                                  ),
                                ),
                              ),
                              ListTile(
                                onTap: () {
                                },
                                leading: const Icon(Icons.circle,
                                    size: 25, color: Color(0xFFEDBD1D)),
                                title: Text(
                                  '$destinoViagem',
                                  style: const TextStyle(
                                    color: Colors.black87,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'gotham',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const Divider(height: 20,),
                    ],
                  ),
                )),
            SafeArea(
                child: Padding(
                  padding: const EdgeInsets.only(
                    left: 10,
                    top: 300,
                    right: 10,
                  ),
                  child: Column(
                    children: [
                      Card(
                        margin: const EdgeInsets.all(0),
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(10),
                              bottomRight: Radius.circular(10),
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10)),
                        ),
                        child: Container(
                          decoration: const BoxDecoration(
                              borderRadius: BorderRadius.only(
                                  bottomLeft: Radius.circular(10),
                                  bottomRight: Radius.circular(10),
                                  topLeft: Radius.circular(10),
                                  topRight: Radius.circular(10)),
                              gradient: LinearGradient(
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                  colors: [
                                    Color(0xFFFFFFFF),
                                    Color(0xFFFFFFFF)
                                  ])),
                          height: 70,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ListTile(
                                onTap: () {
                                },
                                trailing: Text(
                                  " $valorViagem AOA",
                                  style: const TextStyle(
                                    color: Colors.black,
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'gotham',
                                  ),
                                ),
                                leading: const Icon(Icons.monetization_on,
                                    size: 25, color: Color(0xFFEDBD1D)),
                                title:Text(
                                  "$pagamentoViagem",
                                  style: const TextStyle(
                                    color: Colors.black,
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'gotham',
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      const Divider(height: 20,),
                    ],
                  ),
                )),
          ],
        ),
      appBar: AppBar(
        title: const Text(
          "Detalhes da Viagem",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFFEDBD1D),
        elevation: 5,
        iconTheme: const IconThemeData(color: Colors.white, size: 40),
      ),
      );
  }


}
