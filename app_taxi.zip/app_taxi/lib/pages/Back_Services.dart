import 'dart:async';
import 'dart:convert';
import 'dart:isolate';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:permission_handler/permission_handler.dart';
import '../config/Constats.dart';
import '../main.dart';
import 'DriverPage.dart';
import 'LocalNotification.dart';
import 'PrincipalPage.dart';
import 'package:http/http.dart' as http;
import 'RadarPage.dart';
import 'SelectPagamentoPage.dart';

@pragma('vm:entry-point')
void startCallback() {
  FlutterForegroundTask.setTaskHandler(FirstTaskHandler());
}

class FirstTaskHandler extends TaskHandler {
  SendPort? _sendPort;

  void requestPermissionsNotification() async {
    final notification = await Permission.notification.status;
    if (notification != PermissionStatus.granted) {
      await Permission.notification.request();
    }
  }

  @override
  Future<void> onStart(DateTime timestamp, TaskStarter starter) async {
    _sendPort?.send("startTask");
  }

  Future DadosPedido() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/pedido/dados-pedido";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": idPedido.toString(),
      });
      final map = json.decode(response.body);
      final dados = map['pedido'];
      print('Estado pedido back');
      estado_pedido = dados['status'];
    } catch (e) {
      print(e);
    }
  }

  void VerificarPedido() async {
    print('verificar pedido back');
    if (estado_pedido == "2" && notificacao_aceite == false) {
      estatus_viagem = 1;
      await SessionManager().set("estatus_viagem", 1);
      LocalNotification.showBigTextNotification(
          title: 'O seu pedido foi atendido',
          body: 'Aguarde no local de recolha, por favor.',
          fln: flutterLocalNotificationsPlugin);
      notificacao_aceite = true;
      await SessionManager().set("notificacao_aceite", true);
    }
  }

  @override
  void onRepeatEvent(DateTime timestamp) async {
    idPassageiro = await SessionManager().get("idPassageiro");
    ChavePublica = await SessionManager().get("ChavePublica");
    idPedido = await SessionManager().get("idPedido");
    notificacao_aceite = await SessionManager().get("notificacao_aceite");
    DadosPedido();
    VerificarPedido();
  }

  @override
  Future<void> onDestroy(DateTime timestamp) async {
    // FlutterForegroundTask.stopService();
  }

  @override
  void onNotificationButtonPressed(String id) {
    // _sendPort?.send("killTask");
  }

  @override
  void onNotificationPressed() {
    _sendPort?.send('onNotificationPressed');
  }
}

class ForegroundTaskService {
  static init() {
    FlutterForegroundTask.init(
      androidNotificationOptions: AndroidNotificationOptions(
          channelId: 'vambora_service_passageiro',
          channelName: 'Vambora',
          channelDescription: 'Viagem em Curso',
          onlyAlertOnce: true,
          enableVibration: true,
          showWhen: true,
          playSound: true),
      iosNotificationOptions: const IOSNotificationOptions(
        showNotification: false,
        playSound: false,
      ),
      foregroundTaskOptions: ForegroundTaskOptions(
        eventAction: ForegroundTaskEventAction.repeat(3000),
        autoRunOnBoot: true,
        autoRunOnMyPackageReplaced: true,
        allowWakeLock: true,
        allowWifiLock: true,
      ),
    );
  }
}
