import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:draggable_bottom_sheet_nullsafety/draggable_bottom_sheet_nullsafety.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:vambora_passageiro/pages/DefineRotaPage.dart';
import 'package:vambora_passageiro/pages/DriverPage.dart';
import 'package:vambora_passageiro/pages/SelectViaturaPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'package:panara_dialogs/panara_dialogs.dart';
import '../config/Constats.dart';
import '../controller/MapController.dart';
import '../main.dart';
import '../modelos/Viaturas.dart';
import 'Back_Services.dart';
import 'PagamentosPage.dart';
import 'PromocaoPage.dart';
import 'RadarPage.dart';
import 'SelectPagamentoPage.dart';
import 'LocalNotification.dart';
import 'PerfilPage.dart';
import 'Loading.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';

import 'TelaAjuda.dart';
import 'TelaSobre.dart';
import 'TelaVerificarNumero.dart';

var sessao_usuario;
var TipoServico = "Piloto";
var idPassageiro;
var ChavePublica;
String regiao = "";
String nomePassageiro = "";
String sobrenomePassageiro = "";
String fotoPerfil = "";
String emailPassageiro = "";
var verificacao;
var posicaoPassageiro;

class PrincipalPage extends StatefulWidget {
  @override
  _PrincipalPage createState() => _PrincipalPage();
}

class _PrincipalPage extends State<PrincipalPage> {
  late GoogleMapController _mapController;
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  final controllerMap = Get.put(MapController());
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  BitmapDescriptor markerIcon = BitmapDescriptor.defaultMarker;
  BitmapDescriptor markerIcon2 = BitmapDescriptor.defaultMarker;

  FocusNode myfocus = FocusNode();

  bool _locationEnabled = false;

  final TextEditingController locationController = TextEditingController();
  final TextEditingController servicoController = TextEditingController();
  final TextEditingController locationController2 = TextEditingController();
  loading load = loading();
  final CameraPosition _initialLocation = const CameraPosition(
      target: LatLng(-8.56148317153996, 13.593409574676945), zoom: 0);
  late GoogleMapController mapController;

  Future<void> getCurrentLocation() async {
    await Geolocator.getCurrentPosition().then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(const CameraPosition(
        // target: LatLng(position.latitude, position.latitude),
       target: LatLng(-8.8778925,13.4846825),
        zoom: 10.5,
      )));
      posicaoV1 = position.latitude;
      posicaoV2 = position.longitude;
      setState(() {
        posicaoPassageiro = "$posicaoV1,$posicaoV2";
      });
    }).catchError((e) {
      print(e);
    });
  }

  LocationData? currentLocation;

  void pegarCurrentLocation() async {
    Location location = Location();
    location.getLocation().then(
      (location) {
        currentLocation = location;
        setState(() {});
      },
    );
    GoogleMapController googleMapController = await _controller.future;
    location.onLocationChanged.listen((newLoc) {
      currentLocation = newLoc;
      googleMapController.animateCamera(CameraUpdate.newCameraPosition(
          const CameraPosition(
              target: LatLng(-8.8778925,13.4846825),
              zoom: 10.5)));
    });
    setState(() {});
  }

  List<LatLng> polylineCoordinates = [];


  Future Carregamento() async {
    await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(load.getFuture()),
    );
  }

  Future ValidarNumero() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/activar/passo1');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      print(map);
      final msgr = map["retorno"];
      final msg = map["msg"];
      if (msgr == 1) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.info(
            message: 'Verifique o seu número.',
          ),
        );
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) =>
                TelaVerificarNumero()));
        // ignore: use_build_context_synchronously
      } else if (msgr == 0) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'O número de telemóvel informado é inválido.',
          ),
        );
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Future CarregarDados() async {
    try {
      var url = Uri(
          scheme: 'https', host: dom, path: '$endpoint/passageiroapi/dados');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final perfil = map["perfil_passageiro"];
      setState(() {
        verificacao = perfil['status_verificacao'];
        nomePassageiro = perfil['nome'];
        sobrenomePassageiro = perfil['apelido'];
        fotoPerfil = urlImagem + perfil['foto'];
        emailPassageiro = perfil['email'];
        contacto_pedido = perfil['telefone'];
        viajante_pedido = nomePassageiro;
      });
      print("idPassageiro");
      print(idPassageiro);
      print(ChavePublica);
    } catch (e) {
      print(e);
    }
  }


  var rating = 0.0;

  Widget InfoBar() {
    return Container(
        width: MediaQuery.of(context).size.width,
        height: 100,
        decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(15),
                bottomLeft: Radius.circular(0),
                bottomRight: Radius.circular(0),
                topRight: Radius.circular(15)),
            color: Color(0xFFFF0066)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              color: const Color(0xFFEDEEE9),
              height: 7,
              width: 40,
              decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(100),
                      bottomLeft: Radius.circular(100),
                      bottomRight: Radius.circular(100),
                      topRight: Radius.circular(100)),
                  color: Color(0xFFEDEEE9)),
            ),
            const SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                TxtLocation(),
              ],
            ),
          ],
        ));
  }

  Widget TxtLocation2() {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            bottomLeft: Radius.circular(10),
            bottomRight: Radius.circular(10),
            topRight: Radius.circular(10)),
        color: Color(0xFF15191C),
      ),
      width: MediaQuery.of(context).size.width / 1.1,
      height: 50,
      child: TextField(
        decoration: const InputDecoration(
          fillColor: Color(0xFF15191C),
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(width: 0, color: Color(0xFF15191C)),
          ),
          border: InputBorder.none,
          icon: Icon(
            CupertinoIcons.search,
            color: Colors.black54,
            size: 30,
          ),
        ),
        onTap: () {
          locationController2.text = '';
        },
        textAlignVertical: TextAlignVertical.center,
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 22,
          fontFamily: 'Gotham',
        ),
        keyboardType: TextInputType.text,
        controller: locationController2,
      ),
    );
  }

  Widget TxtLocation() {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(100),
            bottomLeft: Radius.circular(100),
            bottomRight: Radius.circular(100),
            topRight: Radius.circular(100)),
        color: Color(0xFF15191C),
      ),
      width: MediaQuery.of(context).size.width / 1.1,
      height: 50,
      child: TextField(
        focusNode: myfocus,
        readOnly: true,
        decoration: const InputDecoration(
          fillColor: Color(0xFF15191C),
          enabledBorder: UnderlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
            borderSide: BorderSide(width: 0, color: Color(0xFF15191C)),
          ),
          border: InputBorder.none,
          icon: Icon(
            CupertinoIcons.search,
            color: Colors.white,
            size: 30,
          ),
        ),
        onTap: () {
          setState(() {
            controllerMap.getAddress();
          });
          Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) => DefineRotaPage()));
        },
        textAlignVertical: TextAlignVertical.center,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 22,
          fontFamily: 'Gotham',
        ),
        keyboardType: TextInputType.none,
        controller: locationController,
      ),
    );
  }

  Future<void> share() async {

  }

  void ActivarSessao() async {
    await SessionManager().set("sessao_usuario", 1);
    // service.invoke("stopService");
  }

  void limparDadosViagem() async {
    await SessionManager().set("estatus_viagem", 0);
    await SessionManager().set("idPedido", "");
    estatus_viagem = 0;
    calc_distancia_viatura = 0;
    aceite_viagem = false;
    idPedido = "";
    localRecolha = "Localização Actual";
    notificacao_aceite = false;
    await SessionManager().set("notificacao_aceite", false);
  }


  final Set<Marker> _markers = {};


  Widget _BtnMenu() {
    return SizedBox(
      width: 50,
      height: 50,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 5,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          _scaffoldKey.currentState!.openDrawer();
        },
        child: const Icon(
          Icons.menu,
          color: Color(0xFF15191C),
          size: 40,
        ),
      ),
    );
  }

  // Tracking de viatura

  final Map<String, Marker> _markers2 = {};
  final Map<String, LatLng> _ultimaPosicao = {};
  Timer? _timer;
  late BitmapDescriptor carroIcon;


  Future<void> carregarIcone() async {
    carroIcon = await BitmapDescriptor.fromAssetImage(
      const ImageConfiguration(size: Size(48, 48)),
      'assets/images/carro_online.png',
    );
  }

  Future<void> animarViatura({
    required String id,
    required LatLng inicio,
    required LatLng destino,
  }) async {
    const int frames = 20;

    final bearing = calcularBearing(inicio, destino);

    for (int i = 0; i <= frames; i++) {
      final t = i / frames;

      final posicao = LatLng(
        inicio.latitude +
            (destino.latitude - inicio.latitude) * t,
        inicio.longitude +
            (destino.longitude - inicio.longitude) * t,
      );

      _markers2[id] = Marker(
        markerId: MarkerId(id),
        position: posicao,
        icon: carroIcon,
        flat: true,
        rotation: bearing,
        anchor: const Offset(0.5, 0.5),
      );

      if (mounted) setState(() {});
      await Future.delayed(
        const Duration(milliseconds: 50),
      );
    }
  }

  double calcularBearing(LatLng inicio, LatLng fim) {
    final lat1 = inicio.latitude * pi / 180;
    final lon1 = inicio.longitude * pi / 180;
    final lat2 = fim.latitude * pi / 180;
    final lon2 = fim.longitude * pi / 180;

    final dLon = lon2 - lon1;

    final y = sin(dLon) * cos(lat2);
    final x = cos(lat1) * sin(lat2) -
        sin(lat1) * cos(lat2) * cos(dLon);

    final bearing = atan2(y, x);
    return (bearing * 180 / pi + 360) % 360;
  }



  Future<List<Viatura>> buscarViaturasOnline() async {
    final response = await http.get(
      Uri.parse('https://mvconws.com/vamborawbs/motoristasonline'),
    );

    final List data = json.decode(response.body);

    return data.map((e) => Viatura.fromJson(e)).toList();
  }

  Future<void> atualizarViaturas() async {
    final viaturas = await buscarViaturasOnline();

    if (!mounted) return;

    for (final v in viaturas) {
      final id = v.matricula;
      final novaPosicao = v.posicao;

      if (_ultimaPosicao.containsKey(id)) {
        final posicaoAnterior = _ultimaPosicao[id]!;
        animarViatura(
          id: id,
          inicio: posicaoAnterior,
          destino: novaPosicao,
        );
      } else {
        _markers2[id] = Marker(
          markerId: MarkerId(id),
          position: novaPosicao,
          flat: true,
          anchor: const Offset(0.5, 0.5),
          icon: carroIcon,
          infoWindow: InfoWindow(title: v.apelido),
        );
      }

      _ultimaPosicao[id] = novaPosicao;
    }
  }


  void iniciarTracking() {
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      atualizarViaturas();
    });
  }
// fim tracking




  @override
  void initState() {
    super.initState();
   FirstTaskHandler().requestPermissionsNotification();
    if (verificacao == "0") {
      ValidarNumero();
    } else {}
    limparDadosViagem();
    pegarCurrentLocation();
    getCurrentLocation();
    controllerMap.getPosition();
    controllerMap.getAddress();
    carregarIcone().then((_) {
      atualizarViaturas();
      iniciarTracking();
    });
    myfocus.requestFocus();
    locationController.text = "Para onde vai?";
    locationController2.text = "Para onde vai?";
    LocalNotification.initialize(flutterLocalNotificationsPlugin);
  }

  Widget _BtnGPS() {
    return SizedBox(
      width: 50,
      height: 50,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          getCurrentLocation();
        },
        child: const Icon(
          CupertinoIcons.location_circle,
          color: Color(0xFF15191C),
          size: 30,
        ),
      ),
    );
  }


  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void stopService() {
    FlutterForegroundTask.stopService();
  }

  @override
  Widget build(BuildContext context) => WillPopScope(
        onWillPop: () async {
          Future.delayed(const Duration(milliseconds: 1000), () {
            if (Platform.isAndroid) {
              SystemNavigator.pop();
            } else if (Platform.isIOS) {
              exit(0);
            }
          });
          return true;
        },
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          theme: ThemeData(fontFamily: 'Gotham'),
          home: Scaffold(
              key: _scaffoldKey,
              endDrawerEnableOpenDragGesture: false,
              body:  Stack(
                children: [
                   GoogleMap(
                    mapType: MapType.normal,
                    initialCameraPosition: _initialLocation,
                     markers: Set<Marker>.of(_markers2.values),
                     zoomControlsEnabled: false,
                     myLocationButtonEnabled: false,
                    zoomGesturesEnabled: true,
                    onMapCreated: (GoogleMapController controller) {
                      _controller.complete(controller);
                      Future.delayed(const Duration(milliseconds: 500), () {
                        setState(() {
                          _locationEnabled = true;
                        });
                      });
                    },
                  ),
                  DraggableBottomSheet(
                    minExtent: 130,
                    maxExtent: 200,
                    previewChild: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: const BoxDecoration(
                          color: Color(0xFFEDBD1D),
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(15),
                            topRight: Radius.circular(15),
                          ),
                        ),
                        child: Column(
                          children: <Widget>[
                            Container(
                              width: 60,
                              height: 6,
                              decoration: BoxDecoration(
                                gradient: const LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [
                                    Color(0xFF15191C),
                                    Color(0xFF15191C),
                                  ],
                                ),
                                // color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            const SizedBox(height: 8),
                            TxtLocation(),
                          ],
                        ),),
                    expandedChild: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: const BoxDecoration(
                        color: Color(0xFFEDBD1D),
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(15),
                          topRight: Radius.circular(15),
                        ),
                      ),
                      child: Column(
                        children: <Widget>[
                          Container(
                            width: 60,
                            height: 6,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  Color(0xFF15191C),
                                  Color(0xFF15191C),
                                ],
                              ),
                              // color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                          const SizedBox(height: 8),
                          TxtLocation(),
                        ],
                      ),),
                    backgroundWidget: Container(),
                  ),
                  SafeArea(
                      child: Padding(
                    padding: const EdgeInsets.only(
                      left: 10,
                      top: 20,
                    ),
                    child: Column(
                      children: [
                        _BtnMenu(),
                      ],
                    ),
                  )),
                  SafeArea(
                      child: Padding(
                    padding: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width * 0.8,
                      top: MediaQuery.of(context).size.height * 0.70,
                      right: 10,
                    ),
                    child: Column(
                      children: [
                        _BtnGPS(),
                      ],
                    ),
                  )),
                ],
              ),
              drawer: Drawer(
                backgroundColor: const Color(0xFFEDBD1D),
                child: ListView(
                  children: [
                    Card(
                      margin: EdgeInsets.zero,
                      elevation: 5,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                            topLeft: Radius.circular(0),
                            topRight: Radius.circular(0)),
                      ),
                      child: Container(
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(0),
                                bottomRight: Radius.circular(0),
                                topLeft: Radius.circular(0),
                                topRight: Radius.circular(0)),
                            gradient: LinearGradient(
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                                colors: [
                                  Color(0xFF15191C),
                                  Color(0xFF15191C)
                                ])),
                        height: 75,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 30,
                                    )
                                  ],
                                ),
                                Column(
                                  children: [
                                    Container(
                                      width: 5,
                                    )
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    Text(
                                      "Olá, $nomePassageiro",
                                      textAlign: TextAlign.left,
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 20,
                                      ),
                                    ),
                                  ],
                                )
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    Card(
                        margin: EdgeInsets.zero,
                        elevation: 0,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(0),
                              bottomRight: Radius.circular(0),
                              topLeft: Radius.circular(0),
                              topRight: Radius.circular(0)),
                        ),
                        child: Container(
                          color: const Color(0xFFEDBD1D),
                            child: Column(
                          children: [
                            ListTile(
                              onTap: () {
                                Navigator.of(context).push(CupertinoPageRoute(
                                    builder: (BuildContext context) =>
                                        PerfilPage()));
                              },
                              leading: const Icon(CupertinoIcons.person,
                                  size: 25, color: Color(0xFF15191C)),
                              title: const Text(
                                "Minha Conta",
                                style: TextStyle(
                                  color: Color(0xFF15191C),
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                            const Divider(height: 2,),
                            ListTile(
                              onTap: () {
                                Navigator.of(context).push(CupertinoPageRoute(
                                    builder: (BuildContext context) =>
                                        const PagamentosPage()));
                              },
                              leading: const Icon(CupertinoIcons.calendar_today,
                                  size: 25, color: Color(0xFF15191C)),
                              title: const Text(
                                "Corridas",
                                style: TextStyle(
                                  color: Color(0xFF15191C),
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                            const Divider(height: 2,),
                            ListTile(
                              onTap: () {
                                Navigator.of(context).push(CupertinoPageRoute(
                                    builder: (BuildContext context) =>
                                        PromocaoPage()));
                              },
                              leading: const Icon(Icons.local_offer_outlined,
                                  size: 25, color: Color(0xFF15191C)),
                              title: const Text(
                                "Promoções",
                                style: TextStyle(
                                  color: Color(0xFF15191C),
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                            const Divider(height: 2,),
                            ListTile(
                              onTap: () {
                                Navigator.of(context).push(CupertinoPageRoute(
                                    builder: (BuildContext context) =>
                                        TelaAjuda()));
                              },
                              leading: const Icon(Icons.help_outline_outlined,
                                  size: 25, color: Color(0xFF15191C)),
                              title: const Text(
                                "Ajuda",
                                style: TextStyle(
                                  color: Color(0xFF15191C),
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                            const Divider(height: 2,),
                            ListTile(
                              onTap: () {
                                Navigator.of(context).push(CupertinoPageRoute(
                                    builder: (BuildContext context) =>
                                        TelaSobre()));
                              },
                              leading: const Icon(Icons.info_outline,
                                  size: 25, color: Color(0xFF15191C)),
                              title: const Text(
                                "Sobre nós",
                                style: TextStyle(
                                  color: Color(0xFF15191C),
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                            const Divider(height: 2,),
                            ListTile(
                                onTap: () {
                                  PanaraConfirmDialog.showAnimatedGrow(
                                    color: Colors.red,
                                    context,
                                    title: "Terminar Sessão",
                                    message:
                                        "Tem certeza que deseja terminar Sessão?",
                                    confirmButtonText: "Não",
                                    cancelButtonText: "Sim",
                                    onTapConfirm: () {
                                      Navigator.pop(context);
                                    },
                                    onTapCancel: () async {
                                      await SessionManager()
                                          .set("sessao_usuario", 0);
                                      CodigoCupom = "";
                                      await SessionManager()
                                          .set("CodigoCupom", "");
                                      ValorCupom = "";
                                      await SessionManager()
                                          .set("ValorCupom", "");
                                      // ignore: use_build_context_synchronously
                                      Future.delayed(
                                          const Duration(milliseconds: 3000),
                                          () async {
                                        await showDialog(
                                          context: context,
                                          builder: (context) =>
                                              FutureProgressDialog(
                                                  load.getFuture()),
                                        );
                                        if (Platform.isAndroid) {
                                          SystemNavigator.pop();
                                        } else if (Platform.isIOS) {
                                          exit(0);
                                        }
                                      });
                                    },
                                    panaraDialogType: PanaraDialogType.warning,
                                  );
                                },
                                leading: const Icon(Icons.exit_to_app_outlined,
                                    size: 25, color: Colors.black87),
                                title: const Text(
                                  "Terminar sessão",
                                  style: TextStyle(
                                    color: Colors.black87,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.normal,
                                    fontFamily: 'gotham',
                                  ),
                                )),
                          ],
                        ))),
                  ],
                ),
              )),
        ),
      );
}
