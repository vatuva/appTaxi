import 'dart:async';
import 'dart:convert';
import 'package:vambora_passageiro/config/Constats.dart';
import 'package:vambora_passageiro/controller/MapController.dart';
import 'package:vambora_passageiro/pages/SelectViaturaPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'DefineRotaPage.dart';

class DefineRotaMapaPage extends StatefulWidget {
  @override
  _DefineRotaMapaPage createState() => _DefineRotaMapaPage();
}

class _DefineRotaMapaPage extends State<DefineRotaMapaPage> {
  bool buscando = false;
  var currentLocation;

  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();

  final TextEditingController destinoController = TextEditingController();

  final CameraPosition _initialLocation =
      CameraPosition(target: LatLng(posicaoV1, posicaoV2), zoom: 13.5);
  late GoogleMapController mapController;

  Future<void> getCurrentLocation() async {
    await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best)
        .then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(position.latitude, position.longitude),
        zoom: 13.5,
      )));
      setState(() {});
    }).catchError((e) async {
      print(e);
    });
  }

  Widget TxtDestino() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 55,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: Colors.black12)),
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 10,
        ),
        style: const TextStyle(
          color: Colors.black54,
          fontSize: 15,
          fontWeight: FontWeight.normal,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(
          Icons.gps_not_fixed_outlined,
          color: Color(0xFF000000),
          size: 20,
        ),
        controller: destinoController,
      ),
    );
  }

  @override
  void initState() {
    getCurrentLocation();

    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  void onCreated(GoogleMapController controller) {
    destinoController.text = controller as String;
  }

  void onCameraMove(CameraPosition position) async {
    setState(() {
      buscando = false;
      currentLocation = position.target;
    });
  }

  void getMoveCamera() async {
    List<Placemark> placemark = await placemarkFromCoordinates(
        currentLocation.latitude, currentLocation.longitude);
    setState(() {
      String address =
          "${placemark[0].name.toString()}, ${placemark[0].locality.toString()}, ${placemark[0].country.toString()}";
      destinoController.text = address;
      desc_destino_pedido = address.toString();
      destinoV1 = currentLocation.latitude;
      destinoV2 = currentLocation.longitude;
      destino_pedido = "$destinoV1,$destinoV2";
    });
  }

  CalculaViagem(double Latorigem, double Longorigem, double Latdestino,
      double Longdestino) async {
    try {
      calc_distancia_viatura = 0;
      String origem = "";
      String destino = "";
      origem = "$Latorigem,$Longorigem";
      destino = "$Latdestino,$Longdestino";
      String baseURL =
          "https://maps.googleapis.com/maps/api/distancematrix/json";
      String request =
          "$baseURL?units=imperial&origins=$origem&destinations=$destino&key=$google_api_key";
      final response = await http.get(Uri.parse(request));
      final map = json.decode(response.body);
      final res = map['rows'];
      final data = res[0]['elements'];
      final data2 = data[0]["distance"];
      setState(() {
        calc_distancia_viatura = data2["value"] / 1000;
      });
      // distancia = data2["text"];
      // var dados = data[0]['duration'];
      // tempo = dados["text"];
      // data = map["elements"];
    } catch (e) {
      print(e);
    }
  }

  Widget btnDefinir() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          calc_distancia_viatura = 0;
          distance_rota = Geolocator.distanceBetween(
              posicaoV1, posicaoV2, destinoV1, destinoV2);
          calc_distancia_viatura = distance_rota / 1000;
          // ignore: use_build_context_synchronously
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => SelectViaturaPage()));
        },
        child: const Text(
          'Definir Destino',
          style: TextStyle(
            color: Colors.black,
            fontSize: 15.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
          textAlign: TextAlign.center,
          overflow: TextOverflow.fade,
          maxLines: 1,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          SafeArea(
            child: GoogleMap(
              mapType: MapType.normal,
              initialCameraPosition: _initialLocation,
              myLocationEnabled: true,
              myLocationButtonEnabled: false,
              zoomGesturesEnabled: true,
              zoomControlsEnabled: false,
              onMapCreated: (GoogleMapController controller) async {
                _controller.complete(controller);
              },
              onCameraMove: onCameraMove,
              onCameraIdle: () async {
                setState(() {
                  buscando = true;
                  getMoveCamera();
                });
              },
            ),
          ),
          Container(
            alignment: Alignment.topCenter,
            child: Card(
                elevation: 2,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const SizedBox(
                      height: 100,
                    ),
                    TxtDestino(),
                  ],
                )),
          ),
          Container(
            alignment: Alignment.center,
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.location_on,
                  size: 70,
                  color: Color(0xFFEDBD1D),
                )
              ],
            ),
          ),
          Container(
            alignment: Alignment.bottomCenter,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                btnDefinir(),
                const SizedBox(
                  height: 100,
                )
              ],
            ),
          ),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Definir Rota pelo Mapa",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFFEDBD1D),
        elevation: 5,
        iconTheme: const IconThemeData(color: Colors.white, size: 40),
      ),
    );
  }
}
