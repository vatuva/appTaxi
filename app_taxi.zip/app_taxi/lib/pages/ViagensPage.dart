import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:http/http.dart' as http;
import '../config/Constats.dart';
import '../modelos/CardViagens.dart';
import 'PrincipalPage.dart';

var dadosViagem;

class ViagensPage extends StatefulWidget {
  const ViagensPage({super.key});

  @override
  _ViagensPage createState() => _ViagensPage();
}

class _ViagensPage extends State<ViagensPage> {
  final TextEditingController chatController = TextEditingController();
  DateTime now = DateTime.now();
  late TextEditingController data1;
  late TextEditingController data2;
  var dataActual = DateTime.now().add(const Duration(days: -7));
  var dataActual2 = DateTime.now().add(const Duration(days: 1));

  bool carregadoV = false;

  Widget InfoBar() {
    return Container(
        width: MediaQuery.of(context).size.width,
        height: 50,
        decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(0),
                bottomLeft: Radius.zero,
                bottomRight: Radius.zero,
                topRight: Radius.zero),
            color: Colors.white),
        child: Row(
          children: [
            Row(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width - 50,
                      height: 50,
                      child: const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            "0.00",
                            style: TextStyle(
                              fontSize: 25,
                              fontFamily: 'Gotham',
                              fontWeight: FontWeight.bold,
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  width: 50,
                  height: 50,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                  //    _BtnChat(),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ));
  }

  Future CarregarViagens() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/listar/viagens');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "data1": data1.text,
        "data2": data2.text,
      });
      final map = json.decode(response.body);
      setState(() {
        dadosViagem = map['viagens'];
        carregadoV = true;
      });
      print(dadosViagem);
    } catch (e) {
      print(e);
    }
  }

  Widget _daoViagens() {
    return Container(
      height: MediaQuery.of(context).size.height / 1.3,
      margin: const EdgeInsets.only(top: 80),
      child: !carregadoV
          ? const Text(
              "Carregando...",
              style: TextStyle(
                fontFamily: "Gotham",
                fontSize: 12,
              ),
            )
          : ListView.builder(
              scrollDirection: Axis.vertical,
              itemCount: dadosViagem.length,
              itemBuilder: (BuildContext context, int index) {
                return CardViagens(
                  origem: dadosViagem[index]['desc_origem'],
                  id: dadosViagem[index]['id'],
                  destino: dadosViagem[index]['desc_destino'],
                  data: dadosViagem[index]['inicio_viagem'],
                );
              },
            ),
    );
  }


  @override
  void initState() {
    data1 = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual));
    data2 = TextEditingController(
        text: DateFormat('yyyy-MM-dd').format(dataActual2));
    CarregarViagens();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
        body: Stack(
          children: [
            Container(
              alignment: Alignment.center,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  _daoViagens(),
                ],
              ),
            ),
            Container(
              alignment: Alignment.bottomCenter,
              child: const Row(
                children: [
                  Row(
                    children: [
                      //  InfoBar(),
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      appBar: AppBar(
        title: const Text(
          "Histórico de Viagens",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFFEDBD1D),
        elevation: 5,
        iconTheme: const IconThemeData(color: Colors.white, size: 40),
      ),
      );
  }

  Future<void> showDate1(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2000),
    );
    setState(() {
      String selectdata1 = DateFormat('yyyy-MM-dd').format(picked!);
      data1 = TextEditingController(text: selectdata1);
      setState(() {
        CarregarViagens();
        print(data1.text);
      });
    });
  }

  Future<void> showDate2(BuildContext context) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      lastDate: DateTime(2101),
      firstDate: DateTime(2000),
    );
    setState(() {
      String Selectdata2 = DateFormat('yyyy-MM-dd').format(picked!);
      data2 = TextEditingController(text: Selectdata2);
      setState(() {
        CarregarViagens();
        print(data2.text);
      });
    });
  }

  Widget _Data1() {
    return Column(
      children: <Widget>[
        Container(
          alignment: Alignment.centerLeft,
          height: 45.0,
          width: MediaQuery.of(context).size.width / 2.2,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            onTap: () async {
              await showDate1(context);
            },
            readOnly: true,
            controller: data1,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
              fontSize: 14,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(
                Icons.calendar_today,
                color: Color(0xFF00008B),
              ),
              hintText: 'Data inicial',
            ),
          ),
        ),
      ],
    );
  }

  Widget _Data2() {
    return Column(
      children: <Widget>[
        Container(
          alignment: Alignment.centerLeft,
          height: 45.0,
          width: MediaQuery.of(context).size.width / 2.2,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            onTap: () async {
              await showDate2(context);
            },
            readOnly: true,
            controller: data2,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
              fontSize: 14,
            ),
            decoration: const InputDecoration(
              border: InputBorder.none,
              prefixIcon: Icon(
                Icons.calendar_today,
                color: Color(0xFF00008B),
              ),
              hintText: 'Data final',
            ),
          ),
        ),
      ],
    );
  }
}
