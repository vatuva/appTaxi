import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../config/Constats.dart';

class PrivacyPolicyScreen extends StatefulWidget {
  const PrivacyPolicyScreen({Key? key}) : super(key: key);

  @override
  State<PrivacyPolicyScreen> createState() => _PrivacyPolicyScreenState();
}

class _PrivacyPolicyScreenState extends State<PrivacyPolicyScreen> {
  final String _policyTitle = 'Política de Privacidade - Vambora';
  final String _lastUpdated = 'Última actualização: Dezembro de 2025';

  final String _policyText = '''
O Vambora respeita a sua privacidade e compromete-se a proteger as informações pessoais fornecidas pelos nossos utilizadores. Esta política explica como recolhemos, utilizamos e protegemos os seus dados.

1. Informações Recolhidas
Dados pessoais fornecidos pelo utilizador (nome, e-mail e telefone).
Informações de utilização do app (histórico de corridas, preferências).

2. Uso das Informações
As informações recolhidas são utilizadas para:

Processar e pedido de corrida.
Garantir a ligação entre clientes e o motorista.
Melhorar a experiência do utilizador e oferecer recomendações personalizadas.
Cumprir requisitos legais e de segurança.

3. Partilha de Informações
Os dados podem ser partilhados apenas com:

Motoristas licenciados para processar pedido de corrida.
Serviços de pagamento, quando necessário.
Autoridades legais, em caso de obrigação regulatória.

4. Segurança
Adotamos medidas técnicas e organizacionais para proteger as suas informações contra acesso não autorizado, alteração ou perda.

5. Direitos do Utilizador
O utilizador pode solicitar a correção, actualização ou eliminação dos seus dados a qualquer momento através do suporte.

6. Contacto
Se tiver dúvidas sobre esta Política de Privacidade, entre em contacto pelo e-mail: suporte@mvcon.net
''';

  void _copyPolicyToClipboard() async {
    await Clipboard.setData(
        ClipboardData(text: '"$_policyTitle"\n$_lastUpdated\n\n$_policyText'));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Política copiada para a área de transferência')),
    );
  }

  void _showShareOptions() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text(
              'Funcionalidade de partilha não ativada. Adicione `share_plus` para habilitar.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Política de Privacidade",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFFEDBD1D),
        elevation: 5,
        iconTheme: const IconThemeData(color: Colors.white, size: 40),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(_policyTitle, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              Text(_lastUpdated, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              const SizedBox(height: 18),
              Card(
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 2,
                child: const Padding(
                  padding: EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Resumo rápido', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                      SizedBox(height: 8),
                      Text(
                          'Recolha de dados pessoais e de uso; partilha limitada com parceiros; medidas de segurança; direitos do utilizador e contacto para suporte.'),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 18),
              _buildSectionTitle('1. Informações Recolhidas'),
              const SelectableText(
                  'Dados pessoais fornecidos pelo utilizador (nome, e-mail, telefone).\nInformações de utilização do app (histórico de corrida).'),

              const SizedBox(height: 12),

              _buildSectionTitle('2. Uso das Informações'),
              const SelectableText(
                  'As informações recolhidas são utilizadas para:\n\n• Processar pedidos de corrida.\n• Garantir a ligação entre clientes e motoristas.\n• Melhorar a experiência do utilizador e oferecer recomendações personalizadas.\n• Cumprir requisitos legais e de segurança.'),

              const SizedBox(height: 12),

              _buildSectionTitle('3. Partilha de Informações'),
              const SelectableText(
                  'Os dados podem ser partilhados apenas com:\n\n• Motoristas licenciados para processar pedidos de corrida.\n• Serviços de pagamento, quando necessário.\n• Autoridades legais, em caso de obrigação regulatória.'),

              const SizedBox(height: 12),

              _buildSectionTitle('4. Segurança'),
              const SelectableText(
                  'Adotamos medidas técnicas e organizacionais para proteger as suas informações contra acesso não autorizado, alteração ou perda.'),

              const SizedBox(height: 12),

              _buildSectionTitle('5. Direitos do Utilizador'),
              const SelectableText(
                  'O utilizador pode solicitar a correção, actualização ou eliminação dos seus dados a qualquer momento através do suporte.'),

              const SizedBox(height: 12),

              _buildSectionTitle('6. Contacto'),
              const SelectableText(
                  'Se tiver dúvidas sobre esta Política de Privacidade, entre em contacto pelo e-mail: geral@vambora.com'),

              const SizedBox(height: 24),

              // Botões de ação
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _copyPolicyToClipboard,
                      icon: const Icon(Icons.copy),
                      label: const Text('Copiar Política'),
                    ),
                  ),
                  const SizedBox(width: 12),
                ],
              ),
              const SizedBox(height: 12),
              const Center(
                child: Text('Versão Vambora:$versionApp', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
              ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6.0),
      child: Text(title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
    );
  }
}
