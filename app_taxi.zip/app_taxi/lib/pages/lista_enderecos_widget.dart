import 'package:flutter/material.dart';
import '../modelos/Endereco_Model.dart';

class ListaEnderecosWidget extends StatelessWidget {
  final List<EnderecoModel> enderecos;
  final IconData icon;
  final Function(EnderecoModel) onTap;

  const ListaEnderecosWidget({
    Key? key,
    required this.enderecos,
    required this.onTap,
    this.icon = Icons.location_on,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      separatorBuilder: (_, __) => const Divider(height: 2),
      itemCount: enderecos.length,
      itemBuilder: (context, index) {
        final item = enderecos[index];

        return ListTile(
          leading: Icon(icon),
          title: Text(
            item.formatted,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 14,
            ),
          ),
          subtitle: Text(
            item.addressLine,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 11),
          ),
          onTap: () => onTap(item),
        );
      },
    );
  }
}
