import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';

// ignore: depend_on_referenced_packages
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import 'package:material_dialogs/material_dialogs.dart';
import 'package:http/http.dart' as http;
import 'package:panara_dialogs/panara_dialogs.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import '../config/Constats.dart';
import 'EditarPerfilPage.dart';
import 'EditarSenhaPage.dart';
import 'Loading.dart';
import 'PrincipalPage.dart';
import 'PromocaoPage.dart';
import 'SelectViaturaPage.dart';
import 'SplashPage.dart';

class PerfilPage extends StatefulWidget {
  @override
  _PerfilPage createState() => _PerfilPage();
}

class _PerfilPage extends State<PerfilPage> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();

  final TextEditingController _email = TextEditingController();
  final TextEditingController _nome = TextEditingController();
  final TextEditingController _sobrenome = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  File? file;

  loading load = loading();



  Widget BarraInferior() {
    return Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height * 0.30,
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(20),
              bottomLeft: Radius.circular(0),
              bottomRight: Radius.circular(0),
              topRight: Radius.circular(20)),
          // color: Colors.white,
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Colors.white,
              Color(0xFFEDEEE9),
            ],
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            const Divider(
              height: 20,
              color: Colors.white,
            ),
            ListTile(
              onTap: () {
                Navigator.of(context).push(CupertinoPageRoute(
                    builder: (BuildContext context) => EditarSenhaPage()));
              },
              leading: const Icon(
                Icons.lock_outline,
                size: 25,
                color: Colors.black,
              ),
              title: const Text(
                "Actualizar Senha",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 16.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const Divider(
              height: 20,
              color: Colors.black12,
            ),
            ListTile(
              onTap: () {
                Dialogs.bottomMaterialDialog(
                    msg: 'Deseja terminar a sessão?',
                    title: 'Sair do Aplicativo',
                    context: context,
                    actions: [
                      IconsOutlineButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        text: 'Não',
                        iconData: Icons.cancel_outlined,
                        textStyle: const TextStyle(color: Color(0xFFEDBD1D)),
                        iconColor: Colors.white,
                      ),
                      IconsButton(
                        onPressed: () async {
                          await SessionManager().set("sessao_usuario", 0);
                          CodigoCupom = "";
                          await SessionManager().set("CodigoCupom", "");
                          ValorCupom = "";
                          await SessionManager().set("ValorCupom", "");
                          // ignore: use_build_context_synchronously
                          Future.delayed(const Duration(milliseconds: 3000),
                              () async {
                            await showDialog(
                              context: context,
                              builder: (context) =>
                                  FutureProgressDialog(load.getFuture()),
                            );
                            if (Platform.isAndroid) {
                              SystemNavigator.pop();
                            } else if (Platform.isIOS) {
                              exit(0);
                            }
                          });
                        },
                        text: 'Sim',
                        iconData: Icons.exit_to_app_sharp,
                        color: const Color(0xFFFF0066),
                        textStyle: const TextStyle(color: Colors.white),
                        iconColor: Colors.white,
                      ),
                    ]);
              },
              leading: const Icon(
                Icons.exit_to_app_outlined,
                size: 25,
                color: Colors.black54,
              ),
              title: const Text(
                "Terminar Sessão",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 16.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const Divider(
              height: 20,
              color: Colors.black12,
            ),
            ListTile(
              onTap: () {
                Dialogs.bottomMaterialDialog(
                    msg: 'Deseja excluir a sua conta?',
                    title: 'Excluir Perfil',
                    context: context,
                    actions: [
                      IconsOutlineButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                        },
                        text: 'Não',
                        iconData: Icons.cancel_outlined,
                        color: Colors.green,
                        textStyle: const TextStyle(color: Colors.white),
                        iconColor: Colors.white,
                      ),
                      IconsButton(
                        onPressed: () {
                          Navigator.of(context).pop();
                          ExcluirPerfil();
                        },
                        text: 'Sim',
                        iconData: Icons.done_outline,
                        color: const Color(0xFFFF0066),
                        textStyle: const TextStyle(color: Colors.white),
                        iconColor: Colors.white,
                      ),
                    ]);
              },
              leading: const Icon(Icons.delete, size: 25, color: Colors.red),
              title: const Text(
                "Eliminar a Conta",
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 16.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham',
                ),
              ),
            ),
            const Divider(
              height: 20,
              color: Colors.black12,
            ),
          ],
        ));
  }



  Future ExcluirPerfil() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/conta/excluir');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      if (msgr == 1) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Perfil excluido com sucesso.',
          ),
        );
        await SessionManager().set("sessao_usuario", 0);
        await SessionManager().set("idPassageiro", "");
        await SessionManager().set("ChavePublica", "");
        CodigoCupom = "";
        await SessionManager().set("CodigoCupom", "");
        // ignore: use_build_context_synchronously
        Future.delayed(const Duration(milliseconds: 3000), () async {
          await showDialog(
            context: context,
            builder: (context) => FutureProgressDialog(load.getFuture()),
          );
          if (Platform.isAndroid) {
            SystemNavigator.pop();
          } else if (Platform.isIOS) {
            exit(0);
          }
        });
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao excluir o registo.',
          ),
        );
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        CustomSnackBar.error(
          message: 'Ops! Ocorreu um erro. Erro $e.',
        ),
      );
    }
  }




  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFEDEEE9),
      body: Stack(
        children: [
          SafeArea(
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 10,
                  top: 10,
                  right: 10,
                ),
                child: Column(
                  children: [
                    Card(
                      margin: const EdgeInsets.all(0),
                      elevation: 5,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10)),
                      ),
                      child: Container(
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(10),
                                bottomRight: Radius.circular(10),
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                            gradient: LinearGradient(
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                                colors: [
                                  Color(0xFFFFFFFF),
                                  Color(0xFFFFFFFF)
                                ])),
                        height: 100,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ListTile(
                              onTap: () {
                                Navigator.of(context).push(CupertinoPageRoute(
                                    builder: (BuildContext context) =>
                                        EditarPerfilPage()));
                              },
                              leading: CircleAvatar(
                                  backgroundColor: const Color(0xFFEDBD1D),
                                  radius: 50,
                                  backgroundImage: file == null
                                      ? Image.network(fotoPerfil).image
                                      : Image.file(File(file!.path)).image),
                              trailing: const Icon(Icons.edit,
                                  size: 25, color: Color(0xFFEDBD1D)),
                              title: Text(
                                '$nomePassageiro $sobrenomePassageiro',
                                style: const TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              )),
          SafeArea(
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 10,
                  top: 120,
                  right: 10,
                ),
                child: Column(
                  children: [
                    Card(
                      margin: const EdgeInsets.all(0),
                      elevation: 5,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10)),
                      ),
                      child: Container(
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(10),
                                bottomRight: Radius.circular(10),
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                            gradient: LinearGradient(
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                                colors: [
                                  Color(0xFFFFFFFF),
                                  Color(0xFFFFFFFF)
                                ])),
                        height: 200,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ListTile(
                              onTap: () {
                                Navigator.of(context).push(CupertinoPageRoute(
                                    builder: (BuildContext context) => EditarSenhaPage()));
                              },
                              leading:const Icon(Icons.lock_clock_outlined,
                                  size: 25, color: Color(0xFFEDBD1D)),
                              trailing: const Icon(Icons.navigate_next,
                                  size: 25, color: Color(0xFFEDBD1D)),
                              title: const Text(
                                'Alterar Senha',
                                style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                            const Divider(height: 10,),
                            ListTile(
                              onTap: () {
                                PanaraConfirmDialog.showAnimatedGrow(
                                  color: Colors.red,
                                  context,
                                  title: "Terminar Sessão",
                                  message: "Tem certeza que deseja terminar Sessão?",
                                  confirmButtonText: "Não",
                                  cancelButtonText: "Sim",
                                  onTapConfirm: () {
                                    Navigator.pop(context);
                                  },
                                  onTapCancel: () async{
                                    await SessionManager().set("sessao_usuario", 0);
                                    CodigoCupom = "";
                                    await SessionManager().set("CodigoCupom", "");
                                    ValorCupom = "";
                                    await SessionManager().set("ValorCupom", "");
                                    // ignore: use_build_context_synchronously
                                    Future.delayed(const Duration(milliseconds: 3000),
                                            () async {
                                          await showDialog(
                                            context: context,
                                            builder: (context) =>
                                                FutureProgressDialog(load.getFuture()),
                                          );
                                          if (Platform.isAndroid) {
                                            SystemNavigator.pop();
                                          } else if (Platform.isIOS) {
                                            exit(0);
                                          }
                                        });
                                  },
                                  panaraDialogType: PanaraDialogType.warning,
                                );
                              },
                              leading:const Icon(Icons.exit_to_app_rounded,
                                  size: 25, color: Colors.red),
                              trailing: const Icon(Icons.navigate_next,
                                  size: 25, color: Color(0xFFEDBD1D)),
                              title: const Text(
                                'Terminar sessão',
                                style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              )),
          SafeArea(
              child: Padding(
                padding: const EdgeInsets.only(
                  left: 10,
                  top: 350,
                  right: 10,
                ),
                child: Column(
                  children: [
                    Card(
                      margin: const EdgeInsets.all(0),
                      elevation: 5,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10),
                            topLeft: Radius.circular(10),
                            topRight: Radius.circular(10)),
                      ),
                      child: Container(
                        decoration: const BoxDecoration(
                            borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(10),
                                bottomRight: Radius.circular(10),
                                topLeft: Radius.circular(10),
                                topRight: Radius.circular(10)),
                            gradient: LinearGradient(
                                begin: Alignment.bottomCenter,
                                end: Alignment.topCenter,
                                colors: [
                                  Color(0xFFFFFFFF),
                                  Color(0xFFFFFFFF)
                                ])),
                        height: 75,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            ListTile(
                              onTap: () {
                                PanaraConfirmDialog.showAnimatedGrow(
                                  color: Colors.red,
                                  context,
                                  title: "Apagar Conta",
                                  message: "Tem certeza que deseja Apagar Conta?",
                                  confirmButtonText: "Não",
                                  cancelButtonText: "Sim",
                                  onTapConfirm: () {
                                    Navigator.pop(context);
                                  },
                                  onTapCancel: () {
                                    Navigator.of(context).pop();
                                    ExcluirPerfil();
                                  },
                                  panaraDialogType: PanaraDialogType.warning,
                                );
                              },
                              leading:const Icon(Icons.delete,
                                  size: 25, color: Colors.red),
                              trailing: const Icon(Icons.navigate_next,
                                  size: 25, color: Color(0xFFEDBD1D)),
                              title: const Text(
                                'Apagar a Conta',
                                style: TextStyle(
                                  color: Colors.red,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.normal,
                                  fontFamily: 'gotham',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Minha Conta",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFFEDBD1D),
        elevation: 5,
        iconTheme: const IconThemeData(color: Colors.white, size: 40),
      ),
    );
  }
}
