import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:vambora_passageiro/pages/DigitePinPageRegisto.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import '../config/Constats.dart';
import 'CarregarPerfilPage.dart';
import 'LoginPage.dart';
import 'PrincipalPage.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'Loading.dart';
import 'PrivacyPolicyScreen.dart';
import 'SplashPage.dart';
import 'package:flutter_cached_pdfview/flutter_cached_pdfview.dart';

var numeroTel;

class TelaRegisto extends StatefulWidget {
  @override
  _TelaRegisto createState() => _TelaRegisto();
}

class _TelaRegisto extends State<TelaRegisto> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();

  final TextEditingController _email = TextEditingController();
  final TextEditingController _nome = TextEditingController();
  final TextEditingController _sobrenome = TextEditingController();
  final globalKey = GlobalKey<FormState>();
  late bool _toggleVisibility = true;
  var seguro = true;
  final TextEditingController PhoneController = TextEditingController();
  final TextEditingController _senha = TextEditingController();

  loading load = loading();

  Future Registar() async {
    setState(() {
      btnRg2 = true;
    });
    try {
      var url = Uri(
          scheme: 'https', host: dom, path: '$endpoint/passageiroapi/cadastro');
      var response = await http.post(url, body: {
        "telefone": PhoneController.text.toString(),
        "email": _email.text.toString(),
        "senha": _senha.text.toString(),
        "nome": _nome.text.toString(),
        "apelido": _sobrenome.text.toString()
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final dados = map["perfil_passageiro"];
      final cp = map["chave_publica"];
      final msg = map["msg"];
      idPassageiro = dados["id"];
      ChavePublica = cp;
      if (msgr == 1) {
        numeroTel = PhoneController.text;
        // ignore: use_build_context_synchronously
        await showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        if (file == null) {
          ValidarNumero();
          setState(() {
            btnRg2 = false;
          });
          Navigator.of(context).pushReplacement(CupertinoPageRoute(
              builder: (BuildContext context) => DigitePinPageRegisto()));
        } else {
          _UploadFoto();
        }
      } else if (msgr == 0) {
        print(msg);
        showTopSnackBar(
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Lamentamos! A conta que deseja criar, já existe.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg2 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message: 'Lamentamos! A conta que deseja criar, já existe.',
        ),
      );
    }
  }

  @override
  void initState() {
    super.initState();
  }

  File? file;

  Future _UploadFoto() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/alterarfoto');
      var response = await http.MultipartRequest('POST', url);
      response.fields['id'] = idPassageiro.toString();
      response.fields['chave_publica'] = ChavePublica.toString();
      var pic = await http.MultipartFile.fromPath("foto", file!.path);
      response.files.add(pic);
      var res = await response.send();
      if (res.statusCode == 200) {
        ValidarNumero();
        setState(() {
          btnRg2 = false;
        });
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => DigitePinPageRegisto()));
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message:
                'Ocorreu um erro ao carregar a foto de perfil. Por favor, tente novamente mais tarde.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg2 = false;
      });
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
      print("erro de foto");
      print(e);
    }
  }

  Future ValidarNumero() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/activar/passo1');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final msg = map["msg"];
      if (msgr == 1) {
        // ignore: use_build_context_synchronously
      } else if (msgr == 0) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'O número de telemóvel informado é inválido.',
          ),
        );
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Não foi possível completar a acção. Tente novamente mais tarde.',
        ),
      );
    }
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor:
                _checked == false ? Colors.grey : const Color(0xFFEDBD1D),
            elevation: 10,
            padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: _checked == false
            ? null
            : btnRg2 == false
                ? () {
                    if (_nome.text == '') {
                      showTopSnackBar(
                        // ignore: use_build_context_synchronously
                        Overlay.of(context),
                        const CustomSnackBar.error(
                          message: 'Ops! Por favor, Informe o seu nome.',
                        ),
                      );
                    } else if (_sobrenome.text == '') {
                      showTopSnackBar(
                        // ignore: use_build_context_synchronously
                        Overlay.of(context),
                        const CustomSnackBar.error(
                          message: 'Ops! Por favor, Informe o seu sobrenome.',
                        ),
                      );
                    } else if (PhoneController.text == '') {
                      showTopSnackBar(
                        // ignore: use_build_context_synchronously
                        Overlay.of(context),
                        const CustomSnackBar.error(
                          message: 'Ops! Por favor, Informe o seu Telefone.',
                        ),
                      );
                    } else if (_email.text == '') {
                      showTopSnackBar(
                        // ignore: use_build_context_synchronously
                        Overlay.of(context),
                        const CustomSnackBar.error(
                          message: 'Ops! Por favor, Informe o seu e-mail.',
                        ),
                      );
                    } else if (_senha.text == '') {
                      showTopSnackBar(
                        // ignore: use_build_context_synchronously
                        Overlay.of(context),
                        const CustomSnackBar.error(
                          message:
                              'Ops! Por favor, Informe a sua Palavra-passe.',
                        ),
                      );
                    } else {
                      Registar();
                    }
                  }
                : () {},
        child: btnRg1 == false
            ? const Text(
                'Registar',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator(
                backgroundColor: Color(0xFFEDBD1D),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  Widget _BtnEntrar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
          style: TextButton.styleFrom(
              backgroundColor: const Color(0xFFFFFFFF),
              elevation: 10,
              padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
              shape: RoundedRectangleBorder(
                side: const BorderSide(width: 1, color: Color(0xFFEDBD1D)),
                borderRadius: BorderRadius.circular(90),
              )),
          onPressed: () {
            Navigator.of(context).push(CupertinoPageRoute(
                builder: (BuildContext context) => LoginPage()));
          },
          child: const Text(
            'Entrar',
            style: TextStyle(
              color: Color(0xFFEDBD1D),
              fontSize: 18.0,
              fontWeight: FontWeight.w900,
              fontFamily: 'gotham',
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.fade,
            maxLines: 1,
          )),
    );
  }

  Widget _TxtNome() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 55,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "Nome",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.person,
              size: 25,
              color: Color(0xFF000000),
            ),
            validator: FormValidation.requiredTextField,
            controller: _nome,
          ),
        ));
  }

  Widget _TxtSobreNome() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 55,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "Sobrenome",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.person,
              size: 25,
              color: Color(0xFF000000),
            ),
            validator: FormValidation.requiredTextField,
            controller: _sobrenome,
          ),
        ));
  }

  Widget _TxtEmail() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 55,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "E-mail",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.email,
              color: Color(0xFF000000),
              size: 25,
            ),
            validator: FormValidation.requiredTextField,
            controller: _email,
          ),
        ));
  }

  Widget _TxtSenha() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 55,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "Palavra-passe",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.lock_outline,
              color: Color(0xFF000000),
              size: 25,
            ),
            suffixIcon: IconButton(
              onPressed: () {
                setState(() {
                  _toggleVisibility = !_toggleVisibility;
                });
              },
              icon: _toggleVisibility
                  ? const Icon(
                      Icons.visibility_off_outlined,
                      size: 20,
                    )
                  : const Icon(
                      Icons.visibility_outlined,
                      size: 20,
                    ),
              color: const Color(0xFF000000),
            ),
            validator: FormValidation.requiredTextField,
            controller: _senha,
            obscureText: _toggleVisibility,
          ),
        ));
  }

  String text = "";
  int maxLength = 9;

  Widget _TxtTelefone() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 55,
          child: MaterialTextField(
            onChanged: (String newVal) {
              if (newVal.length <= maxLength) {
                text = newVal;
              } else {
                PhoneController.text = text;
              }
            },
            keyboardType: TextInputType.number,
            hint: "Telefone",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.phone_android_outlined,
              color: Color(0xFF000000),
              size: 25,
            ),
            validator: FormValidation.requiredTextField,
            controller: PhoneController,
          ),
        ));
  }

  bool _checked = false;

  Widget _TxtTermos() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.7,
      height: 50,
      child: CheckboxListTile(
        controlAffinity: ListTileControlAffinity.platform,
        value: _checked,
        onChanged: (bool? value) {
          setState(() {
            _checked = value!;
          });
        },
        title: const Text(
          'Concordo com os termos',
          style: TextStyle(
            decoration: TextDecoration.none,
            color: Colors.black87,
            fontSize: 14.0,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }

  Widget _BtnBack() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFFFFFF),
            elevation: 0,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.of(context).pop();
        },
        child: const Icon(
          CupertinoIcons.arrow_left,
          color: Color(0xFF000000),
          size: 40,
        ),
      ),
    );
  }

  Widget _btnOR() {
    return GestureDetector(
      onTap: () => null,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            children: [
              Container(
                  height: 2,
                  color: Colors.black12,
                  width: MediaQuery.of(context).size.width * 0.4)
            ],
          ),
          Column(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width * 0.01),
              const Text(
                "  ",
                style: TextStyle(
                  color: Colors.black12,
                  fontSize: 12.0,
                  fontWeight: FontWeight.normal,
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width * 0.01)
            ],
          ),
          Column(
            children: [
              Container(
                  height: 2,
                  color: Colors.black12,
                  width: MediaQuery.of(context).size.width * 0.4)
            ],
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(20),
                              bottomRight: Radius.circular(20),
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20)),
                          gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)])),
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.9,
                      margin: const EdgeInsets.all(0),
                      child: Container(
                        margin: const EdgeInsets.only(
                            right: 5, top: 50, left: 5, bottom: 5),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text(
                              'Criar uma conta',
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: 20.0,
                                fontWeight: FontWeight.normal,
                                fontFamily: 'gotham',
                              ),
                              textAlign: TextAlign.left,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            _TxtNome(),
                            const SizedBox(
                              height: 5,
                            ),
                            _TxtSobreNome(),
                            const SizedBox(
                              height: 5,
                            ),
                            _TxtTelefone(),
                            const SizedBox(
                              height: 5,
                            ),
                            _TxtEmail(),
                            const SizedBox(
                              height: 5,
                            ),
                            _TxtSenha(),
                            const SizedBox(
                              height: 10,
                            ),
                            TextButton(
                              onPressed: ()  async {
                                Navigator.of(context).push(CupertinoPageRoute(
                                    builder: (BuildContext context) => const PrivacyPolicyScreen()));
                              },
                              child: const Text(
                                'Ler os termos de privacidade.',
                                style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 14.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            _TxtTermos(),
                            _BtnComecar(),
                            const SizedBox(
                              height: 20,
                            ),
                            _btnOR(),
                            const SizedBox(
                              height: 10,
                            ),
                            const Text(
                              'Já tem uma conta?',
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: 14.0,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            _BtnEntrar(),
                          ],
                        ),
                      )),
                ],
              ),
            ),
            Positioned(
                left: 10.0,
                top: 40.0,
                width: 60,
                child: FittedBox(
                  alignment: Alignment.center,
                  //fit: BoxFit.fill,
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(100),
                            bottomRight: Radius.circular(100),
                            topLeft: Radius.circular(100),
                            topRight: Radius.circular(100)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Colors.white, Colors.white])),
                    width: 60,
                    height: 60,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [_BtnBack()],
                    ),
                  ),
                )),
          ],
        ));
  }
}
