import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
// ignore: depend_on_referenced_packages
import 'package:http/http.dart' as http;
import 'package:vambora_passageiro/pages/RadarPage.dart';
import '../config/Constats.dart';
import '../modelos/CardChat.dart';
import 'PrincipalPage.dart';
import 'package:url_launcher/url_launcher.dart';

class ChatPage extends StatefulWidget {
  @override
  _ChatPage createState() => _ChatPage();
}

class _ChatPage extends State<ChatPage> {
  final TextEditingController chatController = TextEditingController();

  var carregado = false;
  var dadosChat;

  Future getChat() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/chat/ver-msg";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave": ChavePublica.toString(),
        "motorista": id_motorista.toString(),
      });
      final map = json.decode(response.body);
      dadosChat = map["mensagens"];
      setState(() {
        carregado = true;
        abrirSMS();
      });
    } catch (e) {
      print(e);
    }
  }

  Future abrirSMS() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/chat/abrir-msg";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      var msgChat = map["mensagens"];
    } catch (e) {
      print(e);
    }
  }

  Future verificarSMS() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/chat/notificacao";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      var msgChat = map["mensagens"];
      var msgRotorno = map["retorno"];
      if (msgRotorno == 1) {}
    } catch (e) {
      print(e);
    }
  }

  Future addChat() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/chat/enviar-msg";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave_passageiro": ChavePublica.toString(),
        "motorista": id_motorista.toString(),
        "mensagem": chatController.text,
      });
      final map = json.decode(response.body);
      final msgChat = map["msg"];
      getChat();
    } catch (e) {
      print(e);
    }
  }

  Future addChat2(String msg) async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/chat/enviar-msg";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave_passageiro": ChavePublica.toString(),
        "motorista": id_motorista.toString(),
        "mensagem": msg.toString(),
      });
      final map = json.decode(response.body);
      final msgChat = map["msg"];
      getChat();
    } catch (e) {
      print(e);
    }
  }

  Widget _daoChat() {
    return Container(
      height: MediaQuery.of(context).size.height / 1.3,
      margin: const EdgeInsets.only(top: 80),
      child: !carregado
          ? const Text("Carregando...")
          : ListView.builder(
        scrollDirection: Axis.vertical,
        itemCount: dadosChat.length,
        itemBuilder: (BuildContext context, int index) {
          return CardChat(
            mensagem: dadosChat[index]['mensagem'],
            id: dadosChat[index]['id'],
            data: dadosChat[index]['data'],
            hora: dadosChat[index]['hora'],
            status: dadosChat[index]['status_motorista'],
          );
        },
      ),
    );
  }

  Future<void> _Call() async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: contacto_motorista,
    );
    print(contacto_motorista);
    await launchUrl(launchUri);
  }

  Widget InfoBar() {
    return Container(
        width: MediaQuery.of(context).size.width,
        height: 60,
        decoration: const BoxDecoration(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(0),
                bottomLeft: Radius.zero,
                bottomRight: Radius.zero,
                topRight: Radius.zero),
            color: Colors.white),
        child: Row(
          children: [
            Row(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: MediaQuery.of(context).size.width - 50,
                      height: 50,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          TxtChat(),
                        ],
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  width: 50,
                  height: 50,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      _BtnChat(),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ));
  }

  Widget TxtChat() {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      height: 50,
      child: MaterialTextField(
        hint: 'Escrever mensagem',
        keyboardType: TextInputType.text,
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.white,
          radius: 0,
        ),
        style: const TextStyle(
          color: Colors.black,
          fontSize: 18,
          fontFamily: 'Gotham',
        ),
        controller: chatController,
      ),
    );
  }

  Widget _BtnCall() {
    return SizedBox(
      width: 40,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 20,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          _Call();
        },
        child: const Icon(
          Icons.call,
          color: Color(0xFF000000),
          size: 30,
        ),
      ),
    );
  }

  Widget _BtnClose() {
    return SizedBox(
      width: 40,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.transparent,
            elevation: 5,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.of(context).pop();
        },
        child: const Icon(
          Icons.close,
          color: Color(0xFF000000),
          size: 30,
        ),
      ),
    );
  }

  Widget _BtnChat() {
    return SizedBox(
      width: 45,
      height: 45,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.white,
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(0),
            )),
        onPressed: () {
          setState(() {
            addChat2(chatController.text);
            getChat();
          });
          chatController.text="";
        },
        child: const Icon(
          Icons.send_outlined,
          color: Color(0xFFEDBD1D),
          size: 30,
        ),
      ),
    );
  }

  Widget SMS() {
    return Container(
        alignment: Alignment.center,
        height: 60,
        child: ListView(scrollDirection: Axis.horizontal, children: [
          _daoMsg(),
        ]));
  }

  List<Map> staticData = tbMsg.data;

  Widget _daoMsg() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.95,
      margin: const EdgeInsets.only(top: 0, bottom: 0, left: 10, right: 10),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: staticData.length,
        itemBuilder: (BuildContext context, int index) => Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
          ),
          child: InkWell(
              onTap: () {
                addChat2(staticData[index]["mensagem"].toString());
                getChat();
              },
              child: Column(
                children: [
                  Row(
                    children: [
                      Card(
                        semanticContainer: true,
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        elevation: 2,
                        color: const Color(0xFFFFFFFF),
                        shadowColor: const Color(0xFF000000),
                        shape: const RoundedRectangleBorder(
                            borderRadius:
                            BorderRadius.all(Radius.circular(10))),
                        child: Stack(
                          alignment: Alignment.center,
                          children: <Widget>[
                            SizedBox(
                              height: 40.0,
                              width: MediaQuery.of(context).size.width * 0.33,
                              child: Container(
                                color: const Color(0xFFFFFFFF),
                              ),
                            ),
                            Positioned(
                                child: Container(
                                  margin: const EdgeInsets.all(0),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        staticData[index]["mensagem"].toString(),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        style: const TextStyle(
                                            fontSize: 10.0,
                                            fontWeight: FontWeight.normal,
                                            color: Color(0xFF000000),
                                            fontFamily: 'gotham'),
                                      ),
                                    ],
                                  ),
                                )),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              )),
        ),
      ),
    );
  }

  @override
  void initState() {
    getChat();
    abrirSMS();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'Gotham'),
      home: Scaffold(
        body: Stack(
          children: [
            Container(
              alignment: Alignment.center,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  _daoChat(),
                ],
              ),
            ),
            // Add listview
            SafeArea(
              child: Align(
                alignment: Alignment.topCenter,
                child: Padding(
                    padding: const EdgeInsets.only(right: 0, bottom: 0, top: 0),
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(0),
                            color: const Color(0xFFEDBD1D),
                          ),
                          width: MediaQuery.of(context).size.width,
                          height: 70,
                          child: Column(
                            children: [
                              const SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 50,
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CircleAvatar(
                                        radius: 25,
                                        backgroundColor: Colors.grey,
                                        child: foto_motorista == null
                                            ? CircleAvatar(
                                          radius: 22,
                                          backgroundImage: Image.asset(
                                              'assets/images/nofoto.png')
                                              .image,
                                        )
                                            : CircleAvatar(
                                          radius: 22,
                                          backgroundImage: Image.network(
                                              urlImagem +
                                                  foto_motorista)
                                              .image,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        width: 5,
                                      )
                                    ],
                                  ),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Text(
                                        '$nome_motorista',
                                        textAlign: TextAlign.center,
                                        style: const TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    )),
              ),
            ),
            Container(
              alignment: Alignment.bottomCenter,
              child: Row(
                children: [
                  Row(
                    children: [
                      InfoBar(),
                    ],
                  )
                ],
              ),
            ),
            SafeArea(
              child: Align(
                alignment: Alignment.topRight,
                child: Padding(
                    padding:
                    const EdgeInsets.only(right: 5, bottom: 0, top: 20),
                    child: Column(
                      children: [
                        _BtnCall(),
                      ],
                    )),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: Alignment.topLeft,
                child: Padding(
                    padding:
                    const EdgeInsets.only(right: 0, bottom: 0, top: 20),
                    child: Column(
                      children: [
                        _BtnClose(),
                      ],
                    )),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: Alignment.topCenter,
                child: Padding(
                    padding:
                    const EdgeInsets.only(right: 0, bottom: 0, top: 70),
                    child: Container(
                      color: Colors.black54,
                      height: 2,
                      width: MediaQuery.of(context).size.width,
                    )),
              ),
            ),
            SafeArea(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                    padding: const EdgeInsets.only(right: 0, bottom: 20),
                    child: SMS()),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class tbMsg {
  static List<Map> data = [
    {
      "id": 1,
      "mensagem": "Estou no local indicado",
    },
    {
      "id": 2,
      "mensagem": "Está perto?",
    },
    {
      "id": 3,
      "mensagem": "Pode esperar, por favor?",
    },
    {
      "id": 4,
      "mensagem": "Já estou a caminho.",
    },
    {
      "id": 5,
      "mensagem": "Desculpe o atraso.",
    },
  ];
}

