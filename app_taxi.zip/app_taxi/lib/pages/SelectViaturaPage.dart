import 'dart:async';
import 'dart:convert';
import 'package:card_loading/card_loading.dart';
import 'package:draggable_bottom_sheet_nullsafety/draggable_bottom_sheet_nullsafety.dart';
import 'package:vambora_passageiro/pages/RadarPage.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:vambora_passageiro/pages/PrincipalPage.dart';
import 'package:vambora_passageiro/pages/SelectPagamentoPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:http/http.dart' as http;
import 'package:maps_curved_line/maps_curved_line.dart';
import '../config/Constats.dart';
import 'package:google_maps_flutter_platform_interface/google_maps_flutter_platform_interface.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../controller/MapController.dart';
import 'package:get/get.dart';
import 'package:flutter_polyline_points/flutter_polyline_points.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import '../modelos/CardViaturas.dart';
import '../modelos/Viaturas.dart';
import 'DefineRotaPage.dart';
import 'Loading.dart';
import 'package:custom_map_markers/custom_map_markers.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

var resV;

// inputs pedido
var viatura_pedido; // = "Economico";
var origem_pedido;
var paragem_pedido;
var destino_pedido;
var viajante_pedido;
var contacto_pedido;
var tipo_viatura; // = "Economico";
var metodo_pagamento = "Cash";
var desc_origem_pedido;
var desc_destino_pedido;
double? valor_estimado = 0.0;
int inicio_cobranca = 0;
bool carregadoViatura = false;
var dataV;

var viatura_proxima;

class SelectViaturaPage extends StatefulWidget {
  @override
  _SelectViaturaPageState createState() => _SelectViaturaPageState();
}

class _SelectViaturaPageState extends State<SelectViaturaPage> {
  final f = NumberFormat("#,##0", "pt_BR");
 bool _locationEnabled = false;
  // late final mid="0.0,0.0";
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  NumberFormat formatter = NumberFormat("00.00");
  loading load = loading();

  final controllerMap = Get.put(MapController());
  BitmapDescriptor markerCarro = BitmapDescriptor.defaultMarker;
  BitmapDescriptor markerIcon1 = BitmapDescriptor.defaultMarker;
  BitmapDescriptor markerIcon2 = BitmapDescriptor.defaultMarker;
  BitmapDescriptor markerIcon = BitmapDescriptor.defaultMarker;

  // personalizar marker
  final locations = [
    LatLng(posicaoV1, posicaoV2),
    LatLng(destinoV1, destinoV2),
  ];

  late List<MarkerData> _customMarkers;

  final Set<Polyline> _polylines = Set();
  final Set<Marker> _markers = Set();

  final CameraPosition _initialLocation = CameraPosition(
      target: LatLng(posicaoV1, posicaoV2),
      zoom: calc_distancia_viatura >= 24
          ? 10.0
          : calc_distancia_viatura >= 100
              ? 0
              : calc_distancia_viatura >= 10
                  ? 11.0
                  : 13.0);
  late GoogleMapController mapController;

  getCurrentLocation() async {
    await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best)
        .then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(posicaoV1, posicaoV2),
        zoom: calc_distancia_viatura >= 24
            ? 10.0
            : calc_distancia_viatura >= 100
                ? 0
                : calc_distancia_viatura >= 10
                    ? 11.0
                    : 13.0,
      )));
        posicaoPassageiro = "$posicaoV1,$posicaoV2";
    }).catchError((e) async {
      print(e);
    });
  }


  Future<void> ajustarCamera(LatLng origem, LatLng destino) async {
    final controller = await _controller.future;

    final bounds = LatLngBounds(
      southwest: LatLng(
        origem.latitude < destino.latitude
            ? origem.latitude
            : destino.latitude,
        origem.longitude < destino.longitude
            ? origem.longitude
            : destino.longitude,
      ),
      northeast: LatLng(
        origem.latitude > destino.latitude
            ? origem.latitude
            : destino.latitude,
        origem.longitude > destino.longitude
            ? origem.longitude
            : destino.longitude,
      ),
    );

    controller.animateCamera(CameraUpdate.newLatLngBounds(bounds, 80));
  }


  Future Carregamento() async {
    await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(load.getFuture()),
    );
  }


  final LatLng _point1 = LatLng(posicaoV1, posicaoV2);
  final LatLng _point2 = LatLng(destinoV1, destinoV2);


  LatLng origem = LatLng(posicaoV1, posicaoV2);
  LatLng destino = LatLng(destinoV1, destinoV2);

  void prepareMarkers() {
    _markers.add(Marker(
      markerId: MarkerId(_point1.toString()),
      position: _point1,
      icon: BitmapDescriptor.defaultMarker,
    ));

    _markers.add(Marker(
      markerId: MarkerId(_point2.toString()),
      position: _point2,
      icon: BitmapDescriptor.defaultMarker,
    ));
  }


  Future CalculaTempoViatura() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/motoristaonlinemaisproximo');
      var response = await http.post(url, body: {
        "localizacao_passageiro": origem_pedido.toString(),
      });
      final map = json.decode(response.body);
        viatura_proxima = map["tempo"];
        print("motorista-mais-proximo");
        print(viatura_proxima);

    } catch (e) {
      print(e);
    }
  }

  final Set<Marker> marker = {};

  Set<Marker> _marker = {};

  void criarMarkers(LatLng origem, LatLng destino) {
    _marker = {
      Marker(
        markerId: const MarkerId('origem'),
        position: origem,
        infoWindow: InfoWindow(title: desc_origem_pedido),
      ),
      Marker(
        markerId: const MarkerId('destino'),
        position: destino,
        infoWindow: InfoWindow(title: desc_destino_pedido),
      ),
    };
  }


  Future CarrosOn() async {
    try {
      String baseURL = "https://$dom/$endpoint/motoristasonline";
      String request = "$baseURL?localizacao_passageiro=$posicaoV1,$posicaoV2";
      final response = await http.get(Uri.parse(request));
      final map = json.decode(response.body);
      for (int i = 0; i < 10; i++) {
        double latitude =
            double.tryParse(map[i]['localizacao_actual'].split(",")[0])!;
        double longitude =
            double.tryParse(map[i]['localizacao_actual'].split(",")[1])!;
        Position destinationCoordinates = Position(
            latitude: latitude,
            longitude: longitude,
            accuracy: 0.0,
            speedAccuracy: 0.0,
            altitude: 1.0,
            heading: 0.0,
            speed: 1.0,
            floor: null,
            isMocked: false,
            altitudeAccuracy: 0.0,
            headingAccuracy: 0.0,
            timestamp: DateTime.now());
        Marker resultMarkers = Marker(
          markerId: MarkerId('${map[i]['localizacao_actual']}'),
          position: LatLng(destinationCoordinates.latitude,
              destinationCoordinates.longitude),
          icon: markerIcon,
          onTap: () {},
        );
        marker.add(resultMarkers);
      }
    } catch (e) {
      print(e);
    }
  }

  void addIcon() {
    BitmapDescriptor.fromAssetImage(
            const ImageConfiguration(), "assets/images/carro_online.png")
        .then(
      (icon) {
          markerIcon = icon;
      },
    );
  }





  var dadoV;
  bool carregado = false;

  Future getViaturas() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/listar/viaturas";
      String request = '$baseURL?provincia=$reg';
      final response = await http.get(Uri.parse(request));
      final map = json.decode(response.body);
      dadoV = map["viaturas"];
        print(dadoV);
        tipo_viatura = dadoV[0]["tipo_viatura"];
        viatura_pedido = dadoV[0]['descricao'];
        inicio_cobranca = int.parse(dadoV[0]['inicio_cobranca']);
        taxakm = double.tryParse(dadoV[0]["tarifa_km"]);
        tarifa_base = double.tryParse(dadoV[0]["tarifa_base"]);
        if (calc_distancia_viatura <= inicio_cobranca) {
          valor_estimado = tarifa_base;
        } else {
          double distanciaContagem = calc_distancia_viatura - inicio_cobranca;
          valor_estimado = taxakm * distanciaContagem.round() + tarifa_base;
        }
        await SessionManager().set("taxa_km", taxakm);
        await SessionManager().set("tarifa_base", tarifa_base);
        await SessionManager().set("valor_estimado", valor_estimado);
      setState(() {
        carregado = true;
      });
      print("valor_estimado");
      print(valor_estimado);
    } catch (e) {
      print(e);
    }
  }

  List<bool> _isSelectedlist = [
    true,
    false,
    false,
  ];


  Widget _BtnContinuar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFF15191C),
            elevation: 10,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => SelectPagamentoPage()));
        },
        child: const Text(
          'Continuar',
          style: TextStyle(
            color: Color(0xFFEDBD1D),
            fontSize: 18.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
          textAlign: TextAlign.center,
          overflow: TextOverflow.fade,
          maxLines: 1,
        ),
      ),
    );
  }

  _updateList(int index) {
    _isSelectedlist[0] = false;
    _isSelectedlist[1] = false;
    _isSelectedlist[2] = false;
    if (_isSelectedlist[index] == true) {
      setState(() {
        _isSelectedlist[index] = false;
      });
    } else {
      setState(() {
        _isSelectedlist[index] = true;
      });
    }
  }

  Widget _BtnBack() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.pop(context);
        },
        child: const Icon(
          CupertinoIcons.arrow_left_circle,
          color: Color(0xFF15191C),
          size: 30,
        ),
      ),
    );
  }

  Widget _daoViaturas() {
    return SizedBox(
       height: 500,
        child: !carregado
            ? const CardLoading(
                cardLoadingTheme: CardLoadingTheme(
                    colorOne: Color(0xFFEDBD1D), colorTwo: Colors.white),
                height: 20,
                borderRadius: BorderRadius.all(Radius.circular(10)),
                margin: EdgeInsets.only(bottom: 10),
              )
            : ListView.builder(
          padding: const EdgeInsets.only(top: 5),
                scrollDirection: Axis.vertical,
                itemCount: dadoV.length,
                itemBuilder: (BuildContext context, int index) => Card(
                    shape: RoundedRectangleBorder(
                        side: BorderSide(
                          color: _isSelectedlist[index] == true
                              ? const Color(0xFF15191C)
                              : const Color(0xFF15191C),
                          width: _isSelectedlist[index] == true ? 1 : 1,
                        ),
                        borderRadius: BorderRadius.circular(10)),
                    borderOnForeground: true,
                    shadowColor: Colors.black12,
                    elevation: _isSelectedlist[index] == true ? 4 : 0,
                    color: _isSelectedlist[index] == true
                        ? const Color(0xFF15191C)
                        : Colors.transparent,
                    child: ListTile(
                      selected: _isSelectedlist[index],
                      title: Text(
                        dadoV[index]['tipo_viatura'].toString(),
                        style: TextStyle(
                          fontFamily: "Gotham",
                          fontSize: _isSelectedlist[index] == true ? 20 : 18,
                          color: _isSelectedlist[index] == true
                              ? const Color(0xFFEDBD1D)
                              : const Color(0xFF15191C),
                        ),
                      ),
                      leading: Image(
                        image: const AssetImage("assets/images/premium.png"),
                        width: _isSelectedlist[index] == true ? 100 : 90,
                        height: _isSelectedlist[index] == true ? 90 : 80,
                      ),
                      trailing: carregado == false
                          ? const Text(
                              "0.0",
                              style: TextStyle(
                                fontFamily: "Gotham",
                                fontSize: 18,
                                color: Colors.white,
                              ),
                            )
                          : calc_distancia_viatura <= inicio_cobranca
                              ? Text(
                                  f
                                      .format(double.parse(
                                              dadoV[index]['tarifa_base'])
                                          .round())
                                      .toString(),
                                  style: TextStyle(
                                    fontFamily: "Gotham",
                                    fontSize: _isSelectedlist[index] == true
                                        ? 20
                                        : 18,
                                    color: _isSelectedlist[index] == true
                                        ? const Color(0xFFEDBD1D)
                                        : const Color(0xFF15191C),
                                  ))
                              : Text(
                                  f
                                      .format(double.parse(
                                              dadoV[index]['tarifa_base']) +
                                          (double.parse(dadoV[index]
                                                      ['tarifa_km']) *
                                                  (calc_distancia_viatura -
                                                      inicio_cobranca))
                                              .round())
                                      .toString(),
                                  style: TextStyle(
                                    fontFamily: "Gotham",
                                    fontSize: _isSelectedlist[index] == true
                                        ? 20
                                        : 18,
                                    color: _isSelectedlist[index] == true
                                        ? const Color(0xFFEDBD1D)
                                        : const Color(0xFF15191C),
                                  )),
                      selectedColor: Colors.white,
                      onLongPress: () {},
                      onTap: () async {
                        viatura_pedido = dadoV[index]['descricao'];
                        tipo_viatura = dadoV[index]['tipo_viatura'];
                        _updateList(index);
                        setState(() async {
                          if (calc_distancia_viatura <= inicio_cobranca) {
                            valor_estimado =
                                double.parse(dadoV[index]['tarifa_base']);
                          } else {
                            double distanciaContagem =
                                calc_distancia_viatura - inicio_cobranca;
                            valor_estimado =
                                double.parse(dadoV[index]['tarifa_base']) +
                                    double.parse(dadoV[index]['tarifa_km']) *
                                        distanciaContagem.round();
                          }
                          await SessionManager()
                              .set("valor_estimado", valor_estimado);
                          taxakm = double.parse(dadoV[index]["tarifa_km"]);
                          tarifa_base =
                              double.parse(dadoV[index]["tarifa_base"]);
                          await SessionManager().set("taxa_km", taxakm);
                          await SessionManager()
                              .set("tarifa_base", tarifa_base);
                        });
                      },
                    )),
              ));
  }




// marker
  _customMarkerOrigem(String text) {
    return Container(
      width: 300,
      height: 50,
      margin: const EdgeInsets.all(10),
      padding: const EdgeInsets.all(0),
      child: Card(
        elevation: 10,
        color: Colors.white,
        child: Center(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  color: Colors.black,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        viatura_proxima == null ? ".." : "${viatura_proxima}Min",
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.visible,
                        maxLines: 1,
                      ),
                    ],
                  ),
                ),
                Container(
                    width: 200,
                    height: 50,
                    color: Colors.white,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          text,
                          style: const TextStyle(
                            color: Colors.black87,
                            fontSize: 12,
                          ),
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                      ],
                    ))
              ],
            )),
      ),
    );
  }


  _customMarkerDestino(String text) {
    return Container(
      width: 300,
      height: 50,
      margin: const EdgeInsets.all(10),
      padding: const EdgeInsets.all(0),
      child: Card(
        elevation: 10,
        color: const Color(0xFFEDBD1D),
        child: Center(
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  color: Colors.black,
                  child: const Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.location_on_rounded, size: 30, color: Colors.white,),
                    ],
                  ),
                ),
                Container(
                    width: 200,
                    height: 50,
                    color: const Color(0xFFEDBD1D),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          text,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                          ),
                          textAlign: TextAlign.center,
                          overflow: TextOverflow.ellipsis,
                          maxLines: 2,
                        ),
                      ],
                    ))
              ],
            )),
      ),
    );
  }
// fim


  @override
  void initState() {
    super.initState();
    getCurrentLocation();
    getViaturas();
   addIcon();
    CalculaTempoViatura();
    _customMarkers = [
      MarkerData(
          marker: Marker(
              markerId: const MarkerId('id-1'),
              position: LatLng(posicaoV1, posicaoV2)),
          child: _customMarkerOrigem(desc_origem_pedido)),
      MarkerData(
          marker: Marker(
              markerId: const MarkerId('id-2'),
              position: LatLng(destinoV1, destinoV2)),
          child: _customMarkerDestino(desc_destino_pedido)),
    ];//fim

  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    prepareMarkers();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'Gotham'),
      home: Scaffold(
        drawer: const Drawer(),
        body: Stack(
          children: [
            DraggableBottomSheet(
              previewChild: Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFFEDBD1D),
                      Color(0xFFEDBD1D),
                    ],
                  ),
                  //color: Color(0xFF00008B),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    topRight: Radius.circular(15),
                  ),
                ),
                child: SizedBox(
                  child: SizedBox(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: <Widget>[
                        Container(
                          width: 50,
                          height: 6,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                Color(0xFF15191C),
                                Color(0xFF15191C),
                              ],
                            ),
                            // color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        _daoViaturas(),
                      ],
                    ),
                  ),
                ),
              ),
              expandedChild: Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  color: Color(0xFFEDBD1D),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),
                    topRight: Radius.circular(15),
                  ),
                ),
                child: Column(
                  children: <Widget>[
                    Container(
                      width: 50,
                      height: 6,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            Color(0xFF15191C),
                            Color(0xFF15191C),
                          ],
                        ),
                        // color: Colors.white,
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height * 0.2,
                      child: _daoViaturas(),
                    )
                  ],
                ),
              ),
              backgroundWidget: CustomGoogleMapMarkerBuilder(
                  customMarkers: _customMarkers,
                  builder: (BuildContext context, Set<Marker>? markers) {
                    if (markers == null) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    return GoogleMap(
                    mapType: MapType.normal,
                    initialCameraPosition: _initialLocation,
                    myLocationEnabled: false,
                    myLocationButtonEnabled: false,
                    zoomGesturesEnabled: true,
                    zoomControlsEnabled: false,
                    markers: markers,
                    onMapCreated: (GoogleMapController controller) {
                      _controller.complete(controller);
                      ajustarCamera(origem, destino);
                      Future.delayed(const Duration(milliseconds: 500), () {
                        setState(() {
                          _locationEnabled = true;
                        });
                      });
                    },
              );}),
              minExtent: MediaQuery.of(context).size.height * 0.2,
              maxExtent: MediaQuery.of(context).size.height * 0.5,
            ),
            SafeArea(
                child: Padding(
              padding: EdgeInsets.only(
                right: MediaQuery.of(context).size.width / 1.5,
                top: 10,
                left: 10,
              ),
              child: Column(
                children: [
                  _BtnBack(),
                ],
              ),
            )),
            Container(
              width: MediaQuery.of(context).size.width,
              alignment: Alignment.bottomCenter,
              child: Card(
                  margin: EdgeInsets.zero,
                  color: const Color(0xFFEDBD1D),
                  elevation: 10,
                  shadowColor: Colors.black54,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(
                        height: 100,
                      ),
                      _BtnContinuar(),
                    ],
                  )),
            ),
          ],
        ),
      ),
    );
  }
}
