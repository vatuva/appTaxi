import 'dart:convert';
import 'dart:io';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:material_dialogs/dialogs.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import '../config/Constats.dart';
import 'PrincipalPage.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'Loading.dart';
import 'SplashPage.dart';


class EditarPerfilPage extends StatefulWidget {
  @override
  _EditarPerfilPage createState() => _EditarPerfilPage();
}

class _EditarPerfilPage extends State<EditarPerfilPage> {
  final TextEditingController _email = TextEditingController();
  final TextEditingController _nome = TextEditingController();
  final TextEditingController _sobrenome = TextEditingController();
  final globalKey = GlobalKey<FormState>();
  var seguro = true;
  final TextEditingController PhoneController = TextEditingController();

  loading load = loading();
  File? file;
  XFile? _image;

  final picker = ImagePicker();

  File? _selectedImage;

  Future getImageGaleria() async {
    _image = await picker.pickImage(source: ImageSource.gallery);
    if (_image != null) {
      setState(() {
        file = File(_image!.path);
      });
      // ignore: use_build_context_synchronously
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar a foto?',
          title: 'Actualizar foto de perfil',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: Colors.white38,
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadFoto();
              },
              text: 'Sim',
              iconData: Icons.done_outline,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future<void> getImageCamera() async {
    _image = await picker.pickImage(source: ImageSource.camera);
    if (_image != null) {
      setState(() {
        file = File(_image!.path);
      });
      // ignore: use_build_context_synchronously
      Dialogs.bottomMaterialDialog(
          msg: 'Deseja salvar a foto?',
          title: 'Actualizar foto de perfil',
          context: context,
          actions: [
            IconsOutlineButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              text: 'Não',
              iconData: Icons.cancel,
              color: Colors.white38,
              textStyle: const TextStyle(color: Colors.grey),
              iconColor: Colors.white,
            ),
            IconsButton(
              onPressed: () {
                Navigator.of(context).pop();
                _UploadFoto();
              },
              text: 'Sim',
              iconData: Icons.done_outline,
              color: Colors.green,
              textStyle: const TextStyle(color: Colors.white),
              iconColor: Colors.white,
            ),
          ]);
    }
  }

  Future _UploadFoto() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/alterarfoto');
      var response = await http.MultipartRequest('POST', url);
      response.fields['id'] = idPassageiro.toString();
      response.fields['chave_publica'] = ChavePublica.toString();
      var pic = await http.MultipartFile.fromPath("foto", file!.path);
      response.files.add(pic);
      var res = await response.send();
      if (res.statusCode == 200) {
        file = null;
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Registo actualizado com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => PrincipalPage()));
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao carregar a foto de perfil.',
          ),
        );
      }
    } catch (e) {
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Ops! Algo deu errado ao tentar completar a acção solicitada. ',
        ),
      );
      print(e);
    }
  }

  Future Registar() async {
    try {
      setState(() {
        btnRg2 = true;
      });
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/actualizar');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "email": _email.text,
        "nome": _nome.text,
        "apelido": _sobrenome.text
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final perfil = map["perfil_passageiro"];
      setState(() {
        nomePassageiro = perfil['nome'];
        sobrenomePassageiro = perfil['apelido'];
        emailPassageiro = perfil['email'];
      });
      if (msgr == 1) {
        // ignore: use_build_context_synchronously
        await showDialog(
          context: context,
          builder: (context) => FutureProgressDialog(load.getFuture()),
        );
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Actualizado com sucesso.',
          ),
        );
        setState(() {
          btnRg2 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => PrincipalPage()));
      } else if (msgr == 0) {
        setState(() {
          btnRg2 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao actualizar o registo.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg2 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        CustomSnackBar.error(
          message: 'Ops! Ocorreu um erro. Erro $e.',
        ),
      );
    }
  }

  @override
  void initState() {
    _email.text = emailPassageiro.toString();
    _nome.text = nomePassageiro.toString();
    _sobrenome.text = sobrenomePassageiro.toString();
    super.initState();
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: btnRg2 == false
            ? () {
                if (_nome.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Ops! Por favor, Informe o seu nome.',
                    ),
                  );
                } else if (_sobrenome.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Ops! Por favor, Informe o seu sobrenome.',
                    ),
                  );
                } else if (_email.text == '') {
                  showTopSnackBar(
                    // ignore: use_build_context_synchronously
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Ops! Por favor, Informe o seu e-mail.',
                    ),
                  );
                } else {
                  Registar();
                }
              }
            : () {},
        child: btnRg2 == false
            ? const Text(
                'Salvar',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator(
                backgroundColor: Color(0xFFEDBD1D),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  Widget _TxtNome() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 55,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "Nome",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.person,
              size: 25,
              color: Color(0xFF000000),
            ),
            validator: FormValidation.requiredTextField,
            controller: _nome,
          ),
        ));
  }

  Widget _TxtSobreNome() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 55,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "Sobrenome",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.person,
              size: 25,
              color: Color(0xFF000000),
            ),
            validator: FormValidation.requiredTextField,
            controller: _sobrenome,
          ),
        ));
  }

  Widget _TxtEmail() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 55,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "E-mail",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.email,
              color: Color(0xFF000000),
              size: 25,
            ),
            validator: FormValidation.requiredTextField,
            controller: _email,
          ),
        ));
  }

  String text = "";
  int maxLength = 9;

  Widget _TxtTelefone() {
    return Card(
        elevation: 1,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 55,
          child: MaterialTextField(
            onChanged: (String newVal) {
              if (newVal.length <= maxLength) {
                text = newVal;
              } else {
                PhoneController.text = text;
              }
            },
            keyboardType: TextInputType.number,
            labelText: "Telefone",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Colors.black54,
              fontSize: 15,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.phone_android_outlined,
              color: Color(0xFF000000),
              size: 25,
            ),
            validator: FormValidation.requiredTextField,
            controller: PhoneController,
          ),
        ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          SafeArea(
              child: Column(
            children: [
              const SizedBox(
                height: 10,
              ),
              Card(
                margin: const EdgeInsets.all(0),
                elevation: 5,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(100),
                      bottomRight: Radius.circular(100),
                      topLeft: Radius.circular(100),
                      topRight: Radius.circular(100)),
                ),
                child: Container(
                  decoration: const BoxDecoration(
                      borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(100),
                          bottomRight: Radius.circular(100),
                          topLeft: Radius.circular(100),
                          topRight: Radius.circular(100)),
                      gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [Color(0xFFEDBD1D), Color(0xFFEDBD1D)])),
                  height: 150,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      CircleAvatar(
                          backgroundColor: const Color(0xFFEDBD1D),
                          radius: 50,
                          backgroundImage: file == null
                              ? Image.network(fotoPerfil).image
                              : Image.file(File(file!.path)).image),
                      IconButton(
                          onPressed: () {
                            Dialogs.bottomMaterialDialog(
                                msg: 'Carregar foto de perfil',
                                title: 'Foto de Perfil',
                                context: context,
                                actions: [
                                  IconsOutlineButton(
                                    onPressed: () {
                                      getImageCamera();
                                      Navigator.of(context).pop();
                                    },
                                    text: 'Câmera',
                                    iconData: Icons.camera_alt,
                                    color: const Color(0xFFEDBD1D),
                                    textStyle:
                                        const TextStyle(color: Colors.white),
                                    iconColor: Colors.white,
                                  ),
                                  IconsButton(
                                    onPressed: () {
                                      getImageGaleria();
                                      Navigator.of(context).pop();
                                    },
                                    text: 'Galeria',
                                    iconData: Icons.image,
                                    color: const Color(0xFFEDBD1D),
                                    textStyle:
                                        const TextStyle(color: Colors.white),
                                    iconColor: Colors.white,
                                  ),
                                ]);
                          },
                          icon: const Icon(
                            Icons.camera_alt_outlined,
                            size: 25,
                            color: Color(0xFFFFFFFF),
                          ))
                    ],
                  ),
                ),
              ),
              SingleChildScrollView(
                child: Column(
                  children: [
                    const SizedBox(
                      height: 50,
                    ),
                    _TxtNome(),
                    const SizedBox(
                      height: 10,
                    ),
                    _TxtSobreNome(),
                    const SizedBox(
                      height: 10,
                    ),
                    _TxtEmail(),
                    const SizedBox(
                      height: 20,
                    ),
                    Container(
                      alignment: Alignment.bottomCenter,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          _BtnComecar(),
                          const SizedBox(
                            height: 10,
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          )),
        ],
      ),
      appBar: AppBar(
        title: const Text(
          "Editar Perfil",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            fontFamily: 'gotham',
          ),
        ),
        actionsIconTheme: const IconThemeData(color: Colors.white),
        backgroundColor: const Color(0xFFEDBD1D),
        elevation: 5,
        iconTheme: const IconThemeData(color: Colors.white, size: 40),
      ),
    );
  }
}
