import 'dart:async';
import 'dart:convert';
import 'package:flutter_animation_progress_bar/flutter_animation_progress_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:vambora_passageiro/pages/DefineRotaPage.dart';
import 'package:vambora_passageiro/pages/DriverPage.dart';
import 'package:vambora_passageiro/pages/SelectViaturaPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter_platform_interface/google_maps_flutter_platform_interface.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../NovoVisual/home.dart';
import '../NovoVisual/home/homePage.dart';
import '../config/Constats.dart';
import '../controller/MapController.dart';
import '../modules/home/home_page.dart';
import 'PerfilPage.dart';
import 'PrincipalPage.dart';
import 'Loading.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import 'RadarPage.dart';

bool carregarDados = false;

class CarregarPerfilPage extends StatefulWidget {
  @override
  _CarregarPerfilPage createState() => _CarregarPerfilPage();
}

class _CarregarPerfilPage extends State<CarregarPerfilPage> {
  final controllerMap = Get.put(MapController());
  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();
  BitmapDescriptor markerIcon = BitmapDescriptor.defaultMarker;

  FocusNode myfocus = FocusNode();

  final TextEditingController locationController = TextEditingController();
  final TextEditingController servicoController = TextEditingController();
  final TextEditingController locationController2 = TextEditingController();
  loading load = loading();

  Future<void> getCurrentLocation() async {
    await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best)
        .then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(position.latitude, position.longitude),
        zoom: 13.5,
      )));
      // controllerMap.getAddress();
      setState(() {
        posicaoV1 = position.latitude;
        posicaoV2 = position.longitude;
      });
    }).catchError((e) {
      print(e);
    });
  }

  Future Carregamento() async {
    await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(load.getFuture()),
    );
  }

  Future CarregarDados() async {
    try {
      var url = Uri(
          scheme: 'https', host: dom, path: '$endpoint/passageiroapi/dados');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final perfil = map["perfil_passageiro"];
      print(map);
      verificacao = perfil['status_verificacao'];
      nomePassageiro = perfil['nome'];
      sobrenomePassageiro = perfil['apelido'];
      fotoPerfil = urlImagem + perfil['foto'];
      emailPassageiro = perfil['email'];
      contacto_pedido = perfil['telefone'];
      viajante_pedido = nomePassageiro;
      carregarDados = true;
      print("idPassageiro");
      print(ChavePublica);
    } catch (e) {
      print(e);
    }
  }


  void ActivarSessao() async {
    sessao_usuario = 1;
    await SessionManager().set("sessao_usuario", 1);
  }

  void limparDadosViagem() async {
    await SessionManager().set("estatus_viagem", 0);
    await SessionManager().set("idPedido", "");
    estatus_viagem = 0;
    aceite_viagem = false;
    localRecolha = "Localização Actual";
  }

  @override
  void initState() {
    super.initState();
    ActivarSessao();
    getCurrentLocation();
   limparDadosViagem();
   CarregarDados();
    Future.delayed(const Duration(milliseconds: 1000), () {
    //  // ignore: use_build_context_synchronously
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => PrincipalPage(),
        ),
      );
    });
  }

  @override
  void dispose() {

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFFEDBD1D),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Center(
                  child: Image(
                    image: AssetImage("assets/images/logotipo.png"),
                  ),
                ),
                SizedBox(height: 20,),
                Text("Só um momento.",
                    style: TextStyle(
                        color: Color(0xFF15191C),
                        fontFamily: 'gotham',
                        fontSize: 20,
                        fontWeight: FontWeight.normal)),
                SizedBox(
                  height: 10,
                ),
                Text("e vamos embora...",
                    style: TextStyle(
                        color: Color(0xFF15191C),
                        fontFamily: 'gotham',
                        fontSize: 18,
                        fontWeight: FontWeight.normal)),
                SizedBox(
                  height: 10,
                ),
                SizedBox(
                  height: 10,
                ),
                CircularProgressIndicator.adaptive(
                  backgroundColor: Color(0xFFEDBD1D),
                  valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF15191C)),
                ),
                SizedBox(
                  height: 10,
                ),

              ],
            )

          ],
        ),
      ),
    );
  }
}
