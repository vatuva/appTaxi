import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
// ignore: depend_on_referenced_packages
import 'package:flutter/material.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import 'package:dropdown_button2/dropdown_button2.dart';


class InfoPerfilPage extends StatefulWidget {
  @override
  _InfoPerfilPage createState() => _InfoPerfilPage();
}

class _InfoPerfilPage extends State<InfoPerfilPage> {
  final GlobalKey<FormState> _key = GlobalKey<FormState>();
  String? provincia;
  final TextEditingController _bi = TextEditingController();
  final TextEditingController _carta = TextEditingController();
  final TextEditingController _cidade = TextEditingController();
  final TextEditingController _endereco = TextEditingController();

  @override
  void initState() {
    super.initState();
  }

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 2,
      height: 40,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: Colors.black54,
            elevation: 5,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {

        },
        child: const Text(
          'Salvar',
          style: TextStyle(
            color: Colors.white,
            fontSize: 18.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
        ),
      ),
    );
  }

  List<String> items = [
    'Cabinda',
    'Luanda',
    'Huambo',
  ];

  Widget _TxtProvincia() {
    return DropdownButtonHideUnderline(
      child: DropdownButton2(
        barrierColor: Colors.black12,
        style: const TextStyle(
          fontFamily: 'Gotham',
          color: Colors.black,
        ),
        isExpanded: true,
        hint: const Text(
          'Província',
          style: TextStyle(
            fontSize: 14,
            color: Colors.black,
          ),
        ),
        items: items
            .map((item) => DropdownMenuItem<String>(
          value: item,
          child: Text(
            item,
            style: const TextStyle(
              fontSize: 14,
            ),
          ),
        ))
            .toList(),
        value: provincia,
        onChanged: (value) {
          setState(() {
            provincia = value as String;
            print(value);
          });
        },
      ),
    );
  }

  Widget _TxtBI() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Nº. Bilhete de Identidade",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.add_card),
        validator: FormValidation.requiredTextField,
        controller: _bi,
      ),
    );
  }


  Widget _TxtCidade() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Cidade",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.location_city),
        validator: FormValidation.requiredTextField,
        controller: _cidade,
      ),
    );
  }

  Widget _TxtEndereco() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Endereço",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.location_on),
        validator: FormValidation.requiredTextField,
        controller: _endereco,
      ),
    );
  }

  Widget _TxtCarta() {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.5,
      height: 50,
      child: MaterialTextField(
        keyboardType: TextInputType.text,
        labelText: "Nº. Carta de Condução",
        theme: FilledOrOutlinedTextTheme(
          fillColor: Colors.black12,
          radius: 80,
        ),
        textInputAction: TextInputAction.next,
        prefixIcon: const Icon(Icons.add_card),
        validator: FormValidation.requiredTextField,
        controller: _carta,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(
              height: 10,
            ),
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: const Color(0xFaeb2b5),
              ),
              height: 80,
              width: MediaQuery.of(context).size.width / 1.5,
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Dados adicionais',
                    style: TextStyle(
                      color: Colors.black87,
                      letterSpacing: 0,
                      fontSize: 14.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'gotham',
                    ),
                  ),
                  SizedBox(
                    height: 2,
                  ),
                  Align(
                    alignment: Alignment.center,
                    child: Text(
                      'Esssas informações deixam os motoristas mais seguros',
                      style: TextStyle(
                        color: Colors.black87,
                        letterSpacing: 0,
                        fontSize: 12.0,
                        fontWeight: FontWeight.normal,
                        fontFamily: 'gotham light',
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const Align(
              alignment: Alignment.center,
              child: Text(
                'Seus dados de configuração',
                style: TextStyle(
                  color: Colors.red,
                  letterSpacing: 0,
                  fontSize: 12.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham light',
                ),
              ),
            ),
            const Align(
              alignment: Alignment.center,
              child: Text(
                'de conta.',
                style: TextStyle(
                  color: Colors.red,
                  letterSpacing: 0,
                  fontSize: 12.0,
                  fontWeight: FontWeight.normal,
                  fontFamily: 'gotham light',
                ),
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            _TxtBI(),
            const SizedBox(
              height: 10,
            ),
            _TxtCarta(),
            const SizedBox(
              height: 10,
            ),
            _TxtProvincia(),
            const SizedBox(
              height: 10,
            ),
            _TxtCidade(),
            const SizedBox(
              height: 10,
            ),
            _TxtEndereco(),
            const SizedBox(
              height: 20,
            ),
            _BtnComecar(),
          ],
        ),
      ),
      appBar: AppBar(
        actionsIconTheme: const IconThemeData(color: Color(0xFF00008B)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF00008B), size: 40),
        actions: const [],
      ),
    );
  }
}
