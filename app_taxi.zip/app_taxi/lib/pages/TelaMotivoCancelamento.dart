import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import '../config/Constats.dart';
import 'DriverPage.dart';
import 'PrincipalPage.dart';
import 'SelectPagamentoPage.dart';
import 'SplashPage.dart';

class TelaMotivoCancelamento extends StatefulWidget {
  const TelaMotivoCancelamento({Key? key}) : super(key: key);

  @override
  State<TelaMotivoCancelamento> createState() =>
      _TelaJustificarCancelamentoState();

}

class _TelaJustificarCancelamentoState
    extends State<TelaMotivoCancelamento> {
  String? motivoSelecionado;
  final TextEditingController outrosController = TextEditingController();
  late String motivoFinal;

  final List<String> motivos = [
    "Demora excessiva do motorista para chegar.",
    "Mudança de planos de última hora.",
    "O motorista exigiu mais dinheiro.",
    "Problemas com a localização do motorista.",
    "O motorista não aceitou a forma de pagamento.",
    "Solicitação feita por engano.",
    "A viatura não oferece segurança nenhuma.",
    "Outros motivos.",
  ];

  bool get isOutros =>
      motivoSelecionado != null &&
          motivoSelecionado!.toLowerCase().contains("outros");

  void confirmarCancelamento() {
    if (motivoSelecionado == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Selecione um motivo para continuar")),
      );
      return;
    }else if (isOutros && outrosController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text("Descreva o motivo do cancelamento")),
      );
      return;
    }else {

      motivoFinal = isOutros
          ? outrosController.text.trim()
          : motivoSelecionado!;
      CancelarPedido();
    }
  }

  void limparDadosViagem() async {
    await SessionManager().set("estatus_viagem", 0);
    await SessionManager().set("idPedido", "");
    estatus_viagem = 0;
    idPedido = "";
  }

  Future CancelarPedido() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/pedido/cancelar');
      var response = await http.post(url, body: {
        "passageiro": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": idPedido.toString(),
        "motivo": motivoFinal.toString(),
      });
      final map = json.decode(response.body);
        final msgr = map["retorno"];
        if (msgr == 1) {
          showTopSnackBar(
            // ignore: use_build_context_synchronously
            Overlay.of(context),
            const CustomSnackBar.success(
              message: 'Corrida cancelada com sucesso!',
            ),
          );
          limparDadosViagem();
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (_) => SplashPage()),
                (route) => false,
          );
        }

    } catch (e) {
      print(e);
    }
  }
  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      appBar: AppBar(
        backgroundColor: const Color(0xFFEDBD1D),
        title: const Text("Cancelar corrida"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: const Color(0xFFEDBD1D).withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text(
                "Ajude-nos a melhorar o serviço informando o motivo do cancelamento.",
                style: TextStyle(fontSize: 14),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: motivos.length,
              itemBuilder: (context, index) {
                return Card(
                  margin:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                  child: RadioListTile<String>(
                    value: motivos[index],
                    groupValue: motivoSelecionado,
                    title: Text(motivos[index]),
                    activeColor: Colors.red,
                    onChanged: (value) {
                      setState(() {
                        motivoSelecionado = value;
                      });
                    },
                  ),
                );
              },
            ),
          ),
          if (isOutros)
            Padding(
              padding: const EdgeInsets.all(16),
              child: TextField(
                controller: outrosController,
                maxLines: 3,
                decoration: InputDecoration(
                  hintText: "Descreva o motivo...",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.only(top:0, right: 40, left: 40, bottom: 10),
            child: SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                onPressed: (){
                  confirmarCancelamento();
                },
                child: const Text(
                  "Confirmar",
                  style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
