import 'dart:convert';
import 'dart:io';
import 'package:vambora_passageiro/config/Constats.dart';
import 'package:vambora_passageiro/pages/CarregarPerfilPage.dart';
import 'package:vambora_passageiro/pages/IniciarPage.dart';
import 'package:vambora_passageiro/pages/TelaRegisto.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:geolocator/geolocator.dart';
import 'package:material_text_fields/material_text_fields.dart';
import 'package:material_text_fields/theme/material_text_field_theme.dart';
import 'package:material_text_fields/utils/form_validation.dart';
import 'package:sign_in_button/sign_in_button.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'DigitePinPage.dart';
import 'package:http/http.dart' as http;
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'Loading.dart';
import 'PrincipalPage.dart';
import 'ResetSenhaPage.dart';
import 'SplashPage.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPage createState() => _LoginPage();
}

class _LoginPage extends State<LoginPage> {
  final globalKey = GlobalKey<FormState>();
  late bool _toggleVisibility = true;
  var seguro = true;
  final TextEditingController PhoneController = TextEditingController();
  final TextEditingController _senha = TextEditingController();

  @override
  void initState() {
    myfocus.requestFocus();
    super.initState();
  }

  Future<Position> posicaoActual() async {
    LocationPermission permission;
    bool activado = await Geolocator.isLocationServiceEnabled();
    if (!activado) {
      return Future.error('Por favor, habilite a sua localização');
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied) {
      return Future.error('Você precisa autorizar o acesso à localização');
    }
    ValidarNumero();
    return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.best);
  }

  loading load = loading();
  FocusNode myfocus = FocusNode();

  void GerarSessao(String id, chave) async {
    await SessionManager().set("idPassageiro", id);
    await SessionManager().set("ChavePublica", chave);
  }

  Future Validarlogin() async {
    try {
      setState(() {
        btnRg1 = true;
      });
      var url = Uri(
          scheme: 'https', host: dom, path: '$endpoint/passageiroapi/login');
      var response = await http.post(url, body: {
        "usuario": PhoneController.text.toString(),
        "senha": _senha.text.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final dados = map["perfil_passageiro"];
      final cp = map['chave_publica'];
      if (msgr == 1) {
        // ignore: use_build_context_synchronously
        idPassageiro = dados['id'];
        ChavePublica = cp;
        GerarSessao(idPassageiro, ChavePublica);
        setState(() {
          btnRg1 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => CarregarPerfilPage()));
      } else {
        showTopSnackBar(
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Telefone ou Palavra-passe inválida.',
          ),
        );
        setState(() {
          btnRg1 = false;
        });
      }
    } catch (e) {
      setState(() {
        btnRg1 = false;
      });
      showTopSnackBar(
        Overlay.of(context),
        const CustomSnackBar.error(
          message: 'Ops! Erro ao efectuar o login. Verifique a sua Internet',
        ),
      );
    }
  }

  Future ValidarNumero() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/reset/passo1');
      var response = await http.post(url, body: {
        "telefone": PhoneController.text,
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final msg = map["msg"];
      print(map);
      print(msgr);
      print(map);
      if (msgr == 1) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Enviado com sucesso.',
          ),
        );
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => DigitePinPage()));
      } else if (msgr == 0) {
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => TelaRegisto()));
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        CustomSnackBar.error(
          message: 'Ops! Ocorreu um erro. Erro $e.',
        ),
      );
    }
  }

  String text = "";
  int maxLength = 9;

  Widget _BtnComecar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: btnRg1 == false
            ? () {
                numeroTel = PhoneController.text;
                if (PhoneController.text == "") {
                  showTopSnackBar(
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Por favor, Preencher o número de telefone.',
                    ),
                  );
                  myfocus.requestFocus();
                } else {
                  Validarlogin();
                }
              }
            : () {},
        child: btnRg1 == false
            ? const Text(
                'Iniciar sessão',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator.adaptive(
                backgroundColor: Color(0xFFEDBD1D),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  Widget _BtnRegisto() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
          style: TextButton.styleFrom(
              backgroundColor: const Color(0xFFFFFFFF),
              elevation: 2,
              padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
              shape: RoundedRectangleBorder(
                side: const BorderSide(width: 1, color: Color(0xFFEDBD1D)),
                borderRadius: BorderRadius.circular(90),
              )),
          onPressed: () {
            Navigator.of(context).push(CupertinoPageRoute(
                builder: (BuildContext context) => TelaRegisto()));
          },
          child: const Text(
            'Criar uma conta',
            style: TextStyle(
              color: Color(0xFFEDBD1D),
              fontSize: 18.0,
              fontWeight: FontWeight.w900,
              fontFamily: 'gotham',
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.fade,
            maxLines: 1,
          )),
    );
  }

  Widget _BtnGoogle() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFFFFFF),
            elevation: 2,
            padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
            shape: RoundedRectangleBorder(
              side: const BorderSide(width: 1, color: Color(0xFFEDBD1D)),
              borderRadius: BorderRadius.circular(90),
            )),
        onPressed: () {},
        child: SignInButton(
          padding: const EdgeInsets.all(0),
          elevation: 0,
          text: " Continuar com Google ",
          Buttons.google,
          onPressed: () {
            print("Google");
          },
        ),
      ),
    );
  }

  Widget _BtnApple() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFFFFFF),
            elevation: 2,
            padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
            shape: RoundedRectangleBorder(
              side: const BorderSide(width: 1, color: Color(0xFFEDBD1D)),
              borderRadius: BorderRadius.circular(90),
            )),
        onPressed: () {},
        child: SignInButton(
          elevation: 0,
          padding: const EdgeInsets.all(0),
          text: " Continuar com Apple ",
          Buttons.apple,
          onPressed: () {
            print("Apple");
          },
        ),
      ),
    );
  }

  Widget _TxtSenha() {
    return Card(
        elevation: 5,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 60,
          child: MaterialTextField(
            keyboardType: TextInputType.text,
            hint: "Palavra-passe",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Color(0xFF000000),
              fontSize: 22,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.lock_outline,
              color: Color(0xFF000000),
              size: 25,
            ),
            suffixIcon: IconButton(
              onPressed: () {
                setState(() {
                  _toggleVisibility = !_toggleVisibility;
                });
              },
              icon: _toggleVisibility
                  ? const Icon(
                      Icons.visibility_off_outlined,
                      size: 20,
                    )
                  : const Icon(
                      Icons.visibility_outlined,
                      size: 20,
                    ),
              color: const Color(0xFF000000),
            ),
            validator: FormValidation.requiredTextField,
            controller: _senha,
            obscureText: _toggleVisibility,
          ),
        ));
  }

  Widget _TxtTelefone() {
    return Card(
        elevation: 5,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(100))),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(100),
              border: Border.all(color: Colors.black12)),
          width: MediaQuery.of(context).size.width * 0.9,
          height: 60,
          child: MaterialTextField(
            onChanged: (String newVal) {
              if (newVal.length <= maxLength) {
                text = newVal;
              } else {
                PhoneController.text = text;
              }
            },
            keyboardType: TextInputType.number,
            hint: "Telefone",
            theme: FilledOrOutlinedTextTheme(
              fillColor: Colors.black12,
              radius: 100,
              focusedColor: const Color(0xFFEDBD1D),
            ),
            style: const TextStyle(
              color: Color(0xFF000000),
              fontSize: 22,
              fontWeight: FontWeight.normal,
            ),
            textInputAction: TextInputAction.next,
            prefixIcon: const Icon(
              Icons.phone_android_outlined,
              color: Color(0xFF000000),
              size: 25,
            ),
            validator: FormValidation.requiredTextField,
            controller: PhoneController,
          ),
        ));
  }

  Widget _btnOR() {
    return GestureDetector(
      onTap: () => null,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            children: [
              Container(
                  height: 2,
                  color: Colors.black12,
                  width: MediaQuery.of(context).size.width * 0.4)
            ],
          ),
          Column(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width * 0.01),
              const Text(
                " Ou ",
                style: TextStyle(
                  color: Colors.black12,
                  fontSize: 12.0,
                  fontWeight: FontWeight.normal,
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width * 0.01)
            ],
          ),
          Column(
            children: [
              Container(
                  height: 2,
                  color: Colors.black12,
                  width: MediaQuery.of(context).size.width * 0.4)
            ],
          )
        ],
      ),
    );
  }

  Widget _btnReset() {
    return ListTile(
      onTap: () {
        Navigator.of(context).push(CupertinoPageRoute(
            builder: (BuildContext context) => ResetSenhaPage()));
      },
      title: RichText(
        text: const TextSpan(
          children: [
            TextSpan(
              text: 'Esqueci-me da palavra-passe.',
              style: TextStyle(
                color: Colors.black87,
                fontSize: 14.0,
                fontWeight: FontWeight.normal,
                fontFamily: 'gotham',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _textRegisto() {
    return GestureDetector(
      onTap: () {},
      child: RichText(
        text: const TextSpan(
          children: [
            TextSpan(
              text: 'Ainda não tem conta?',
              style: TextStyle(
                color: Colors.black87,
                fontSize: 14.0,
                fontWeight: FontWeight.normal,
                fontFamily: 'gotham',
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _BtnBack() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFFFFFF),
            elevation: 0,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Navigator.of(context).pushReplacement(CupertinoPageRoute(
              builder: (BuildContext context) => IniciarPage()));
        },
        child: const Icon(
          Icons.close,
          color: Color(0xFF000000),
          size: 40,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            Positioned(
                left: 0.0,
                top: 0.0,
                width: MediaQuery.of(context).size.width,
                child: FittedBox(
                  alignment: Alignment.center,
                  //fit: BoxFit.fill,
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(0),
                            bottomRight: Radius.circular(0),
                            topLeft: Radius.circular(0),
                            topRight: Radius.circular(0)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Colors.white, Colors.white])),
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.6,
                    margin: const EdgeInsets.all(0),
                  ),
                )),
            Positioned(
                left: 10.0,
                top: 40.0,
                width: 60,
                child: FittedBox(
                  alignment: Alignment.center,
                  //fit: BoxFit.fill,
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(100),
                            bottomRight: Radius.circular(100),
                            topLeft: Radius.circular(100),
                            topRight: Radius.circular(100)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Colors.white, Colors.white])),
                    width: 60,
                    height: 60,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [_BtnBack()],
                    ),
                  ),
                )),
            Positioned(
                left: 0.0,
                bottom: 0.0,
                width: MediaQuery.of(context).size.width,
                child: FittedBox(
                  alignment: Alignment.center,
                  //fit: BoxFit.fill,
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(0),
                            bottomRight: Radius.circular(0),
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)])),
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.3,
                    margin: const EdgeInsets.all(0),
                    child: const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [],
                    ),
                  ),
                )),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(20),
                              bottomRight: Radius.circular(20),
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20)),
                          gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)])),
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.8,
                      margin: const EdgeInsets.all(0),
                      child: Container(
                        margin: const EdgeInsets.only(
                            right: 5, top: 50, left: 5, bottom: 5),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text(
                              'Acesse a sua conta',
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: 20.0,
                                fontWeight: FontWeight.normal,
                                fontFamily: 'gotham',
                              ),
                              textAlign: TextAlign.left,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            _TxtTelefone(),
                            const SizedBox(
                              height: 7,
                            ),
                            _TxtSenha(),
                            const SizedBox(
                              height: 2,
                            ),
                            _btnReset(),
                            const SizedBox(
                              height: 2,
                            ),
                            _BtnComecar(),
                            const SizedBox(
                              height: 10,
                            ),
                            _btnOR(),
                            const SizedBox(
                              height: 10,
                            ),
                            //  _BtnGoogle(),
                            //    const SizedBox(height: 10,),
                            //  _BtnApple(),
                            //  const SizedBox(height: 20,),
                            _textRegisto(),
                            const SizedBox(
                              height: 10,
                            ),
                            _BtnRegisto(),
                            const SizedBox(
                              height: 20,
                            ),
                          ],
                        ),
                      ))
                ],
              ),
            )
          ],
        ));
  }
}
