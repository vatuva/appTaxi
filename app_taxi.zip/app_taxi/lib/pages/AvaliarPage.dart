import 'dart:convert';
import 'package:vambora_passageiro/pages/PrincipalPage.dart';
import 'package:vambora_passageiro/pages/RadarPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:smooth_star_rating_null_safety/smooth_star_rating_null_safety.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:http/http.dart' as http;
import '../config/Constats.dart';
import 'DriverPage.dart';
import 'Loading.dart';
import 'PromocaoPage.dart';
import 'SelectPagamentoPage.dart';
import 'SelectViaturaPage.dart';
import 'SplashPage.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:intl/intl.dart';

class AvaliarPage extends StatefulWidget {
  @override
  _AvaliarPage createState() => _AvaliarPage();
}

class _AvaliarPage extends State<AvaliarPage> {
  var comentariotxt = TextEditingController();
  final f = NumberFormat("#,##0", "pt_BR");
  double ratingMotorsta = 0.0;
  bool loadingRecibo = false;
  var feedback;

  @override
  void initState() {
    InfoViagem();
    super.initState();
  }

  List<Map> staticData = tbAvalicao.data;

  Widget _daoAvalicao() {
    return Container(
      width: MediaQuery.of(context).size.width * 0.95,
      margin: const EdgeInsets.only(top: 0, bottom: 0, left: 10, right: 10),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: staticData.length,
        itemBuilder: (BuildContext context, int index) => Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
          ),
          child: InkWell(
              onTap: () {
                if (comentariotxt.text == "") {
                  comentariotxt.text = staticData[index]["mensagem"];
                } else {
                  comentariotxt.text =
                      "${comentariotxt.text}," + staticData[index]["mensagem"];
                }

                print(feedback);
              },
              child: Column(
                children: [
                  Row(
                    children: [
                      Card(
                        semanticContainer: true,
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        elevation: 2,
                        color: Colors.white,
                        shadowColor: const Color(0xFFEDBD1D),
                        shape: const RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                        child: Stack(
                          alignment: Alignment.center,
                          children: <Widget>[
                            SizedBox(
                              height: 40.0,
                              width: MediaQuery.of(context).size.width * 0.33,
                              child: Container(
                                color: const Color(0xFFFFFFFF),
                              ),
                            ),
                            Positioned(
                                child: Container(
                              margin: const EdgeInsets.all(0),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    staticData[index]["mensagem"].toString(),
                                    overflow: TextOverflow.fade,
                                    maxLines: 1,
                                    style: const TextStyle(
                                        fontSize: 10.0,
                                        fontWeight: FontWeight.normal,
                                        color: Color(0xFFEDBD1D),
                                        fontFamily: 'gotham'),
                                  ),
                                ],
                              ),
                            )),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              )),
        ),
      ),
    );
  }

  Future InfoViagem() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/viagem/ver-dados');
      var response = await http.post(url, body: {
        "pedido": idPedido.toString(),
      });
      final map = json.decode(response.body);
      final DadosPagamento = map["pagamento"];
      setState(() {
        totalPagar = double.parse(DadosPagamento["valor"]);
      });
      loadingRecibo = true;
      print('Total');
      print(totalPagar);
    } catch (e) {
      print(e);
    }
  }

  loading load = loading();

  Future Avaliar() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/viagem/actualizar');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "avaliacao_motorista": ratingMotorsta.toString(),
        "feedback": comentariotxt.text,
        "pedido": idPedido.toString(),
      });
      final map = json.decode(response.body);
      //final msgr = map["retorno"];
      print(map);
      estatus_viagem = "0";
      await SessionManager().set("estatus_viagem", "0");
      idPedido = "";
      chegada = false;
      carregarViagem = false;
      aceite_viagem = false;
      CodigoCupom = "";
      await SessionManager().set("CodigoCupom", "");
      ValorCupom = "";
      await SessionManager().set("ValorCupom", "");
      await SessionManager().set("idPedido", "");
      valor_estimado = 0.0;
      await SessionManager().set("valor_estimado", "0.0");
      await SessionManager().set("taxa_km", "0.0");
      await SessionManager().set("tarifa_base", "0.0");
      ratingMotorsta = 0.0;
      // ignore: use_build_context_synchronously
      Navigator.of(context).pushReplacement(
          CupertinoPageRoute(builder: (BuildContext context) => SplashPage()));
      showTopSnackBar(
        // ignore: use_build_context_synchronously
        Overlay.of(context),
        const CustomSnackBar.success(
          message: 'Avaliação enviada com sucesso!',
        ),
      );
    } catch (e) {
      print(e);
    }
  }

  Widget _BtnFinalizar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFFFFFFF),
            elevation: 2,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          Avaliar();
        },
        child: const Text(
          'Enviar Avaliação',
          style: TextStyle(
            color: Color(0xFF000000),
            fontSize: 22.0,
            fontWeight: FontWeight.normal,
            fontFamily: 'gotham',
          ),
          textAlign: TextAlign.center,
          overflow: TextOverflow.fade,
          maxLines: 1,
        ),
      ),
    );
  }

  Widget _comentario() {
    return Column(
      children: <Widget>[
        Container(
          color: Colors.white,
          alignment: Alignment.topLeft,
          height: 100.0,
          width: MediaQuery.of(context).size.width * 0.9,
          child: TextFormField(
            textAlignVertical: TextAlignVertical.center,
            textAlign: TextAlign.left,
            maxLines: 4,
            controller: comentariotxt,
            keyboardType: TextInputType.text,
            style: const TextStyle(
              color: Colors.black,
              fontFamily: 'gotham',
            ),
            decoration: InputDecoration(
              border: InputBorder.none,
              suffixIcon: IconButton(
                  icon: const Icon(
                    Icons.clear,
                    color: Color(0xFFF20424),
                    size: 20,
                  ),
                  onPressed: () {
                    comentariotxt.clear();
                  }),
              hintText: 'Comentário',
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFFEDBD1D),
        body: ListView(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const SizedBox(
                  height: 50,
                ),
                const Center(
                  child: Text(
                    'VALOR DA CORRIDA',
                    style: TextStyle(
                      color: Color(0xFF000000),
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'gotham',
                    ),
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                Center(
                  child: loadingRecibo == false
                      ? const Text(
                          'Carregando valor...',
                          style: TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 12.0,
                            fontWeight: FontWeight.normal,
                            fontFamily: 'gotham',
                          ),
                        )
                      : Text(
                          "${f.format(totalPagar).toString()} Kz",
                          style: const TextStyle(
                            color: Color(0xFF000000),
                            fontSize: 60.0,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'gotham',
                          ),
                        ),
                ),
                const Divider(
                  height: 30,
                  color: Color(0xFF000000),
                ),
                const SizedBox(
                  height: 50,
                ),
                const Text(
                  'Avalie a sua Viagem',
                  style: TextStyle(
                    color: Color(0xFF000000),
                    letterSpacing: 0,
                    fontSize: 22.0,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'gotham',
                  ),
                ),
                const SizedBox(
                  height: 25,
                ),
                SmoothStarRating(
                  rating: ratingMotorsta,
                  size: 60,
                  filledIconData: Icons.star,
                  halfFilledIconData: Icons.star_half,
                  defaultIconData: Icons.star_border,
                  color: const Color(0xFFFFFFFF),
                  borderColor: const Color(0xFF000000),
                  starCount: 5,
                  allowHalfRating: true,
                  spacing: 3.0,
                  onRatingChanged: (value) {
                    setState(() {
                      ratingMotorsta = value;
                    });
                  },
                ),
                const SizedBox(
                  height: 10,
                ),
                // _daoAvalicao(),
                const SizedBox(
                  height: 15,
                ),
                _BtnFinalizar()
              ],
            )
          ],
        ));
  }
}

class tbAvalicao {
  static List<Map> data = [
    {
      "id": 1,
      "mensagem": "Viagem Agradável",
    },
    {
      "id": 2,
      "mensagem": "Profissional",
    },
    {
      "id": 3,
      "mensagem": "Prestativo",
    },
    {
      "id": 4,
      "mensagem": "Viatura em bom estado",
    },
    {
      "id": 5,
      "mensagem": "Música agradável",
    },
  ];
}
