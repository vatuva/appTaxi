// ignore_for_file: use_build_context_synchronously
import 'dart:io';
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:card_loading/card_loading.dart';
import 'package:flutter_foreground_task/flutter_foreground_task.dart';
import 'package:vambora_passageiro/controller/MapController.dart';
import 'package:vambora_passageiro/pages/DriverPage.dart';
import 'package:vambora_passageiro/pages/SelectPagamentoPage.dart';
import 'package:vambora_passageiro/pages/SelectViaturaPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:more_loading_gif/more_loading_gif.dart';
import 'package:panara_dialogs/panara_dialogs.dart';
import '../config/Constats.dart';
import '../main.dart';
import '../modelos/Viaturas.dart';
import 'Back_Services.dart';
import 'Loading.dart';
import 'LocalNotification.dart';
import 'PrincipalPage.dart';
import 'package:material_dialogs/material_dialogs.dart';
import 'package:material_dialogs/widgets/buttons/icon_button.dart';
import 'package:material_dialogs/widgets/buttons/icon_outline_button.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'SplashPage.dart';

// Dados da Viagem
var estado_pedido;
var nome_motorista;
var foto_motorista;
var contacto_motorista;
var viatura_motorista;
var matricula_motorista;
var marca_viatura;
var cor_viatura;
var modelo_viatura;
var numeropedido;
var id_motorista;
var posicaoMotorista;
var distanciaMotorista;
var tempoEspera;
var minhaPosicao;
double? lat1 = 0.0;
double? long1 = 0.0;
double? lat2 = 0.0;
double? long2 = 0.0;
double? latPosMoto = 0.0;
double? longPosMoto = 0.0;
var origem_viagem;
var destino_viagem;
bool aceite_viagem = false;
var status_radar;
bool viagem = false;
double rating_motorista = 0.0;
String msgPesquisa = "Estamos a procura da Viatura mais próxima de si.";
bool notificacao_aceite = false;

class RadarPage extends StatefulWidget {
  @override
  _RadarPageState createState() => _RadarPageState();
}

class _RadarPageState extends State<RadarPage> {
  bool con = false;

  loading load = loading();

  final controllerMap = Get.put(MapController());
  BitmapDescriptor markerIcon = BitmapDescriptor.defaultMarker;

  final Set<Polyline> _polylines = Set();

  final Completer<GoogleMapController> _controller =
      Completer<GoogleMapController>();

  final CameraPosition _initialLocation =
      CameraPosition(target: LatLng(posicaoV1, posicaoV2), zoom: 13.0);
  late GoogleMapController mapController;

  getCurrentLocation() async {
    await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best)
        .then((Position position) async {
      GoogleMapController controller = await _controller.future;
      controller.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: LatLng(posicaoV1, posicaoV2),
        zoom: 13.0,
      )));
    }).catchError((e) async {
      print(e);
    });
  }

  Future<void> ajustarCamera(LatLng origem, LatLng destino) async {
    final controller = await _controller.future;

    final bounds = LatLngBounds(
      southwest: LatLng(
        origem.latitude < destino.latitude
            ? origem.latitude
            : destino.latitude,
        origem.longitude < destino.longitude
            ? origem.longitude
            : destino.longitude,
      ),
      northeast: LatLng(
        origem.latitude > destino.latitude
            ? origem.latitude
            : destino.latitude,
        origem.longitude > destino.longitude
            ? origem.longitude
            : destino.longitude,
      ),
    );

    controller.animateCamera(CameraUpdate.newLatLngBounds(bounds, 80));
  }


  Future Carregamento() async {
    await showDialog(
      context: context,
      builder: (context) => FutureProgressDialog(load.getFuture()),
    );
  }

  Future conexao() async {
    try {
      final result = await InternetAddress.lookup('www.mvconws.com');
      if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
        con = true;
      }
    } on SocketException catch (_) {
      con = false;
    }
    print(con);
  }

  Widget InfoBar() {
    return Container(
        padding: const EdgeInsets.all(16),
        width: MediaQuery.of(context).size.width,
        height: 130,
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15),
            bottomLeft: Radius.zero,
            bottomRight: Radius.zero,
            topRight: Radius.circular(15),
          ),
          color: Color(0xFFEDBD1D),
        ),
        child: Column(
          children: [
            const Divider(
              height: 30,
              color: Color(0xFFEDEEE9),
            ),
            Center(
              child: Text(
                msgPesquisa,
                style: const TextStyle(
                    fontSize: 12,
                    fontFamily: "Gotham",
                    color: Color(0xFF15191C)),
              ),
            ),
            const SizedBox(
              height: 10,
            ),
            const CardLoading(
              cardLoadingTheme: CardLoadingTheme(
                  colorOne: Color(0xFF15191C), colorTwo: Color(0xFFEDBD1D)),
              height: 20,
              borderRadius: BorderRadius.all(Radius.circular(10)),
              margin: EdgeInsets.only(bottom: 10),
            ),
          ],
        ));
  }

  void LatLong() {
    lat1 = double.tryParse(origem_viagem.toString().split(',')[0]);
    long1 = double.tryParse(origem_viagem.toString().split(',')[1]);
    lat2 = double.tryParse(destino_viagem.toString().split(',')[0]);
    long2 = double.tryParse(destino_viagem.toString().split(',')[1]);
    latPosMoto = double.tryParse(posicaoMotorista.toString().split(',')[0]);
    longPosMoto = double.tryParse(posicaoMotorista.toString().split(',')[1]);
  }

  Future DadosPedido() async {
    try {
      String baseURL = "https://$dom/$endpoint/corridaapi/pedido/dados-pedido";
      String request = '$baseURL?app=passageiro';
      var response = await http.post(Uri.parse(request), body: {
        "passageiro": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": idPedido.toString(),
      });
      final map = json.decode(response.body);
      print('dados pedido');
      print(map);
      final dados = map['pedido'];
      final motorista = map['motorista'];
      final infoMotorista = map['info_motorista'];
      print(infoMotorista);
      estado_pedido = dados['status'];
      await SessionManager().set("idPedido", idPedido);
      desc_origem_pedido = dados['desc_origem'];
      desc_destino_pedido = dados['desc_destino'];
      origem_viagem = dados['origem'];
      destino_viagem = dados['destino'];
      if (estado_pedido == "2") {
        posicaoMotorista = infoMotorista['localizacao_actual'];
        LatLong();
        aceite_viagem = true;
        await SessionManager().set("idPedido", idPedido);
        final nomeMoto = motorista['nome'];
        rating_motorista = double.tryParse(map['avaliacao'])!;
        nome_motorista = "$nomeMoto";
        foto_motorista = motorista['foto'];
        contacto_motorista = motorista['telefone'];
        id_motorista = motorista['id'];
        viatura_motorista = infoMotorista['categoria'];
        matricula_motorista = infoMotorista['matricula'];
        marca_viatura = infoMotorista['marca_viatura'];
        cor_viatura = infoMotorista['cor'];
        modelo_viatura = infoMotorista['modelo_viatura'];
      } else {
        aceite_viagem = false;
      }
    } catch (e) {
      print(e);
    }
  }

  Future ActivarPedido() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/pedido/status-passageiro');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": idPedido,
        "status_passageiro": "1",
      });
      final map = json.decode(response.body);
    } catch (e) {
      print(e);
    }
  }

  void VerificarPedido() {
    if (aceite_viagem == true || estatus_viagem == 1) {
      setState(() {
        msgPesquisa = "Estamos a procura da Viatura mais próxima de si.";
      });
      CalcularTempo();
      _radarTimer.cancel();
      _radarTimer2.cancel();
      _radarTimer3.cancel();
      aceite_viagem = false;
      ActivarPedido();
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => DriverPage()));
    } else {}
  }

  Future CancelarPedido() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/pedido/cancelar');
      var response = await http.post(url, body: {
        "passageiro": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": idPedido.toString(),
      });
      final map = json.decode(response.body);
      final retorno = map['retorno'];
      if (retorno == 1) {
        setState(() {
          msgPesquisa = "Estamos a procura da Viatura mais próxima de si.";
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.info(
            message: 'Pedido cancelado com sucesso',
          ),
        );
        stopService();
        _radarTimer.cancel();
        _radarTimer2.cancel();
        _radarTimer3.cancel();
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => PrincipalPage()));
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Ocorreu um erro ao cancelar o pedido',
          ),
        );
      }
    } catch (e) {
      print(e);
    }
  }

  Future CancelarPedido2() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/pedido/cancelar');
      var response = await http.post(url, body: {
        "passageiro": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "pedido": idPedido.toString(),
      });
      final map = json.decode(response.body);
      final retorno = map['retorno'];
      setState(() {
        msgPesquisa = "Estamos a procura da Motorizada mais próxima.";
      });
    } catch (e) {
      print(e);
    }
  }

  Widget _BtnBack() {
    return SizedBox(
      width: 60,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            padding: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: () {
          PanaraConfirmDialog.showAnimatedGrow(
            color: Colors.red,
            context,
            title: "Cancelar Pedido",
            message: "Tem a certeza que deseja cancelar o pedido de boleia?",
            confirmButtonText: "Sim",
            cancelButtonText: "Não",
            onTapConfirm: () {
              Navigator.of(context).pop;
              CancelarPedido();
            },
            onTapCancel: () {
              Navigator.of(context).pop;
            },
            panaraDialogType: PanaraDialogType.warning,
          );
        },
        child: const Icon(
          Icons.cancel_outlined,
          color: Color(0xFF15191C),
          size: 30,
        ),
      ),
    );
  }

  Future enviarPedido() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/corridaapi/pedido/cadastro');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "origem": origem_pedido.toString(),
        "destino": destino_pedido.toString(),
        "viajante": viajante_pedido.toString(),
        "contacto": contacto_pedido.toString(),
        "tipo_viatura": tipo_viatura.toString(),
        "metodo_pagamento": metodo_pagamento.toString(),
        "desc_origem": desc_origem_pedido.toString(),
        "desc_destino": desc_destino_pedido.toString(),
        "estimativa": valor_estimado.toString()
      });
      final map = json.decode(response.body);
      final dadosPedido = map['pedido'];
      print('total pedidos');
      print(dadosPedido);
      idPedido = dadosPedido['id'];
      final retorno = map['retorno'];
      if (retorno == 1) {
        Pesquisar(idPedido);
      } else {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.info(
            message:
                'Caro passageiro, ocorreu um erro ao processar o seu pedido. Tente novamente.',
          ),
        );
      }
    } catch (e) {
      print(e);
    }
  }

  Future Pesquisar(String id) async {
    try {
      setState(() {
        btnRg3 = true;
      });
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https', host: dom, path: '$endpoint/corridaapi/pesquisa');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "categoria": tipo_viatura.toString(),
        "pedido": id.toString(),
      });
      final map = json.decode(response.body);
      final dadosPesquisa = map['motoristas_disponiveis'];
      final total = map['total'];
      if (total > 0) {
        await SessionManager().set("idPedido", id.toString());
        notificacao_aceite = false;
        await SessionManager().set("notificacao_aceite", false);
        // ignore: use_build_context_synchronously
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => RadarPage()));
      } else {
        setState(() {
          btnRg3 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.info(
            message:
                'Caro passageiro, infelizmente estamos sem motorizadas disponíveis para esta rota.',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg3 = false;
      });
      showTopSnackBar(
        // ignore: use_build_context_synchronously
        Overlay.of(context),
        const CustomSnackBar.error(
          message:
              'Caro passageiro, infelizmente estamos com problemas técnicos em processar o seu pedido.',
        ),
      );
    }
  }

  void startService() async {
    if (await FlutterForegroundTask.isRunningService) {
      FlutterForegroundTask.restartService();
    } else {
      FlutterForegroundTask.startService(
        serviceId: 256,
        notificationTitle: 'Viagem em Curso',
        notificationText: 'Toque para retornar ao app',
        callback: startCallback,
      );
    }
  }

  void stopService() {
    FlutterForegroundTask.stopService();
  }

  late Timer _radarTimer;
  late Timer _radarTimer2;
  late Timer _radarTimer3;

  @override
  void initState() {
    startService();
    conexao();
    btnRg3 = false;
    DadosPedido();
    carregarIcone().then((_) {
      atualizarViaturas();
      iniciarTracking();
    });
    _radarTimer = Timer.periodic(const Duration(seconds: 2), (Timer t) {
      DadosPedido();
      VerificarPedido();
    });
    _radarTimer3 = Timer.periodic(const Duration(seconds: 60), (Timer t) {
      setState(() {
        msgPesquisa = "Continuamos a procura. Aguarde um momento.";
      });
      //Pesquisar();
    });
    _radarTimer2 = Timer.periodic(const Duration(seconds: 120), (Timer t) {
      _radarTimer.cancel();
      _radarTimer2.cancel();
      _radarTimer3.cancel();
      PanaraConfirmDialog.showAnimatedGrow(
        color: Colors.red,
        context,
        title: "Pedido sem resposta",
        message:
            "Caro passageiro, infelizmente estamos sem resposta para o seu pedido. \nDeseja cancelar para tentar mais tarde?",
        confirmButtonText: "Cancelar",
        cancelButtonText: "Repetir",
        onTapConfirm: () {
          Navigator.of(context).pop;
          stopService();
          CancelarPedido();
        },
        onTapCancel: () {
          Navigator.of(context).pop;
          enviarPedido();
        },
        panaraDialogType: PanaraDialogType.normal,
      );
    });
    super.initState();
    LocalNotification.initialize(flutterLocalNotificationsPlugin);
  }



  @override
  void dispose() {
    _radarTimer.cancel();
    _radarTimer2.cancel();
    _radarTimer3.cancel();
    _timer?.cancel();
    super.dispose();
  }

  Future CalcularTempo() async {
    try {
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/motoristaonlinemaisproximo');
      var response = await http.post(url, body: {
        "localizacao_passageiro": posicaoMotorista.toString(),
      });
      final map = json.decode(response.body);
      setState(() {
        tempoEspera = map["tempo"];
        print("motorista-mais-proximo");
        print(viatura_proxima);
      });
    } catch (e) {
      print(e);
    }
  }

  // Tracking de viatura

  final Map<String, Marker> _markers2 = {};
  final Map<String, LatLng> _ultimaPosicao = {};
  Timer? _timer;
  late BitmapDescriptor carroIcon;


  Future<void> carregarIcone() async {
    carroIcon = await BitmapDescriptor.fromAssetImage(
      const ImageConfiguration(size: Size(48, 48)),
      'assets/images/carro_online.png',
    );
  }

  Future<void> animarViatura({
    required String id,
    required LatLng inicio,
    required LatLng destino,
  }) async {
    const int frames = 20;

    final bearing = calcularBearing(inicio, destino);

    for (int i = 0; i <= frames; i++) {
      final t = i / frames;

      final posicao = LatLng(
        inicio.latitude +
            (destino.latitude - inicio.latitude) * t,
        inicio.longitude +
            (destino.longitude - inicio.longitude) * t,
      );

      _markers2[id] = Marker(
        markerId: MarkerId(id),
        position: posicao,
        icon: carroIcon,
        flat: true,
        rotation: bearing,
        anchor: const Offset(0.5, 0.5),
      );

      if (mounted) setState(() {});
      await Future.delayed(
        const Duration(milliseconds: 50),
      );
    }
  }

  double calcularBearing(LatLng inicio, LatLng fim) {
    final lat1 = inicio.latitude * pi / 180;
    final lon1 = inicio.longitude * pi / 180;
    final lat2 = fim.latitude * pi / 180;
    final lon2 = fim.longitude * pi / 180;

    final dLon = lon2 - lon1;

    final y = sin(dLon) * cos(lat2);
    final x = cos(lat1) * sin(lat2) -
        sin(lat1) * cos(lat2) * cos(dLon);

    final bearing = atan2(y, x);
    return (bearing * 180 / pi + 360) % 360;
  }



  Future<List<Viatura>> buscarViaturasOnline() async {
    final response = await http.get(
      Uri.parse('https://mvconws.com/vamborawbs/motoristasonline'),
    );

    final List data = json.decode(response.body);

    return data.map((e) => Viatura.fromJson(e)).toList();
  }

  Future<void> atualizarViaturas() async {
    final viaturas = await buscarViaturasOnline();

    if (!mounted) return;

    for (final v in viaturas) {
      final id = v.matricula;
      final novaPosicao = v.posicao;

      if (_ultimaPosicao.containsKey(id)) {
        final posicaoAnterior = _ultimaPosicao[id]!;
        animarViatura(
          id: id,
          inicio: posicaoAnterior,
          destino: novaPosicao,
        );
      } else {
        _markers2[id] = Marker(
          markerId: MarkerId(id),
          position: novaPosicao,
          flat: true,
          anchor: const Offset(0.5, 0.5),
          icon: carroIcon,
          infoWindow: InfoWindow(title: v.apelido),
        );
      }

      _ultimaPosicao[id] = novaPosicao;
    }
  }


  void iniciarTracking() {
    _timer = Timer.periodic(const Duration(seconds: 3), (_) {
      atualizarViaturas();
    });
  }
// fim tracking


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'Gotham'),
      home: Scaffold(
        drawer: const Drawer(),
        body: Stack(
          children: [
            GoogleMap(
              mapType: MapType.normal,
              initialCameraPosition: CameraPosition(
                  zoom: 13.5, target: LatLng(posicaoV1, posicaoV2)),
              myLocationEnabled: true,
              markers: Set<Marker>.of(_markers2.values),
              zoomControlsEnabled: false,
              myLocationButtonEnabled: false,
              zoomGesturesEnabled: true,
              onMapCreated: (GoogleMapController controller) {
                _controller.complete(controller);
                ajustarCamera(origem_pedido, destino_pedido);
              },
            ),
            SafeArea(
                child: Padding(
              padding: EdgeInsets.only(
                right: MediaQuery.of(context).size.width / 1.5,
                top: 10,
                left: 10,
              ),
              child: Column(
                children: [
                  _BtnBack(),
                ],
              ),
            )),
            SafeArea(
                child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  MoreLoadingGif(
                      type: MoreLoadingGifType.ripple,
                      size: MediaQuery.of(context).size.width),
                ],
              ),
            )),
            Container(
              alignment: Alignment.bottomCenter,
              child: Row(
                children: [
                  Row(
                    children: [
                      InfoBar(),
                    ],
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
