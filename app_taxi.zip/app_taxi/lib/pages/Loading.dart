import 'package:flutter/material.dart';

class loading{

  Future getFuture() {
    return Future(() async {
      await Future.delayed(const Duration(seconds: 5));
      return const CircularProgressIndicator(
        backgroundColor: Color(0xFFFFFFFF),
        valueColor: AlwaysStoppedAnimation<Color>(Color(0xFFEDBD1D)),
        strokeWidth: 10,
      );
    });
  }

}
