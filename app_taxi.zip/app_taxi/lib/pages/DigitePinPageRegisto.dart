import 'dart:convert';
import 'dart:io';
import 'package:vambora_passageiro/pages/CarregarPerfilPage.dart';
import 'package:vambora_passageiro/pages/TelaRegisto.dart';
import 'package:vambora_passageiro/pages/PrincipalPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_session_manager/flutter_session_manager.dart';
// ignore: depend_on_referenced_packages
import 'package:otp_text_field/otp_field.dart';
// ignore: depend_on_referenced_packages
import 'package:otp_text_field/otp_text_field.dart';
// ignore: depend_on_referenced_packages
import 'package:otp_text_field/style.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:future_progress_dialog/future_progress_dialog.dart';
import '../config/Constats.dart';
import 'Loading.dart';
import 'package:http/http.dart' as http;
import 'SplashPage.dart';

class DigitePinPageRegisto extends StatefulWidget {
  @override
  _DigitePinPageRegisto createState() => _DigitePinPageRegisto();
}

class _DigitePinPageRegisto extends State<DigitePinPageRegisto> {
  final TextEditingController OtpController = TextEditingController();
  loading load = loading();
  var otp;
  FocusNode myfocus = FocusNode();

  @override
  void initState() {
    super.initState();
  }

  void GerarSessao() async {
    await SessionManager().set("idPassageiro", idPassageiro);
    await SessionManager().set("ChavePublica", ChavePublica);
  }

  Future ValidarCodigo() async {
    try {
      setState(() {
        btnRg4 = true;
      });
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/activar/passo2');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
        "codigo": otp,
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final msg = map["msg"];
      print(map);
      if (msgr == 1) {
        GerarSessao();
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Código validado com sucesso.',
          ),
        );
        setState(() {
          btnRg4 = false;
        });
        // ignore: use_build_context_synchronously
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => CarregarPerfilPage()));
      } else if (msgr == 0) {
        setState(() {
          btnRg4 = false;
        });
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Código inválido. Digite novamente',
          ),
        );
      }
    } catch (e) {
      setState(() {
        btnRg4 = false;
      });
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        CustomSnackBar.error(
          message: 'Ops! Ocorreu um erro. Erro $e.',
        ),
      );
    }
  }

  Future ValidarNumero() async {
    try {
      await showDialog(
        context: context,
        builder: (context) => FutureProgressDialog(load.getFuture()),
      );
      var url = Uri(
          scheme: 'https',
          host: dom,
          path: '$endpoint/passageiroapi/activar/passo1');
      var response = await http.post(url, body: {
        "id": idPassageiro.toString(),
        "chave_publica": ChavePublica.toString(),
      });
      final map = json.decode(response.body);
      final msgr = map["retorno"];
      final msg = map["msg"];
      if (msgr == 1) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.success(
            message: 'Enviado com sucesso.',
          ),
        );
        Navigator.of(context).pushReplacement(CupertinoPageRoute(
            builder: (BuildContext context) => DigitePinPageRegisto()));
        // ignore: use_build_context_synchronously
      } else if (msgr == 0) {
        showTopSnackBar(
          // ignore: use_build_context_synchronously
          Overlay.of(context),
          const CustomSnackBar.error(
            message: 'Número inválido.',
          ),
        );
      }
    } catch (e) {
      print(e);
      showTopSnackBar(
        Overlay.of(context),
        CustomSnackBar.error(
          message: 'Ops! Ocorreu um erro. Erro $e.',
        ),
      );
    }
  }

  Widget _BtnConfirmar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
        style: TextButton.styleFrom(
            backgroundColor: const Color(0xFFEDBD1D),
            elevation: 10,
            padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            )),
        onPressed: btnRg4 == false
            ? () async {
                if (otp == "") {
                  showTopSnackBar(
                    Overlay.of(context),
                    const CustomSnackBar.error(
                      message: 'Por favor, Preencher o Código OTP.',
                    ),
                  );
                } else {
                  ValidarCodigo();
                }
              }
            : () {},
        child: btnRg1 == false
            ? const Text(
                'Continuar',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18.0,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'gotham',
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.fade,
                maxLines: 1,
              )
            : const CircularProgressIndicator(
                backgroundColor: Color(0xFFEDBD1D),
                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
              ),
      ),
    );
  }

  Widget _BtnReenviar() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 60,
      child: TextButton(
          style: TextButton.styleFrom(
              backgroundColor: const Color(0xFFFFFFFF),
              elevation: 2,
              padding: EdgeInsets.only(top: Platform.isAndroid ? 0 : 10),
              shape: RoundedRectangleBorder(
                side: const BorderSide(width: 1, color: Color(0xFFEDBD1D)),
                borderRadius: BorderRadius.circular(90),
              )),
          onPressed: () async {
            setState(() {
              otp = null;
            });
            await showDialog(
              context: context,
              builder: (context) => FutureProgressDialog(load.getFuture()),
            );
            ValidarNumero();
          },
          child: const Text(
            'Reenviar',
            style: TextStyle(
              color: Color(0xFFEDBD1D),
              fontSize: 18.0,
              fontWeight: FontWeight.w900,
              fontFamily: 'gotham',
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.fade,
            maxLines: 1,
          )),
    );
  }

  Widget _TxtOPT() {
    return SizedBox(
      width: MediaQuery.of(context).size.width * 0.9,
      height: 90,
      child: OTPTextField(
        length: 5,
        spaceBetween: 4,
        width: MediaQuery.of(context).size.width,
        fieldWidth: MediaQuery.of(context).size.width * 0.15,
        style: const TextStyle(
            fontFamily: 'Gotham', fontWeight: FontWeight.bold, fontSize: 30),
        textFieldAlignment: MainAxisAlignment.center,
        fieldStyle: FieldStyle.box,
        onCompleted: (pin) {
          otp = pin;
        },
      ),
    );
  }

  Widget _btnOR() {
    return GestureDetector(
      onTap: () => null,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            children: [
              Container(
                  height: 2,
                  color: Colors.black12,
                  width: MediaQuery.of(context).size.width * 0.4)
            ],
          ),
          Column(
            children: [
              SizedBox(width: MediaQuery.of(context).size.width * 0.01),
              const Text(
                "  ",
                style: TextStyle(
                  color: Colors.black12,
                  fontSize: 12.0,
                  fontWeight: FontWeight.normal,
                ),
              ),
              SizedBox(width: MediaQuery.of(context).size.width * 0.01)
            ],
          ),
          Column(
            children: [
              Container(
                  height: 2,
                  color: Colors.black12,
                  width: MediaQuery.of(context).size.width * 0.4)
            ],
          )
        ],
      ),
    );
  }

  Widget _textCodigo() {
    return GestureDetector(
      onTap: () {},
      child: RichText(
        text: const TextSpan(
          children: [
            TextSpan(
              text: 'Não recebeu o código?',
              style: TextStyle(
                color: Colors.black87,
                fontSize: 14.0,
                fontWeight: FontWeight.normal,
                fontFamily: 'gotham',
              ),
            ),
          ],
        ),
      ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            Positioned(
                left: 0.0,
                top: 0.0,
                width: MediaQuery.of(context).size.width,
                child: FittedBox(
                  alignment: Alignment.center,
                  //fit: BoxFit.fill,
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(0),
                            bottomRight: Radius.circular(0),
                            topLeft: Radius.circular(0),
                            topRight: Radius.circular(0)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Colors.white, Colors.white])),
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.6,
                    margin: const EdgeInsets.all(0),
                  ),
                )),
            Positioned(
                left: 10.0,
                top: 30.0,
                width: 60,
                child: FittedBox(
                  alignment: Alignment.center,
                  //fit: BoxFit.fill,
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(100),
                            bottomRight: Radius.circular(100),
                            topLeft: Radius.circular(100),
                            topRight: Radius.circular(100)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Colors.white, Colors.white])),
                    width: 60,
                    height: 60,
                    child: const Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [],
                    ),
                  ),
                )),
            Positioned(
                left: 0.0,
                bottom: 0.0,
                width: MediaQuery.of(context).size.width,
                child: FittedBox(
                  alignment: Alignment.center,
                  //fit: BoxFit.fill,
                  child: Container(
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(0),
                            bottomRight: Radius.circular(0),
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20)),
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)])),
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height * 0.3,
                    margin: const EdgeInsets.all(0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _btnOR(),
                        const SizedBox(
                          height: 20,
                        ),
                        _textCodigo(),
                        const SizedBox(
                          height: 10,
                        ),
                        _BtnReenviar(),
                        const SizedBox(
                          height: 50,
                        )
                      ],
                    ),
                  ),
                )),
            SizedBox(
              width: MediaQuery.of(context).size.width,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                      decoration: const BoxDecoration(
                          borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(20),
                              bottomRight: Radius.circular(20),
                              topLeft: Radius.circular(20),
                              topRight: Radius.circular(20)),
                          gradient: LinearGradient(
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                              colors: [Color(0xFFFFFFFF), Color(0xFFFFFFFF)])),
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height * 0.50,
                      margin: const EdgeInsets.all(0),
                      child: Container(
                        margin: const EdgeInsets.only(
                            right: 5, top: 50, left: 5, bottom: 5),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            const Text(
                              'Digite o Código',
                              style: TextStyle(
                                color: Colors.black87,
                                fontSize: 20.0,
                                fontWeight: FontWeight.normal,
                                fontFamily: 'gotham',
                              ),
                              textAlign: TextAlign.left,
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Text(
                              'Código enviado para o seu telefone.',
                              style: const TextStyle(
                                color: Colors.black54,
                                fontSize: 14.0,
                                fontWeight: FontWeight.normal,
                                fontFamily: 'gotham',
                              ),
                              textAlign: TextAlign.left,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            _TxtOPT(),
                            const SizedBox(
                              height: 15,
                            ),
                            _BtnConfirmar(),
                            const SizedBox(
                              height: 20,
                            ),
                          ],
                        ),
                      ))
                ],
              ),
            )
          ],
        ));
  }
}
