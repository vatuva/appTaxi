import '../modelos/Endereco_Model.dart';
import '../modelos/historico_endereco_service.dart';


class EnderecoController {
  Future<void> salvarEndereco(
      String tipo, EnderecoModel endereco) async {
    await HistoricoEnderecoService.salvar(tipo, endereco);
  }

  Future<List<EnderecoModel>> obterHistorico(String tipo) async {
    return await HistoricoEnderecoService.listar(tipo);
  }

  Future<void> limparHistorico(String tipo) async {
    await HistoricoEnderecoService.limpar(tipo);
  }
}
